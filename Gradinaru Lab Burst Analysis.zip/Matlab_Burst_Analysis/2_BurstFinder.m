function [ ] = BurstMainProgram( )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%% 

%%

clc;
close all;
% clear all;
fclose all;


KeepExpSet=0; %if 1, will load G factor, bkg, irf, irf alignment etc, from ExpWorkState, if 0 will prompt user to supply G factor file, IRF file, Bkg file etc.

if KeepExpSet
    load('ExpWorkState')
    KeepExpSet=1;
end

global BKGFile BKG
BKGFile=1;

%% Global Variables for Picoharp and Router
global ind_Dpar ind_Dperp ind_Apar ind_Aperp ind_Dexc ind_Aexc numRecords
ind_Dpar = 1;
ind_Dperp = 2;
ind_Apar = 3;
ind_Aperp = 4;

% ind_Dpar = 0; %For T2 mode there is usually only two inputs, so just arrange like this.
% ind_Apar = 1;
% ind_Aperp = 4;
% ind_Dperp = 3;

ind_Dexc = 11; %Router channel 2 (ind=15-router channel = 13)
ind_Aexc = 13; %Router channel 3 (ind=15-router channel = 11)
numRecords = 50000; %Number of records to process at a time.
%% Global Variables for Anisotropy Correction
global Gdd Gaa k1 k2 cal_DPar cal_DPerp cal_APar cal_APerp MinPhCal
Gdd=1; %Gfactor for donor after donor excitation
Gaa=1;
k1=0.33; %Applied to rDD but also to rAA - these may be PSF and thus wavelength dependent. Other groups only use one set - so maybe effect is small.
k2=0.065;
cal_DPar=zeros(1,256);
cal_DPerp=zeros(1,256);
cal_APar=zeros(1,256);
cal_APerp=zeros(1,256);
MinPhCal=10000;

%% GLobal Variables for FRET Correction
%% Usually don't know correction factors until after analysis. Leave these at defaults. 
global global_gamma global_lk global_dir global_dirType weightbursts
global_gamma=1;
weightbursts=0; %use gamma weighting in burst search algorithm? 1 is yes. If gamma >>1 or <<1, burst search could be biased.
global_lk=0;
global_dir=0;
global_dirType='ALEX'; % 'ALEX' or 'ABS' (absorption cross sections);
setLk=0; %Use donor only to set leakege/ recommend correct in post.
getLk=0; %retrieve a saved Leakage file/ recommend correct in post. 

if getLk && ~setLk
        load('LkMat','Lk')
        fprintf('The  leakage %0.3f was loaded into the global leakage variable \r\n ',Lk)    
        global_lk=Lk;
end
%% Global Variables for Lifetime
global Irf_DPar Irf_DPerp Irf_APar Irf_APerp t0 MinPhIRF c_Dpar c_Dperp subEns1_Dpar subEns1_Dperp subEns2_Dpar subEns2_Dperp subEns1_Apar subEns1_Aperp subEns2_Apar subEns2_Aperp dt subEns3_Apar subEns3_Aperp subEns3_Dperp subEns3_Dpar
global c_Apar c_Aperp subEns4_Apar subEns4_Aperp subEns4_Dperp subEns4_Dpar repExc MLE1d

repExc=0; % Repetive excitation model. takes 216 ms vs 28 ms for not repetitive vs 3 ms for 1D MLE
MLE1d=0; %use 1d MLE

c_Dpar=0;
c_Dperp=0;
c_Apar=0;
c_Aperp=0;
Irf_DPar=zeros(1,256);
Irf_DPerp=zeros(1,256);
Irf_APar=zeros(1,256); %Not really needed
Irf_APerp=zeros(1,256); %Notreally needed
t0=1; %global start time in ns, to align irfs and then decays
MinPhIRF=60000; %When both polarizations contain atleast MinPhIRF photons, it won't read anymore irf files

%for storings subensmbles
subEns1_Dpar=zeros(1,4096);
subEns1_Dperp=zeros(1,4096);
subEns2_Dpar=zeros(1,4096);
subEns2_Dperp=zeros(1,4096);
subEns1_Apar=zeros(1,4096);
subEns1_Aperp=zeros(1,4096);
subEns2_Apar=zeros(1,4096);
subEns2_Aperp=zeros(1,4096);
subEns3_Dpar=zeros(1,4096);
subEns3_Dperp=zeros(1,4096);
subEns3_Apar=zeros(1,4096);
subEns3_Aperp=zeros(1,4096);
subEns4_Dpar=zeros(1,4096);
subEns4_Dperp=zeros(1,4096);
subEns4_Apar=zeros(1,4096);
subEns4_Aperp=zeros(1,4096);


global FirstRun
FirstRun=1; %For code I only want to execute the first time its used - but not repeat everyfil etc.

%% Global Variable for Burst Search and Bkg search
global M L T dtTraj Nth Lacc

dtTraj=500E-6; %timestep used in creating a trajectory
Nth=1000; %if there is more than Nth photons in a burst don't bother with it. (Likely aggregate/multiple molecules/long computation time (scales with Nph^3))

%According to Nir et al., appropriate values for the APBS algorithm are:
%T = 0.5 ms
%L = 50 %can do L in post processing: better to keep L=M and get all bursts
%then filter later.
%M = 30

M=10;
L=30;
T=500E-6; %in seconds
Lacc=20;



%% I don't like using space between bursts to find bkg. I removed all mentions from the program I could find.
%Leaving this commented in case I broke something. Will remove at earliest convenience.

%global nspace minBkgPh Mbkg Tbkg Lbkg
%nspace=5; % the photons nspace photons after the current burst until nspace photons before the next burst will be considered for bkg computation
%minBkgPh=10; %there must be at least minBkgPh in the bkg region defined above in order for this burst to be considered: if there isn't bkg estimate will be bad.

%Mbkg=10; %Like a sliding MT algorithm, searching for photons in region where local count rate is < Mbkg/Tbkg: TO make sure we only estimate bkg from regions containing no fluorescence
        %Must be integer.
        
        %Gregs advice: Mbkg should be >=10 to have a reliable estimate
        %of the mean bkg rate. For example in very low background e.g <1000
        %CPS, in 200E-6 seconds you would have ~0.2 photons with which to
        %calculate the average interphoton time
        
%Tbkg=5*T; %2 before
%Lbkg=Mbkg; 
%global T_interburst
% T_interburst=1000E-6; %adjacent bursts should be seperated by at least this many seconds
%T_interburst=0; %Ignore T_interburst



%% Global Variables for Workflow
global ALEX pol lifetime FRET draw_microtimeIRF draw_microtimeG draw_microtimeB talkative talkative_burst T3mode AllRecords fid_burst_txt subEnsemble1_condition subEnsemble2_condition customEval DCBS
global TrajFRET TrajPol subEnsemble3_condition FRETfilt subEnsemble4_condition
TrajFRET=1; 
TrajPol=1;

%What to calculate?
ALEX = 1; %Will seperate photons in burst by their excitation source if 1
pol = 1; %Will calculate anisotropy if 1
lifetime =1; %Will perform time resolved if 1
FRET = 1; %Calculate FRET if 1

%What to graph while doing burst search?
FRETfilt=1; %Default 1. show graphics with filtered (1) or not filtered (0)
draw_microtimeIRF=1;
draw_microtimeG=1;
draw_microtimeB=0;
talkative=1;
talkative_burst=1;

T3mode=1; %controls whether records are read as T2 or T3 mode.
DCBS=0; %Dual color burst search. Not progammed yet, reserved for future use. If 1, will use dual color burst search. 0=APBS (tested, works). 1=DCBS (not tested).

%Can perform species selective (subensemble) fluorescence lifetime or anisotropy analysis by saving microtimes meeting some conditions
%Change as you wish.
subEnsemble1_condition='Sdexc>30 & Saexc<10 & S>0.9 '; %Donor only
SE1NAME='DonorOnly'
%% For Sic1.
subEnsemble2_condition='E>0 & E< 0.5 & S<0.7 & S>0.2 & abs(Txd-Txa)<0.25'; %all
SE2NAME='AllFRET'
subEnsemble3_condition='E>0.05 & E< 1 & S<0.7 & S>0.2 & abs(Txd-Txa)<0.25';  %high FRET
SE3NAME='05E100'
subEnsemble4_condition='E>0.15 & E< 0.51 & S<0.7 & S>0.25 & abs(Txd-Txa)<0.25 & tauD>1.6 & tauD<3.9';  %high FRET
SE4NAME='ESubEnsemble'

%For DNA mixture
% subEnsemble2_condition='E>0 & E< 0.3 & S<0.7 & S>0.2;'; %Low
% subEnsemble3_condition='E>0.55 & E< 1.1 & S<0.7 & S>0.2;';  %high FRET

if ~T3mode
    lifetime=0; %not possible without T3 mode
end
if ~ALEX
    DCBS=0; %Not possible without ALEX
end

AllRecords=[]; %will contain the [Nbursts by Nproperties] array with each bursts as a row and burst info as the columns.

global BVA nBVA runLength BVARecord
nBVA=5;
BVA = 0; %will perfrom Burst variance analysis (See Torella et al BiophyJ 2011)
runLength=40; %the number of windows in BVA varies from burst to burst, but need equal column lengths. Make this value ~ maxPh you expect per burst/nBVA. If there is less than runLength windows, the other values for window E will be NaN
BVARecord=[]; %place to keep FRET windows


%CustomEval is a cell array containing statements you wanted evaluated in
%the update burst function. Two examples are listed below. If none wanted
%simply leave customEval='';
customEval='';
% customEval{1}='sprintf(''Mean TauD: %f +/- %f \r\n'', mean(AllRecords(:,21)), std(AllRecords(:,21)));'; 
% customEval{2}='sprintf(''Some statistic: %f \r\n'', somefunction(AllRecords(:,someColumn)));'; 

%% Which graphs to plot during burst search
%One-D histograms
global Eraw_hist Sraw_hist TauD_hist burst_dur_hist InterBurst_hist
Eraw_hist=1;
Sraw_hist=1;
TauD_hist=1;
burst_dur_hist=1;
InterBurst_hist=1;

%Fluorescence Decay Histograms
global subens_fluorplot
subens_fluorplot=1;

%Anisotropy Decay Histograms
global subens_anisoplot
subens_anisoplot=1;

%2d histograms
global anisotau_hist SrawEraw_hist AsymE_hist
anisotau_hist=1;
SrawEraw_hist=1;
AsymE_hist=1;

%Trajector
global plotstate
plotstate=1;

%% Real Analysis Starts here:
StartPath='T:\'


%% Get the IRF, G-factor and Background
%Irf_APar
if ~KeepExpSet
if lifetime
	tmpA=ALEX;
    ALEX=0; %I know, this is hacky. Temporarily turn ALEX off to analyze IRF. Will fix later.
    [StartPath]=GetIRFmain(StartPath); %sets the global variables related to irf and time offsets
    ALEX=tmpA;
end

% Get calibration file - G factor
if pol
    [StartPath]=GetGfactMain(StartPath);
end

%Get the background file
if BKGFile
    [StartPath]=GetBKGMain(StartPath);
    fprintf('The background is')
    BKG
else
    BKG=[0 0 0 0 0 0];
end
end

%Save the workstate. Often multiple samples share same IRF, G-factor, Bkg.
save('ExpWorkState')

%% Final things to set up
[FileName,PathName,~] = uiputfile('*.txt','Save bursts as:');
fid_burst_txt=fopen([PathName FileName],'w');

RecordName=[PathName FileName]

FileNameSE1=strcat(FileName(1:end-4),'SE_',SE1NAME,'.txt');
FileNameSE2=strcat(FileName(1:end-4),'SE_',SE2NAME,'.txt');
FileNameSE3=strcat(FileName(1:end-4),'SE_',SE3NAME,'.txt');
FileNameSE4=strcat(FileName(1:end-4),'SE_',SE4NAME,'.txt');

if setLk
folder_name=uigetdir(StartPath,'Folder containing single molecule DONOR ONLY! experiment data');
else
folder_name=uigetdir(StartPath,'Folder containing single molecule experiment data');
end
d=dir(fullfile(folder_name,'*.bin'));
sync_count=0;

if exist('BurstInfo.mat','file')
delete('BurstInfo.mat')
end

global currName

%% Basic architecture: Loop through burst bin files in directory. Loop through chunks of photons with a bin file to find bursts.
%% Loop through bursts, calculating properties for each burst.

for i=1:numel(d) %Directory Loop
    
    tic;
    
    if talkative_burst
        fprintf('Analysing File %f of %f \r\n',i,numel(d))
        fprintf(d(i).name)
    end
    
    currName=d(i).name;
    
    [sync_count]= FileAnalysis_v2(strcat(folder_name,'\',d(i).name),sync_count);
   

    BurstInfoUpdate()
    if i>=numel(d)-1
        UpdateGraphsv3(1)
    else
        UpdateGraphsv3(0)
    end
    
    if lifetime
	%Write subsensemble .txt files
        fileID=fopen([PathName FileNameSE1],'w');
        edges_ss=0:1:4095;
        % size(subEns1_Dpar)
        % size(subEns1_Dperp)
        [PathName FileName]
        fprintf(fileID,'Gdd= %f \r\n',Gdd);
        fprintf(fileID,'Gaa= %f \r\n',Gaa);
        fprintf(fileID,'%f \t %f \t %f \t %f \t %f \r\n',[ edges_ss(:)*dt*1E9 subEns1_Dpar(:) subEns1_Dperp(:) subEns1_Apar(:) subEns1_Aperp(:)]');
        fclose(fileID);
        fileID=fopen([PathName FileNameSE2],'w');
        fprintf(fileID,'Gdd= %f \r\n',Gdd);
        fprintf(fileID,'Gaa= %f \r\n',Gaa);
        fprintf(fileID,'%f \t %f \t %f \t %f \t %f \r\n',[ edges_ss(:)*dt*1E9 subEns2_Dpar(:) subEns2_Dperp(:) subEns2_Apar(:) subEns2_Aperp(:)]');
        fclose(fileID);
        fileID=fopen([PathName FileNameSE3],'w');
        fprintf(fileID,'Gdd= %f \r\n',Gdd);
        fprintf(fileID,'Gaa= %f \r\n',Gaa);
        fprintf(fileID,'%f \t %f \t %f \t %f \t %f \r\n',[ edges_ss(:)*dt*1E9 subEns3_Dpar(:) subEns3_Dperp(:) subEns3_Apar(:) subEns3_Aperp(:)]');
        fclose(fileID);
                fileID=fopen([PathName FileNameSE4],'w');
        fprintf(fileID,'Gdd= %f \r\n',Gdd);
        fprintf(fileID,'Gaa= %f \r\n',Gaa);
        fprintf(fileID,'%f \t %f \t %f \t %f \t %f \r\n',[ edges_ss(:)*dt*1E9 subEns4_Dpar(:) subEns4_Dperp(:) subEns4_Apar(:) subEns4_Aperp(:)]');
        fclose(fileID);

    end
    
    plotstate=1; %return plotstate to 1, ie we want one trajectory per file
    memory
    
    te=toc;
    sprintf('Took %f seconds for file %d',te,i)
    
end %Directory Loop

if BVA
    %BVA has format where each column is a burst and the rows are the E
    %values for each window of nBVA photons.
    %The first value is the burstID, ie which row does it correspond to in
    %BurstRecord. The second value is the background uncorrected E value
    %Ebkg.
    %This is followed by runLength more values, even if the number of nBVA
    %long windows was less than runLength. Ie, it is padded by NaN.
    %Ie BVARecords is a matrix with (runLength+ 2) rows and (number of
    %bursts) columns.
[FileName,PathName,~] = uiputfile('*.txt','Save BVA record as:');
fid=fopen([PathName FileName],'w');
 fprintf(fid,[repmat('%f \t',1,size(BVARecord,2)) '\r\n'],BVARecord');
end
fclose all;



%% NOT RECOMMENDED. SAVE LK AND DIR CALCULATIONS FOR POST-ANALYSIS.
if setLk && ~getLk
        %par              %perp               %bkg par         %bkg perp
Fd=AllRecords(:,5)+AllRecords(:,6) - (AllRecords(:,11) + AllRecords(:,12)).*AllRecords(:,3);
    Fa=AllRecords(:,7)+AllRecords(:,8) - (AllRecords(:,13)+AllRecords(:,14)).*AllRecords(:,3);
    
    %from the background corrected donor and accepter counts in each burst
    %we now seek the ratio Lk=Fa/Fd for donor only sample. 
    
    vLk=Fa./Fd;
    
    Lk=mean(vLk);
    stdLk=std(vLk);
    

    save('LkMat','Lk')
    fprintf('=========================================== \r\n')
        fprintf('=========================================== \r\n')
    fprintf('The calculated and saved leakage is %0.3f \r\n',Lk)
    
end

fprintf('\r\n DONE \r\n')
fprintf('\r\n Last File Analyzed: \r\n')
d(i).name
fprintf('\r\n Burst Record Saved as: \r\n')
RecordName

end

