function [ output_args ] = AnalyzeCNTRate( input_args )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

close all
clear all
clc
fclose all

%% Global Variables for Picoharp and Router
global ind_Dpar ind_Dperp ind_Apar ind_Aperp ind_Dexc ind_Aexc numRecords ALEX talkative numChunks numFiles dt T3mode
ind_Dpar = 1;
ind_Dperp = 2;
ind_Apar = 3;
ind_Aperp = 4;

% ind_Dpar = 0; %For T2 mode there is usually only two inputs, so just arrange like this.
% ind_Apar = 1;
% ind_Aperp = 4;
% ind_Dperp = 3;

ind_Dexc = 13; %Router channel 2 (ind=15-router channel = 13)
ind_Aexc = 11; %Router channel 3 (ind=15-router channel = 11)
numRecords = 1000; %Number of records to process at a time.
numChunks=[]; %How many chunks of size numRecords do you want to process?
               %if empty, will process all chunks!
numFiles = []; %Number of bin files from directory to process, if empty process all.               
ALEX = 1; %Will seperate photons in burst by their excitation source
talkative=1;
T3mode=0;

global dtTraj avgtime PCHbinWidth PCHEndBin PCHdd PCHad PCHaa

% gatetimeD=1.75/dt;
% gatetimeA=0.6/dt;
avgtime=25E-6;
dtTraj=5E-3; %timestep used in creating a trajectory
PCHbinWidth=1;
PCHEndBin=50;
PCHbins=0:PCHbinWidth:PCHEndBin;
PCHdd=zeros(size(PCHbins));
PCHad=zeros(size(PCHbins));
PCHaa=zeros(size(PCHbins));

StartPath='Z:\';
[folder_name] = GetCNTRATEMain2(StartPath)
fclose all
end

