
close all

global Gdd k1 k2
Gdd=1;
k1=0.33; %Applied to rDD but also to rAA - these may be PSF and thus wavelength dependent. Other groups only use one set - so maybe effect is small.
k2=0.065;



%% Find Data
format = repmat('%f', [1 3]); %format for textscan for how many columns, user can change in ui.
hl=0; %header lines in textfiles
dt=0.004;

[FileName,PathName] = uigetfile('*.txt','Select the data file');
%To replace with a permament location of text file:
%Example: PathName='E:\May 22 Data\';
%Example:FileName='IRF.txt';

disp('Now analyzing:')
disp(FileName)

% Read the file into matrix
fid = fopen(strcat(PathName,FileName));
DATA=textscan(fid,format,'headerlines',hl);
%close(fid)
t=DATA{1}; %A
t=t';

Dpar=DATA{2};
Dperp=DATA{3};
% yPAR(t>25)=[];
% yPERP(t>25)=[];

plot((0:4095)*dt,Aniso(Dpar,Dperp,'D',[]));
        xlabel('t (ns)')
        ylabel('Anisotropy (No bkg Corr)')
%         legend('SubEnsemble1','SubEnsemble2')  
%  ylim([-0.1 0.5])
 xlim([1.5 12])
%  axis tight


[FileName,PathName] = uigetfile('*.txt','Select the data file');
%To replace with a permament location of text file:
%Example: PathName='E:\May 22 Data\';
%Example:FileName='IRF.txt';

disp('Now analyzing:')
disp(FileName)

% Read the file into matrix
fid = fopen(strcat(PathName,FileName));
DATA=textscan(fid,format,'headerlines',hl);
%close(fid)
t=DATA{1}; %A
t=t';

Dpar=DATA{2};
Dperp=DATA{3};
% yPAR(t>25)=[];
% yPERP(t>25)=[];

hold all
plot((0:4095)*dt,Aniso(Dpar,Dperp,'D',[]));
        xlabel('t (ns)')
        ylabel('Anisotropy (No bkg Corr)')
%         legend('SubEnsemble1','SubEnsemble2')  
%  ylim([-0.1 0.5])
 xlim([1.5 12])
%  axis tight
legend('P18','A488')