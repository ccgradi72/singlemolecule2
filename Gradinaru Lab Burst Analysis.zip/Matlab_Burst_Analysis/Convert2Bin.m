function [  ] = Convert2Bin(filename,index,sstime,timetag)
%UNTITLED4 Summary of this function goes here
%   Convert index, sstime, and timetag into 32 bit numbers and perform bit
%   shifting and bitor to coerce them into one 32 bit number in the
%   required picoharp format.
% clc;
% close all
% clear all;

index=uint32(index);
sstime=uint32(sstime);
timetag=uint32(timetag);

index=bitshift(index,+28);
sstime=bitshift(sstime,+16);

T3Record=bitor(sstime,timetag,'uint32');
T3Record=bitor(index,T3Record,'uint32');

fid=fopen(filename,'a');
fwrite(fid,T3Record,'ubit32',0,'l'); %little endian, skip 0 bits
fclose(fid);

    

end

