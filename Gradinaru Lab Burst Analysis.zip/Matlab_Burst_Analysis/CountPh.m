function [numM1,numM2] = CountPh(index,sstime,timetag,M)
%UNTITLED2 Summary of this function goes here
%   Count the number of photons of each excitation type

%The simulation always starts with M1 and ends with M2 - giving equal
%number of green and red excitation periods.

%However, in a real experiment, the burst isn't always synchronized with
%the markers.

%Thus trim burst was used to get rid of photons from the beginning and end
%of the burst.

%There are four possible cases since the markers are not synced with the
%beginning of the burst.
%CASE1: The first and last marker are type M1
%CASE2: The first marker is M1, the last marker is M2
%CASE3: The first and last marker are type M2
%CASE4: The first marker is M2, the last marker is M1

locM1=find(index==15 & sstime==M(1)); %location of M1 markers
locM2=find(index==15 & sstime==M(2));

if locM1(1)<locM2(1)
    if locM1(end)>locM2(end)
        %CASE1
        numM1=sum([locM2 length(index)]-locM1)-length(locM1);
        numM2=length(index)-numM1-length(locM1)-length(locM2);
    else
        %CASE2
        numM1=sum(locM2-locM1)-length(locM1); 
        numM2=length(index)-numM1-length(locM1)-length(locM2);
    end
else
    if locM2(end)>locM1(end)
        %CASE3
        numM2=sum([locM1 length(index)]-locM2)-length(locM2);
        numM1=length(index)-numM2-length(locM1)-length(locM2);
    else
        %CASE4
        numM2=sum(locM1-locM2)-length(locM2); 
        numM1=length(index)-numM2-length(locM1)-length(locM2);
    end
end



end

