function []=DynamicAveraging()

close all
clear all
clc

fs=18;
fsa=15;
lw=2;

coeff='100rhc4';
Ro=5.1; %nm
Rg0=[0.75:0.1:15];
lp=linspace(0.05,10,length(Rg0));
LimSAW=5;
TauDAav=zeros(size(Rg0));
IntAvE=zeros(size(Rg0));
TauD=3.76; %ns
lc=90*0.38;

dr=0.05;
r=0:dr:4.5*max(Ro);

Er=1./(1+(r/Ro).^6);

% figure;
% plot(r,Er)

for j=1:length(Rg0)

% [PrRgOUT,w,rc]=PrSim(r,Rg0(j)^2)
[PrRgOUT]=PrGaussianChain(r,Rg0(j)^2);

Io=10;
% R=sqrt(6)*Rg;
% Pr=4*pi*(r.^2).*((3/(2*pi*(R^2)))^(3/2)).*exp(-(3/2)*((r/R).^2));
% figure;
% plot(r,PrRgOUT)
PrGC=PrRgOUT;
[PrRgOUT,w,rc]=PrSim(r,Rg0(j)^2);
PrSAW=PrRgOUT;
[PrRgOUT]=PrWLC(r,lp(j));
Pr_WLC=PrRgOUT;

EGC(j)=trapz(r,PrGC.*Er)
ESAW(j)=trapz(r,PrSAW.*Er)
EWLC(j)=trapz(r,Pr_WLC.*Er)

t=0:0.1:25; %ns

It=zeros(size(t));
for i=1:length(t)
TauR=TauD*(1-Er);
temp=PrGC.*exp(-t(i)./TauR);
temp(isnan(temp))=0;
ItGC(i)=Io*trapz(r,temp);
temp=PrSAW.*exp(-t(i)./TauR);
temp(isnan(temp))=0;
ItSAW(i)=Io*trapz(r,temp);
temp=Pr_WLC.*exp(-t(i)./TauR);
temp(isnan(temp))=0;
ItWLC(i)=Io*trapz(r,temp);

end



temp=t.*ItGC;
temp(isnan(temp))=0;
TauDAavGC(j)=(trapz(t,temp))/trapz(t,ItGC);

temp=t.*ItSAW;
temp(isnan(temp))=0;
TauDAavSAW(j)=(trapz(t,temp))/trapz(t,ItSAW);

temp=t.*ItWLC;
temp(isnan(temp))=0;
TauDAavWLC(j)=(trapz(t,temp))/trapz(t,ItWLC);


% LifetimeAvE(j)=1-(TauDAav(j)/TauD);

end

ESAW(Rg0>LimSAW)=[];
TauDAavSAW(Rg0>LimSAW)=[];

figure;
hold all
plot(EGC,TauDAavGC/TauD,'-k');
plot(ESAW,TauDAavSAW/TauD,'-r');
plot(EWLC,TauDAavWLC/TauD,'-g');
xlim([0 1])
ylim([0 1])
xlabel('E')
ylabel('\tau_DA/\tau')

% figure;
% plot(Rg0,EGC)

fitE=0.35;
L=50;
wshot=sqrt((fitE.*(1-fitE))/L) %from beta dist
wshot2=(1/sqrt(L))*(fitE*sqrt(1-fitE) + (1-fitE)*sqrt(fitE)) %poiss?

w=wshot;
wt=0.5;

% NumBursts=1000;
% for k=1:NumBursts
% Erand(k) = normrnd(fitE,w);
% tmp=abs(EGC-Erand(k));
% [idx idx]=min(tmp);
% tmp=TauDAavGC(idx);
% tauRand(k) = normrnd(tmp,wt);
% end
% 
% scatter(Erand,tauRand/TauD)
% 
% figure;
% hist(tauRand)


NumBursts=10000;
for k=1:NumBursts
Erand(k) = normrnd(fitE,w);
tmp=abs(EGC-fitE);
[idx idx]=min(tmp);
tmp=TauDAavGC(idx);
tauRand(k) = normrnd(tmp,wt);
end

figure;
plot(Rg0,EGC)

% scatter(Erand,tauRand/TauD)

% figure;
% hist(tauRand)

% figure;
% [hCont,hx ,hy,hMain] =Histogram2d(Erand,tauRand/TauD,[0 1],[0 1],20,20,10,'$\rm E$','$\rm \tau_{DA}/\tau$',[],[],[0 0.25 0.5 0.75 1],[0 0.25 0.5 0.75 1],{'0','0.25','0.5','0.75','1'},{'0','0.25','0.5','0.75','1'});
% plot(hMain,EGC,TauDAavGC/TauD,'r')
% plot(hMain,ESAW,TauDAavSAW/TauD,'g')

figure;
ndhist(Erand,tauRand/TauD,'axis',[-0.1 1.05 -0.1 1.1],'binsx',0.5,'binsy',0.5,'filter',5);

figure;
% [edgesX2,edgesY2,N] =ndhist(Erand,tauRand/TauD,'axis',[-0.1 1.05 -0.1 1.1],'filter',5,'binsx',0.5,'binsy',0.5);
[edgesX2,edgesY2,N] =ndhist(Erand,tauRand/TauD,'axis',[-0.1 1.05 -0.1 1.1],'binsx',0.5,'binsy',0.5);
% [edgesX2,edgesY2,N] =ndhist(Erand,tauRand/TauD,'axis',[-0.05 1.05 -0.05 1.05]);

TauRAT=TauDAavGC/TauD;
save('DynLines.mat','EGC','TauRAT','Rg0')

figure;
hold all
[AX,H1,H2]=plotyy(EGC,TauRAT,EGC(EGC<0.8 &EGC>0.2),Rg0(EGC<0.8 &EGC>0.2))

% end

figure;
subplot(2,2,2); 
[Cm,hCont]=contourf(edgesX2,edgesY2,N,5);
cm=flipud(gray);
colormap(cm);
hold on
h1=gca;

% a2=axes('XAxisLocation','Top')
% set(a2,'color','none')
% set(a2,'YTick',[])
% set(a2,'XTick',Rg0)

hLine1 = line(h1,Rg0,TauDAavGC/TauD,'color','k');
Ax1 = gca;
Ax2 = axes('Position',get(Ax1,'Position'),...
           'XAxisLocation','top');
hLine2 = line(EGC,TauDAavGC/TauD,'color','k','parent',Ax2);


plot(h1,EGC,TauDAavGC/TauD,'r','LineWidth',lw)
plot(h1,EGC,1-EGC,'k','LineWidth',lw)
% plot(ESAW,TauDAavSAW/TauD,'g')



hXLabel = xlabel('E');
hYLabel = ylabel('\tau_{DA}/\tau');
set( gca                       , ...
    'FontSize'   , fsa          ,...
    'FontName'   , 'Helvetica' );
set([hXLabel, hYLabel], ...
    'FontName'   , 'Helvetica');
set([hXLabel, hYLabel]  , ...
    'FontSize'   , fs          );
% hMain=gca;
set(gca, ...
  'Box'         , 'on'     , ...
  'TickDir'     , 'in'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'      , ...
  'YMinorTick'  , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'XColor'      , [.1 .1 .1], ...
  'YColor'      , [.1 .1 .1], ...
  'YTick'       , [0:0.2:1], ...
  'XTick'       , [0:0.2:1], ...
  'LineWidth'   , 1         );
getxlim=xlim();
getylim=ylim();

% [AX,H1,H2]=plotyy(EGC,TauRAT,EGC(EGC<0.8 &EGC>0.2),Rg0(EGC<0.8 &EGC>0.2))
% ylim(AX(1),getylim)
% xlim(AX(1),getxlim)
% xlim(AX(2),getxlim)

subplot(2,2,4);
bar(edgesX2(1:end),sum(N,1),1,'FaceColor', 'k');
hx = gca; 
% h2YLabel=ylabel();
xlim(getxlim); %links the x axis to that of the contour plot
% tmp=ylim(gca);
% y_lim=tmp(2);
ylim([0 1500])

set(gca, ...
    'Box'         , 'on'     , ...
    'TickDir'     , 'in'     , ...
    'TickLength'  , [.02 .02] , ...
    'XMinorTick'  , 'off'      , ...
    'YMinorTick'  , 'off'      , ...
    'YGrid'       , 'off'      , ...
    'XColor'      , [.1 .1 .1], ...
    'YColor'      , [.1 .1 .1], ...
    'XTick'       , [0:0.2:1], ...
    'XTickLabel'  , [], ...
    'YTick'       , [500 1500], ... 
    'LineWidth'   , 1         );


set( gca                       , ...
    'FontSize'   , fsa          ,...
    'FontName'   , 'Helvetica' );
% set([h2YLabel], ...
%     'FontName'   , 'Helvetica');
% set(h2YLabel, ...
%     'FontSize'   , fs        );


subplot(2,2,1); 
hold on
barh(edgesY2,sum(N,2),1,'FaceColor', 'k'); 
hy = gca; 
ylim(getylim)

tmp=xlim(gca);
x_lim=tmp(2);
xlim([0 1500])
% h3XLabel=xlabel('');
set(gca, ...
  'Box'         , 'on'     , ...
  'TickDir'     , 'in'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'      , ...
  'YMinorTick'  , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'XColor'      , [.1 .1 .1], ...
  'YColor'      , [.1 .1 .1], ...
  'YTick'       , [0:0.1:1], ... 
  'YTickLabel'  , [], ...
    'XTick'       , [500 1500], ... 
  'LineWidth'   , 1         );


set( gca                       , ...
    'FontSize'   , fsa          ,...
    'FontName'   , 'Helvetica' );
% set(h3XLabel, ...
%     'FontName'   , 'Helvetica');
% set(h3XLabel, ...
%     'FontSize'   , fs        );



% [left bottom width height]The left and bottom elements define the 
%distance from the lower-left corner of the container to the lower-left 
%corner of the axes. The width and height elements are the axes dimensions.

L= 0.15; %left
B= 0.15; %bottom
W= 0.6; %2d histogram width (shared with marginal x width)
H=0.6; %2d histogram heigh (shared with marginal y height)
mH=0.17; %marginal histogram height

% gap=0.03;
gapv=0.0;
gaph=0.0;

set(h1,'Position',[L B W H]); %main 2d histogram and overlay

%x marginal histogram shares its left edge with 2d hist and has same width
set(hx,'Position',[L B+H+gapv W mH]); 
%y marginal histogram shares its bottom edge with 2d hist and has same
%height
set(hy,'Position',[L+W+gaph B mH H]); %y marginal histogram
set(gcf, 'PaperPositionMode', 'manual');

set(gcf,'PaperUnits','inches');
papersizex=6;
papersizey=5;
marginx=0.5;
marginy=0.5;
% fontsizeax=12;
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
           papersizey-2*(marginy)]);
set(gcf, 'color', 'w');

print('-dpng','-r600','EvsTau'); %save in same directory as input data

% figure;

% bar(edgesX2(1:end),sum(N,1))


function [PrRgOUT,w,rc]=PrSim(r,Rg2)
        
        
        C=2.02;  %Need to change this
        switch coeff
            case '90'
                %the original n=90 SAW
                Z1=-183.13063;
                B1=25.48613;
                B2=-1.08508;
                B3=0.01984;
                B4=-1.34651E-4;
                
                Z2=3.84207;
                ro=-37.14671;
                
            case '100'
                %the n100 SAW simulations
                Z1=-131.88027;
                B1=15.96999;
                B2=-0.48643;
                B3=0.00434;
                B4=1.0139E-5;
                
                Z2=3.77306;
                ro=-40.08632;
                
            case '100rhc4'
                 %the n100 SAW simulations with r_hc=3.14 angstrom
                Z1=-120.07183;
                B1=15.85754;
                B2=-0.52925;
                B3=0.00531;
                B4=1.02129E-5;
                
                Z2=3.73203;
                ro=-36.02189;
                
            case '100rhc3.14'
                %the n100 SAW simulations with r_hc=3.14 angstrom
                Z1=-107.95168;
                B1=15.29116;
                B2=-0.54329;
                B3=0.00584;
                B4=1.14823E-5;
                
                Z2=3.65224;
                ro=-32.01995;
                
            case 'GaussSim'
                %the n100 Gauss simulation
                Z1=1.68789;
                B1=-0.06726;
                B2=0.37797;
                B3=-0.02918;
                B4=6.38106E-4;
                
                Z2=3.10758;
                ro=-11.85742;
                
             case 'SH3'
                %the n100 Gauss simulation
                Z1=-127.72338;
                B1=22.87784;
                B2=-1.23328;
                B3=0.02843;
                B4=-2.41769E-4;
                
                Z2=3.73356;
                ro=-27.22449;   
                
                
        end
        Rg=sqrt(Rg2); %this will need to be converted to Angstrom (since Jianhui's results are in angstrom)
        
        Rg=Rg*10;
        r=r.*10;
        
        
        w=Z1+B1*Rg + B2*Rg^2 + B3*Rg^3 + B4*Rg^4;
        rc=ro+Z2*Rg;
        
        PrCond1=C/(w*sqrt(pi/2));
        PrCond2=exp(-2*(1/w^2)*(r-rc).^2);
        
        PrRgOUT=PrCond1*PrCond2;
        PrRgOUT=PrRgOUT/trapz(r/10,PrRgOUT); %normalize to unit area
        
    end
  function [PrRgOUT]=PrGaussianChain(r,Rg2)
        PrRg1=4*pi*r.^(2);
        PrRg2=(1/(4*pi*Rg2))^(1.5);
        PrRg3=exp(-(r.^2)/(4*Rg2));
        PrRgOUT=PrRg1.*PrRg2.*PrRg3;
  end

 function [PrRgOUT]=PrWLC(r,lp)
      PrRg1=4*pi*(r/lc).^2;
      PrRg2=lc*(1-(r/lc).^2).^(9/2);
      PrRg3=exp(-3*lc./(4*lp*(1-(r/lc).^2)));
      PrRgOUT=(PrRg1./PrRg2).*PrRg3;
      PrRgOUT=PrRgOUT/trapz(r,PrRgOUT);
    end
end