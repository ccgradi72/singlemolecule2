clc
clear all
close all

% S=[0.66 0.61];
% S=[0.65 0.62];

% E=[0.212 0.5981]
% S=[0.653 0.6048]
% 
% E=[0.203 0.6252]
% S=[0.6381 0.6041]
% 
% E=[0.2033 0.6292]
% S=[0.6265 0.6089]
% 
% E=[0.2136 0.6232]
% S=[0.5783 0.5737]



% E=[0.227 0.713]
% S=[0.564 0.553]

% E=[0.227 0.713]
% S=[0.595 0.578]

% E=[0.214 0.709]
% S=[0.62 0.595]

E=[0.214 0.709]
S=[0.635 0.611]




% S=interp1(E,S,[0.73 0.5 0.2151])
% E=[0.73 0.5 0.2151]

sigmaS=[0.003 0.003];

% S=[0.67 0.6];
% E=[0.2 0.62];
% E=[0.19 0.63];

% S=[0.6519 0.6296];
% E=[0.1986 0.6910];
% S=

x=E;
y=1./S;
% sigmaS=[0.02 0.02];

sigm=y.*(sigmaS./S);



A=[x;ones(1,length(x))];
p=y/A;
mfit=p(1)
bfit=p(2)


x=linspace(0,1,100);
A=[x;ones(1,length(x))];
f=p*A; %the best fit function using best fit m and b

gamma=(bfit-1)/(bfit+mfit-1)

figure;
hold all
plot(x,f,'k','linewidth',3)
errorbar(E,1./S,sigm,'ko','MarkerFaceColor','r','MarkerSize',10,'linewidth',2)
title(sprintf('Gamma=%f',gamma))
xlim([0 1])
xlabel('Eapp')
ylabel('1/Sapp')
box on




%% OLLS

x=E;
y=1./S;


sigm=y.*(sigmaS./S);
yo=y;

A=[x;ones(1,length(x))];
p=yo/A;
mfit=p(1);
bfit=p(2);

f=p*A; %the best fit function using best fit m and b
res=(yo-f);
wres=(yo-f)./sigm;
redchisq=sum(wres.^2)/length(yo);

sigm_yEST=sqrt((1/(length(yo)-2))*sum(res.^2));
Del=length(yo)*sum(x.^2)-(sum(x))^2;
err_b=sigm_yEST*sqrt(sum(x.^2)/Del);
err_m=sigm_yEST*sqrt(length(yo)/Del);

figure;
subplot(2,1,1)
hold on
errorbar(x,yo,sigm,'ko')
plot(x,f,'-k')
subplot(2,1,2)
plot(x,wres)
ylabel('Weighted Residuals')
title('Linear Least Squares')

fprintf('Ordinary Linear Least Squares Fitting: \r\n');
fprintf('The fitted slope is %.2f +/- %.2f \r\n',mfit,err_m);
fprintf('The fitted y-intercept is %.2f +/- %.2f \r\n',bfit,err_b);
fprintf('The mean weighted residual is %.2f \r\n',mean(wres));
fprintf('The std of the weighted residuals is %.2f \r\n',std(wres));
fprintf('The reduced chi squared %.2f \r\n',redchisq);
fprintf('---------------------------------- \r\n');

%% WLLS

w=1./(sigm.^2);
pw=lscov(A',yo',w);

fw=A'*pw;
wres=(yo-fw')./sigm;
redchisq=sum(wres.^2)/length(yo);

DEL=sum(w)*sum(w.*(x.^2)) - (sum(w.*x))^2;
err_b=sqrt(sum(w.*(x.^2))/DEL);
err_m=sqrt(sum(w)/DEL);

figure;
subplot(2,1,1)
hold on
errorbar(x,yo,sigm,'ko')
plot(x,fw,'-r')
title('Weighted Linear Least Squares')
legend('data','fit (weighted)')
subplot(2,1,2)
plot(x,wres)
ylabel('Weighted Residuals')

fprintf('Weighted linear least squares fitting: \r\n');
fprintf('The (wls) fitted slope is %.2f +/- %.2f \r\n',pw(1),err_m);
fprintf('The (wls) fitted y-intercept is %.2f +/- %.2f \r\n',pw(2),err_b);
fprintf('The (wls) mean weighted residual is %.2f \r\n',mean(wres));
fprintf('The (wls) std of the weighted residuals is %.2f \r\n',std(wres));
fprintf('The (wls) reduced chi squared %.2f \r\n',redchisq);


b=pw(2)
m=pw(1)
dfdb=b/((b+m-1)^2);
dfdm=(1-b)/((b+m-1)^2);

uncgamma=sqrt((dfdb^2)*(err_b^2) + (dfdm^2)*(err_m^2))
gamma=(b-1)/(b+m-1)

