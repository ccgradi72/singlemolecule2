function [ Epr ] = Eraw2Epr( Eraw,gamma,Lk,di)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

if isempty(gamma)
    gamma=1;
end
if isempty(Lk)
    Lk=0;
end
if isempty(di)
    di=0;
end

Epr=(Eraw*(Lk+di*gamma+1)-Lk-di*gamma)./(Eraw*(Lk-gamma+1)-Lk+gamma);


end

