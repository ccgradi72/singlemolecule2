function []=Explore_Burst_Subensemble()

close all
global Gdd k1 k2 Gaa
k1=0.33; %Applied to rDD but also to rAA - these may be PSF and thus wavelength dependent. Other groups only use one set - so maybe effect is small.
k2=0.065;
Gaa=1;
coff=-35
coffApar=0
coffAperp=0
coffApar=0
coffAperp=0

[FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    hl=2;
    IMPORT = importdata(strcat(PathName,FileName),delimiterIn,hl);
    fprintf('Finished loading and saving %s from text file\r\n',FileName)
    
%     fprintf(fileID,'%f \t %f \t %f \t %f \t %f \r\n',

Gdd=str2double(regexp(IMPORT.textdata{1},'(\d+(?:\.\d*))','Match'));
% Gaa=str2double(regexp(IMPORT.textdata{2},'(\d+(?:\.\d*))','Match'));
    t=IMPORT.data(:,1);
I_Dpar=IMPORT.data(:,2);
I_Dpar=circshift(I_Dpar,[coff,1]);
I_Dperp=IMPORT.data(:,3);
I_Apar=IMPORT.data(:,4);
I_Apar(I_Apar==0)=[];
I_Apar=circshift(I_Apar,[coffApar,1]);
I_Aperp=IMPORT.data(:,5);
I_Aperp(I_Aperp==0)=[];
I_Aperp=circshift(I_Aperp,[coffAperp,1]);

if length(I_Apar)<length(I_Aperp)
    I_Aperp=I_Aperp(1:length(I_Apar));
    sprintf('Warning Itotal(): Iperp clipped due to shorter length of Ipar')
elseif length(I_Aperp)<length(I_Apar)
    I_Apar = I_Apar(1:length(I_Aperp));
    sprintf('Warning Itotal(): Ipar clipped due to shorter length of Iperp')
end

figure;
plot(I_Dpar)
hold all
plot(I_Dperp)
set(gca,'YScale','log')

figure;
plot(I_Apar)
hold all
plot(I_Aperp)
set(gca,'YScale','log')

 I_D1=Itotal(I_Dpar,I_Dperp,'D');
 I_A1=Itotal(I_Apar,I_Aperp,'A');
 r_D1=Aniso(I_Dpar,I_Dperp,'D',[]);
 r_A1=Aniso(I_Apar,I_Aperp,'A',[]);

mtauD1=sum(t(1:length(I_D1)).*I_D1')/sum(I_D1)
mtauA1=sum(t(1:length(I_A1)).*I_A1')/sum(I_A1)

% figure;
%  ttD=t(1:length(I_D1));
%  ttA=t(1:length(I_A1));
% hold all
% plot(I_D1)
% plot(I_A1)
% set(gca,'YScale','log')

% figure;
% plot(r_D1)
 
%  return
 
 
 [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    hl=2;
    IMPORT = importdata(strcat(PathName,FileName),delimiterIn,hl);
    fprintf('Finished loading and saving %s from text file\r\n',FileName)
    
%     fprintf(fileID,'%f \t %f \t %f \t %f \t %f \r\n',

Gdd=str2double(regexp(IMPORT.textdata{1},'(\d+(?:\.\d*))','Match'));
% Gaa=str2double(regexp(IMPORT.textdata{2},'(\d+(?:\.\d*))','Match'));
    t=IMPORT.data(:,1);
I_Dpar=IMPORT.data(:,2);
I_Dpar=circshift(I_Dpar,[coff,0]);
I_Dperp=IMPORT.data(:,3);
I_Apar=IMPORT.data(:,4);
I_Apar(I_Apar==0)=[];
I_Apar=circshift(I_Apar,[coffApar,1]);
I_Aperp=IMPORT.data(:,5);
I_Aperp(I_Aperp==0)=[];
I_Aperp=circshift(I_Aperp,[coffAperp,1]);

if length(I_Apar)<length(I_Aperp)
    I_Aperp=I_Aperp(1:length(I_Apar));
    sprintf('Warning Itotal(): Iperp clipped due to shorter length of Ipar')
elseif length(I_Aperp)<length(I_Apar)
    I_Apar = I_Apar(1:length(I_Aperp));
    sprintf('Warning Itotal(): Ipar clipped due to shorter length of Iperp')
end


 I_D2=Itotal(I_Dpar,I_Dperp,'D');
 I_A2=Itotal(I_Apar,I_Aperp,'A');
 r_D2=Aniso(I_Dpar,I_Dperp,'D',[]);
 r_A2=Aniso(I_Apar,I_Aperp,'A',[]); 
 
 mtauD2=sum(t(1:length(I_D2)).*I_D2')/sum(I_D2)
mtauA2=sum(t(1:length(I_A2)).*I_A2')/sum(I_A2)

 
 figure;
 plot(t,I_D1/sum(I_D1),t,I_D2/sum(I_D2))
 set(gca,'YScale','log')

  figure;
 plot(t,r_D1,t,r_D2)
 ylim([-0.1 0.5])
 xlim([1.52 10])

 
 
%  figure;
%  tt1=t(1:length(I_A1));
%  tt2=t(1:length(I_A2));
%  plot(tt1,I_A1/sum(I_A1),tt2,I_A2/sum(I_A2))
%  set(gca,'YScale','log')
% 
%   figure;
%  plot(t(1:length(I_A1)),r_A1,t(1:length(I_A2)),r_A2)
%  ylim([-0.1 0.5])
%  xlim([1.52 10])
%  
%  
%  figure;
%  x=tt1(tt1>5&tt1<9);
%  y=log(I_A1(tt1>5&tt1<9));
%  plot(x,y)
% 
%   figure;
%  x=tt2(tt2>5&tt2<9);
%  y=log(I_A1(tt2>5&tt2<9));
%  plot(x,y)
% 
 
end