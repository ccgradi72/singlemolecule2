function [synccount] =FileAnalysisBkg(PathFileName,synccount)
%UNTITLED2 Summary of this function goes here
%   Called by GetIRFMain's directory loop.
% Reads current T3 file of the loop, in chunks of numRecords.


%% Global Variables for Picoharp and Router
global ind_Dpar ind_Dperp ind_Apar ind_Aperp ind_Dexc ind_Aexc numRecords
%% Global Variables for Work flow
global ALEX talkative
%% Global Variables for Lifetime
global cal_DPar cal_DPerp dt MinPhCal draw_microtimeG cal_APar cal_APerp dtTraj

global BKG

%% Find the lvm file to get timing information
PathFileNameLVM=PathFileName;
PathFileNameLVM(end-3:end)='.lvm';

% Read the file into matrix
fid = fopen(PathFileNameLVM);
DATA=textscan(fid,'%f','HeaderLines',23);
dt=DATA{1}(4)/1000; %in ns
dt=dt*1E-9; %now in seconds
f0=DATA{1}(5);
Tpp=1/f0; %in seconds
fclose(fid);

%% Read the file of interest and process in chunks of numRecords

data=dir(PathFileName);
filesize=(data.bytes)/4; %4bytes is one uint32 record.
if numRecords>filesize
    errordlg('NumRecords is too big')
    return
end

numLoops=floor(filesize/numRecords);
%did we miss any records from uneven division?
missRecords=mod(filesize,numRecords);
fid=fopen(PathFileName,'r');

BddPar=0;
BddPerp=0;
BadPar=0;
BadPerp=0;
BaaPar=0;
BaaPerp=0;
 figure;
for i=1:150 %File Reading Loop I only go up to 150 since background doesn't get much more accurate after this many chunks
    
    if talkative && ~mod(i,50)
    sprintf('Analysing BKG T3Records Chunk %f of %f',i,numLoops)
    end
    
%     [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,numRecords);
    [ind,sstime,timetag,synccount] = ReadT3FilesDouble_chunky(fid,Tpp,dt,synccount,numRecords);
    
    
    if ALEX
        UniqueInd=unique(ind)
        
        if isempty(UniqueInd(UniqueInd==ind_Dexc))
        continue
        end
        [indDexc,sstimeDexc,timetagDexc,indAexc,sstimeAexc,timetagAexc] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]);
       
        
        
        BddPar=length(indDexc(indDexc==ind_Dpar));
        BddPerp=length(indDexc(indDexc==ind_Dperp));
        BadPar=length(indDexc(indDexc==ind_Apar));
        BadPerp=length(indDexc(indDexc==ind_Aperp));
        
        BaaPar=length(indAexc(indAexc==ind_Apar));
        BaaPerp=length(indAexc(indAexc==ind_Aperp));
    else
        
        BddPar=length(ind(ind==ind_Dpar));
        BddPerp=length(ind(ind==ind_Dperp));
        BadPar=length(ind(ind==ind_Apar));
        BadPerp=length(ind(ind==ind_Aperp));
        
        BaaPar=0;
        BaaPerp=0;
        
    end
    
deltaT=timetag(end)-timetag(1);
if deltaT<0.1
    continue %skip the rest and carry with next iteration
end
Bdd_par(i) =BddPar/deltaT;
Bdd_perp(i)=BddPerp/deltaT;
Bad_par(i) = BadPar/deltaT;
Bad_perp(i) = BadPerp/deltaT;
Baa_par(i) =BaaPar/deltaT;
Baa_perp(i)= BaaPerp/deltaT;


% mean(Bdd_par)
% mean(Bdd_perp)
% mean(Bad_par)
% mean(Bad_perp)
% mean(Baa_par)
% mean(Baa_perp)
    
           if i==numLoops
            if ~ALEX
            %     dtTraj=500E-6;
            edges=min(timetag(ind~=15)):dtTraj:max(timetag(ind~=15));
            
            TrajG=histc(timetag(ind==ind_Dpar | ind==ind_Dperp),edges);
            TrajR=histc(timetag(ind==ind_Apar | ind==ind_Aperp),edges);
            hold all
            plot(edges,TrajG,'g',edges,-1*TrajR,'r')
            plot(edges,-(Bad_par(i)+Bad_perp(i))*dtTraj*ones(size(edges)),'k')
            plot(edges,(Bdd_par(i)+Bdd_perp(i))*dtTraj*ones(size(edges)),'k')
            myylabel=sprintf('Photon Counts, %.3f \\mus bins',dtTraj*1E6);
            ylabel(myylabel)
            xlabel('time(s)')
            title('BKG estimate in black')
            axis tight
            xlim( [edges(1) edges(end)])
            hold off
            else

            edges=min(timetag(ind~=15)):dtTraj:max(timetag(ind~=15));
%             length(edges)
            TrajGG=histc(timetagDexc(indDexc==ind_Dpar | indDexc==ind_Dperp),edges);
            TrajRG=histc(timetagDexc(indDexc==ind_Apar | indDexc==ind_Aperp),edges);
            TrajRR=histc(timetagAexc(indAexc==ind_Apar | indAexc==ind_Aperp),edges);
            TrajGR=histc(timetagAexc(indAexc==ind_Dpar | indAexc==ind_Dperp),edges);
            
            subplot(2,1,1)
            hold all
            plot(edges,TrajGG,'g',edges,-1*TrajRG,'r')
            plot(edges,-(Bad_par(i)+Bad_perp(i))*dtTraj*ones(size(edges)),'k')
            plot(edges,(Bdd_par(i)+Bdd_perp(i))*dtTraj*ones(size(edges)),'k')
            myylabel=sprintf('Photon Counts, %.3f \\mus bins',dtTraj*1E6);
            ylabel(myylabel)
            xlabel('time(s)')
            title('Donor Excitation Bkg Est')
            axis tight
            xlim( [edges(1) edges(end)])
            hold off
            subplot(2,1,2)
            hold all
            plot(edges,TrajGR,'g',edges,-1*TrajRR,'r')
            plot(edges,-(Baa_par(i)+Baa_perp(i))*dtTraj*ones(size(edges)),'k')
            myylabel=sprintf('Photon Counts, %.3f \\mus bins',dtTraj*1E6);
            ylabel(myylabel)
            xlabel('time(s)')
            title('Acceptor Excitation Bkg Est')
            axis tight
            xlim( [edges(1) edges(end)])
            hold off
            
            end
            drawnow
    
           end
    
       
end %File Reading Loop

Bdd_par =mean(Bdd_par);
Bdd_perp=mean(Bdd_perp);
Bad_par = mean(Bad_par);
Bad_perp = mean(Bad_perp);
Baa_par =mean(Baa_par);
Baa_perp= mean(Baa_perp);


BKG=[Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp];

fclose(fid);


end

