function [synccount] =FileAnalysisCNTRate(PathFileName,synccount)
%UNTITLED2 Summary of this function goes here
%   Called by GetIRFMain's directory loop.
% Reads current T3 file of the loop, in chunks of numRecords.


%% Global Variables for Picoharp and Router
global ind_Dpar ind_Dperp ind_Apar ind_Aperp ind_Dexc ind_Aexc numRecords
%% Global Variables for Work flow
global ALEX talkative
%% Global Variables for Lifetime
global dt dtTraj

global mCNT vCNT numChunks vDeltaT mDeltaT

%% Find the lvm file to get timing information
PathFileNameLVM=PathFileName;
PathFileNameLVM(end-3:end)='.lvm';

% Read the file into matrix
fid = fopen(PathFileNameLVM);
DATA=textscan(fid,'%f','HeaderLines',23);
dt=DATA{1}(4)/1000; %in ns
dt=dt*1E-9; %now in seconds
f0=DATA{1}(5);
Tpp=1/f0; %in seconds
fclose(fid);

%% Read the file of interest and process in chunks of numRecords

data=dir(PathFileName);
filesize=(data.bytes)/4; %4bytes is one uint32 record.
if numRecords>filesize
    errordlg('NumRecords is too big')
    return
end

numLoops=floor(filesize/numRecords);
%did we miss any records from uneven division?
missRecords=mod(filesize,numRecords);
fid=fopen(PathFileName,'r');

if isempty(numChunks)
    N=numLoops;
else
    N=numChunks;
end

Bdd_par=[];
Bdd_perp=[];
Bad_par=[];
Bad_perp=[];

Baa_par=[];
Baa_perp=[];
deltaTStore=[];

for i=1:N 
    
    filesize2=(data.bytes)/4; %4bytes is one uint32 record.
    if numRecords>filesize2
        errordlg('NumRecords is too big')
%         Bdd_par=[];
%         Bdd_perp=[];
%         Bad_par=[];
%         Bad_perp=[];
%         
%         Baa_par=[];
%         Baa_perp(i)=[];
        continue
    end
    
%     if talkative && ~mod(i,50)
%         sprintf('Analysing T3Records Chunk %f of %f',i,numLoops)
%     end
    
    [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,numRecords);
    
    if ~any(unique(ind)==ind_Dexc) %check if user accidently put ALEX on when they didn't actually do alex
        ALEX=0;
    end
    
    if ALEX
        
        [indDexc,sstimeDexc,timetagDexc,indAexc,sstimeAexc,timetagAexc] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]);
        
        
        
        BddPar=length(indDexc(indDexc==ind_Dpar));
        BddPerp=length(indDexc(indDexc==ind_Dperp));
        BadPar=length(indDexc(indDexc==ind_Apar));
        BadPerp=length(indDexc(indDexc==ind_Aperp));
        
        BaaPar=length(indAexc(indAexc==ind_Apar));
        BaaPerp=length(indAexc(indAexc==ind_Aperp));
    else
        
        BddPar=length(ind(ind==ind_Dpar));
        BddPerp=length(ind(ind==ind_Dperp));
        BadPar=length(ind(ind==ind_Apar));
        BadPerp=length(ind(ind==ind_Aperp));
        
        BaaPar=0;
        BaaPerp=0;
        
    end
    
    deltaT=timetag(end)-timetag(1);
    if deltaT<10E-6 || deltaT>300E-3
%         Bdd_par(i) =[];
%         Bdd_perp(i)=[];
%         Bad_par(i) = [];
%         Bad_perp(i) = [];
%         Baa_par(i) =[];
%         Baa_perp(i)= [];
%         deltaTStore(i)=[];
        %         continue %skip the rest and carry with next iteration
    else
    Bdd_par =[Bdd_par BddPar/deltaT];
    Bdd_perp=[Bdd_perp BddPerp/deltaT];
    Bad_par = [Bad_par BadPar/deltaT];
    Bad_perp = [Bad_perp BadPerp/deltaT];
    Baa_par =[Baa_par BaaPar/deltaT];
    Baa_perp= [Baa_perp BaaPerp/deltaT];
    deltaTStore=[deltaTStore deltaT];
    end
    
%     if i==N
%         if ~ALEX
%             edges=min(timetag(ind~=15)):dtTraj:max(timetag(ind~=15));
%             TrajG=histc(timetag(ind==ind_Dpar | ind==ind_Dperp),edges);
%             TrajR=histc(timetag(ind==ind_Apar | ind==ind_Aperp),edges);
%             hold all
%             plot(edges,TrajG,'g',edges,-1*TrajR,'r')
%             plot(edges,-(Bad_par(i)+Bad_perp(i))*dtTraj*ones(size(edges)),'k')
%             plot(edges,(Bdd_par(i)+Bdd_perp(i))*dtTraj*ones(size(edges)),'k')
%             myylabel=sprintf('Photon Counts, %.3f \\mus bins',dtTraj*1E6);
%             ylabel(myylabel)
%             xlabel('time(s)')
%             title('BKG estimate in black')
%             axis tight
%             xlim( [edges(1) edges(end)])
%             hold off
%         else        
%             edges=min(timetag(ind~=15)):dtTraj:max(timetag(ind~=15));
%             TrajGG=histc(timetagDexc(indDexc==ind_Dpar | indDexc==ind_Dperp),edges);
%             TrajRG=histc(timetagDexc(indDexc==ind_Apar | indDexc==ind_Aperp),edges);
%             TrajRR=histc(timetagAexc(indAexc==ind_Apar | indAexc==ind_Aperp),edges);
%             TrajGR=histc(timetagAexc(indAexc==ind_Dpar | indAexc==ind_Dperp),edges);
%             subplot(2,1,1)
%             hold all
%             plot(edges,TrajGG,'g',edges,-1*TrajRG,'r')
%             plot(edges,-(Bad_par(i)+Bad_perp(i))*dtTraj*ones(size(edges)),'k')
%             plot(edges,(Bdd_par(i)+Bdd_perp(i))*dtTraj*ones(size(edges)),'k')
%             myylabel=sprintf('Photon Counts, %.3f \\mus bins',dtTraj*1E6);
%             ylabel(myylabel)
%             xlabel('time(s)')
%             title('Donor Excitation Bkg Est')
%             axis tight
%             xlim( [edges(1) edges(end)])
%             hold off
%             subplot(2,1,2)
%             hold all
%             plot(edges,TrajGR,'g',edges,-1*TrajRR,'r')
%             plot(edges,-(Baa_par(i)+Baa_perp(i))*dtTraj*ones(size(edges)),'k')
%             myylabel=sprintf('Photon Counts, %.3f \\mus bins',dtTraj*1E6);
%             ylabel(myylabel)
%             xlabel('time(s)')
%             title('Acceptor Excitation Bkg Est')
%             axis tight
%             xlim( [edges(1) edges(end)])
%             hold off 
%         end
% %         drawnow
%     end
    
    
end %File Reading Loop

% hist(deltaTStore)

Bd=Bdd_par+Bdd_perp;
Ba=Bad_par+Bad_perp;
Baa=Baa_perp+Baa_par;

mBdd_par =mean(Bdd_par);
mBdd_perp=mean(Bdd_perp);
mBad_par = mean(Bad_par);
mBad_perp = mean(Bad_perp);
mBaa_par =mean(Baa_par);
mBaa_perp= mean(Baa_perp);
mBd=mean(Bd);
mBa=mean(Ba);
mBaa=mean(Baa);
mDeltaT=mean(deltaTStore);

vBdd_par =var(Bdd_par);
vBdd_perp=var(Bdd_perp);
vBad_par = var(Bad_par);
vBad_perp = var(Bad_perp);
vBaa_par =var(Baa_par);
vBaa_perp= var(Baa_perp);
vBd=var(Bd);
vBa=var(Ba);
vBaa=var(Baa);
vDeltaT=var(deltaTStore);


mCNT=[mBdd_par mBdd_perp mBad_par mBad_perp mBaa_par mBaa_perp mBd mBa mBaa];
vCNT=[vBdd_par vBdd_perp vBad_par vBad_perp vBaa_par vBaa_perp vBd vBa vBaa];
fclose(fid);


end

