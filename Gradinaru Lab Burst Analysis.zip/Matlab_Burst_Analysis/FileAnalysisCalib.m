function [synccount] =FileAnalysisCalib(PathFileName,synccount)
%UNTITLED2 Summary of this function goes here
%   Called by GetIRFMain's directory loop.
% Reads current T3 file of the loop, in chunks of numRecords.


%% Global Variables for Picoharp and Router
global ind_Dpar ind_Dperp ind_Apar ind_Aperp ind_Dexc ind_Aexc numRecords
%% Global Variables for Work flow
global ALEX talkative
%% Global Variables for Lifetime
global cal_DPar cal_DPerp dt MinPhCal draw_microtimeG cal_APar cal_APerp

%% Find the lvm file to get timing information
PathFileNameLVM=PathFileName;
PathFileNameLVM(end-3:end)='.lvm';

% Read the file into matrix
fid = fopen(PathFileNameLVM);
DATA=textscan(fid,'%f','HeaderLines',23);
dt=DATA{1}(4)/1000; %in ns
dt=dt*1E-9; %now in seconds
f0=DATA{1}(5);
Tpp=1/f0; %in seconds
fclose(fid);

%% Read the file of interest and process in chunks of numRecords

data=dir(PathFileName);
filesize=(data.bytes)/4; %4bytes is one uint32 record.
if numRecords>filesize
    errordlg('NumRecords is too big')
    return
end

numLoops=floor(filesize/numRecords);
%did we miss any records from uneven division?
missRecords=mod(filesize,numRecords);
fid=fopen(PathFileName,'r');

for i=1:numLoops %File Reading Loop
    
    if talkative
    sprintf('Analysing IRF T3Records Chunk %f of %f',i,numLoops)
    end
    
%     [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,numRecords);
    [ind,sstime,timetag,synccount] = ReadT3FilesDouble_chunky(fid,Tpp,dt,synccount,numRecords);
    UniqueInd=unique(ind)
    if ALEX
        %I include time resolved data for the Aexc photons in anticipation
        %of future ability to perform this type of anlaysis. For now, we
        %are only interested in the number of photons in par and perp to
        %get G and steady state anisotropy.
        [ind,sstime,~,indAexc,sstimeAexc,~] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]);
        
        %remove special markers
        sstimeAexc=sstimeAexc(indAexc~=15); %greg changed ind to indAexc Oct 4 2015, hope this fixs things
        indAexc=indAexc(indAexc~=15);
        
        %     ind=double(ind);
        %     sstime=double(sstime);
        
        %Bin with 255 possible values
        edges_ss=0:16:4095;
        dt=16*dt;
        I_Apar=histc(sstimeAexc(indAexc==ind_Apar),edges_ss);
        I_Aperp=histc(sstimeAexc(indAexc==ind_Aperp),edges_ss);
        
        %Remove contigous zeros at the end ~Tpp to 4096*dt is all zeros
        I_Apar=I_Apar(1:floor(Tpp/dt)); %there may be a problem with changing Tpp causing changing vector length
        I_Aperp=I_Aperp(1:floor(Tpp/dt));
        
        %Update the global histogram of Irf
        if length(I_Apar)<length(cal_APar)
            cal_APar=cal_APar(1:length(I_Apar)) + I_Apar;
            cal_APerp=cal_APerp(1:length(I_Apar)) + I_Aperp;
        else
            cal_APar=cal_APar + I_Apar(1:length(cal_APar));
            cal_APerp=cal_APerp + I_Aperp(1:length(cal_APerp));
        end
        
        dt=dt/16; %put dt back for the donor processing
        
        clear indAexc sstimeAexc
    end
    
    clear timetag
    
    %remove special markers
    sstime=sstime(ind~=15);
    ind=ind(ind~=15);
    
    %     ind=double(ind);
    %     sstime=double(sstime);
    
    %Bin with 255 possible values
    edges_ss=0:16:4095;
    dt=16*dt;
    I_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
    I_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
    
    %Remove contigous zeros at the end ~Tpp to 4096*dt is all zeros
    I_Dpar=I_Dpar(1:floor(Tpp/dt)); %there may be a problem with changing Tpp causing changing vector length
    I_Dperp=I_Dperp(1:floor(Tpp/dt));
    
    %Update the global histogram of Irf
    if length(I_Dpar)<length(cal_DPar)
        cal_DPar=cal_DPar(1:length(I_Dpar)) + I_Dpar;
        cal_DPerp=cal_DPerp(1:length(I_Dpar)) + I_Dperp;
    else
        cal_DPar=cal_DPar + I_Dpar(1:length(cal_DPar));
        cal_DPerp=cal_DPerp + I_Dperp(1:length(cal_DPerp));
    end
%     
%     if draw_microtimeG
%         semilogy(1E9*dt*edges_ss(1:length(cal_DPar)),cal_DPar,1E9*dt*edges_ss(1:length(cal_DPar)),cal_DPerp,1E9*dt*edges_ss(1:length(cal_APar)),cal_APar,1E9*dt*edges_ss(1:length(cal_APar)),cal_APerp)
%         drawnow
%     end
    
    NphDpar=sum(cal_DPar);
    NphDperp=sum(cal_DPerp);
    if ALEX
        NphApar=sum(cal_APar);
        NphAperp=sum(cal_APerp);
    else
        NphApar=length(ind==ind_Apar);
        NphAperp=length(ind==ind_Aperp);
    end
    
    
    clear ind  sstime
    
    dt=dt/16; %return dt to its unaltered state - or else it will acculumate dt=dt*16*16*16*16...

    if talkative
        sprintf('NphDpar = %f \r\n NphDperp=%f',NphDpar,NphDperp)
        if ~ALEX
            sprintf('Warning: NphAPar and NphAperp not due to direct acceptor excitation')
        end
        sprintf('NphApar = %f \r\n NphAperp=%f',NphApar,NphAperp)
    end
    
    if ~ALEX
        if (NphDpar> MinPhCal) && (NphDperp > MinPhCal)
            missRecords=0; %don't bother entering the next loop
            break
        end
    else
%        if (NphDpar> MinPhCal) && (NphDperp> MinPhCal) && (NphApar> MinPhCal) && (NphAperp> MinPhCal)
       if (NphDpar> MinPhCal) && (NphDperp> MinPhCal)  
            missRecords=0; %don't bother entering the next loop
            break
        end
    end
    
end %File Reading Loop



if missRecords~=0  %Missed records loop
    
%     [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,missRecords);
    [ind,sstime,timetag,synccount] = ReadT3FilesDouble_chunky(fid,Tpp,dt,synccount,numRecords);
    
    if ALEX
        %Only care about donor excitation since Red Laser is quasi-cw (us
        %modulation)
        [ind,sstime,~,indAexc,sstimeAexc,~] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]);
        
        %remove special markers
        sstimeAexc=sstimeAexc(indAexc~=15);
        indAexc=indAexc(indAexc~=15);
        
        %     ind=double(ind);
        %     sstime=double(sstime);
        
        %Bin with 255 possible values
        edges_ss=0:16:4095;
        dt=16*dt;
        I_Apar=histc(sstimeAexc(indAexc==ind_Apar),edges_ss);
        I_Aperp=histc(sstimeAexc(indAexc==ind_Aperp),edges_ss);
        
        %Remove contigous zeros at the end ~Tpp to 4096*dt is all zeros
        I_Apar=I_Apar(1:floor(Tpp/dt)); %there may be a problem with changing Tpp causing changing vector length
        I_Aperp=I_Aperp(1:floor(Tpp/dt));
        
        %Update the global histogram of Irf
        if length(I_Apar)<length(cal_APar)
            cal_APar=cal_APar(1:length(I_Apar)) + I_Apar;
            cal_APerp=cal_APerp(1:length(I_Apar)) + I_Aperp;
        else
            cal_APar=cal_APar + I_Apar(1:length(cal_APar));
            cal_APerp=cal_APerp + I_Aperp(1:length(cal_APerp));
        end
        
        dt=dt/16; %put dt back for the donor processing
        
        clear indAexc sstimeAexc
    end
    
    clear timetag
    
    %remove special markers
    sstime=sstime(ind~=15);
    ind=ind(ind~=15);
    
    %     ind=double(ind);
    %     sstime=double(sstime);
    
    %Bin with 255 possible values
    edges_ss=0:16:4095;
    dt=16*dt;
    I_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
    I_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
    
    %Remove contigous zeros at the end ~Tpp to 4096*dt is all zeros
    I_Dpar=I_Dpar(1:floor(Tpp/dt)); %there may be a problem with changing Tpp causing changing vector length
    I_Dperp=I_Dperp(1:floor(Tpp/dt));
    
    %Update the global histogram of Irf
    if length(I_Dpar)<length(cal_DPar)
        cal_DPar=cal_DPar(1:length(I_Dpar)) + I_Dpar;
        cal_DPerp=cal_DPerp(1:length(I_Dpar)) + I_Dperp;
    else
        cal_DPar=cal_DPar + I_Dpar(1:length(cal_DPar));
        cal_DPerp=cal_DPerp + I_Dperp(1:length(cal_DPerp));
    end
    
%     if draw_microtimeG
%         semilogy(1E9*dt*edges_ss(1:length(cal_DPar)),cal_DPar,1E9*dt*edges_ss(1:length(cal_DPar)),cal_DPerp,1E9*dt*edges_ss(1:length(cal_APar)),cal_APar,1E9*dt*edges_ss(1:length(cal_APar)),cal_APerp)
%         drawnow
%     end
    
    dt=dt/16; %return dt to its unaltered state - or else it will acculumate dt=dt*16*16*16*16...
    
    NphDpar=sum(cal_DPar);
    NphDperp=sum(cal_DPerp);
    if ALEX
        NphApar=sum(cal_APar);
        NphAperp=sum(cal_APerp);
    else
        NphApar=length(ind==ind_Apar);
        NphAperp=length(ind==ind_Aperp);
    end
     clear ind  sstime
    
     if talkative
        sprintf('NphDpar = %f \r\n NphDperp=%f',NphDpar,NphDperp)
        if ~ALEX
            sprintf('Warning: NphAPar and NphAperp not due to direct acceptor excitation')
        end
        sprintf('NphApar = %f \r\n NphAperp=%f',NphApar,NphAperp)
    end
    
% %     if ~ALEX
% %         if NphDpar && NphDperp > MinPhCal
% %             missRecords=0; %don't bother entering the next loop
% %             break
% %         end
% %     else
% %         if NphDpar && NphDperp && NphApar && NphAperp > MinPhCal
% %             missRecords=0; %don't bother entering the next loop
% %             break
% %         end
% %     end
    
end %Missed records loop
fclose(fid);

save('calib','cal_DPar','cal_DPerp')

dt=dt*16; %Return dt after binning

end

