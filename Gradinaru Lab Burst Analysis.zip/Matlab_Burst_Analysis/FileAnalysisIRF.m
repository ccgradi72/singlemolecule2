function [synccount] =FileAnalysisIRF(PathFileName,synccount)
%UNTITLED2 Summary of this function goes here
%   Called by GetIRFMain's directory loop.
% Reads current T3 file of the loop, in chunks of numRecords. 


%% Global Variables for Picoharp and Router
global ind_Dpar ind_Dperp ind_Apar ind_Aperp ind_Dexc ind_Aexc numRecords 
%% Global Variables for Work flow
global ALEX talkative
%% Global Variables for Lifetime
global Irf_DPar Irf_DPerp Irf_APar Irf_APerp dt MinPhIRF draw_microtimeIRF

%% Find the lvm file to get timing information
PathFileNameLVM=PathFileName;
PathFileNameLVM(end-3:end)='.lvm';

% Read the file into matrix
fid = fopen(PathFileNameLVM);
DATA=textscan(fid,'%f','HeaderLines',23);
dt=DATA{1}(4)/1000; %in ns
dt=dt*1E-9; %now in seconds
f0=DATA{1}(5);
Tpp=1/f0; %in seconds
fclose(fid);

%% Read the file of interest and process in chunks of numRecords

data=dir(PathFileName);
filesize=(data.bytes)/4; %4bytes is one uint32 record.
if numRecords>filesize
    errordlg('NumRecords is too big')
    return
end

numLoops=floor(filesize/numRecords);
%did we miss any records from uneven division?
missRecords=mod(filesize,numRecords);
fid=fopen(PathFileName,'r');

for i=1:numLoops %File Reading Loop
    
    if talkative
    sprintf('Analysing IRF T3Records Chunk %f of %f',i,numLoops)
    end
    
%     [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,numRecords);
    [ind,sstime,timetag,synccount] = ReadT3FilesDouble_chunky(fid,Tpp,dt,synccount,numRecords);
    
    if ALEX
        %Only care about donor excitation since Red Laser is quasi-cw (us
        %modulation)
        [ind,sstime,~,~,~,~,~,~] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]);
    end
    
    clear timetag
    
    %remove special markers
    sstime=sstime(ind~=15);
    ind=ind(ind~=15);
    
    
    ind=double(ind);
    sstime=double(sstime);
    
    
    %Bin with 255 possible values
    edges_ss=0:16:4095;
    dt=16*dt;
    I_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
    I_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
    I_Apar=histc(sstime(ind==ind_Apar),edges_ss);
    I_Aperp=histc(sstime(ind==ind_Aperp),edges_ss);
    
    
    %Remove contigous zeros at the end ~Tpp to 4096*dt is all zeros
    I_Dpar=I_Dpar(1:floor(Tpp/dt)); %there may be a problem with changing Tpp causing changing vector length
    I_Dperp=I_Dperp(1:floor(Tpp/dt));
    I_Apar=I_Apar(1:floor(Tpp/dt)); %there may be a problem with changing Tpp causing changing vector length
    I_Aperp=I_Aperp(1:floor(Tpp/dt));
    
    %Update the global histogram of Irf
    if length(I_Dpar)<length(Irf_DPar)
    Irf_DPar=Irf_DPar(1:length(I_Dpar)) + I_Dpar;
    Irf_DPerp=Irf_DPerp(1:length(I_Dpar)) + I_Dperp;
    Irf_APar=Irf_APar(1:length(I_Apar)) + I_Apar;
    Irf_APerp=Irf_APerp(1:length(I_Apar)) + I_Aperp;
    else
    Irf_DPar=Irf_DPar + I_Dpar(1:length(Irf_DPar));
    Irf_DPerp=Irf_DPerp + I_Dperp(1:length(Irf_DPerp));
    Irf_APar=Irf_APar + I_Apar(1:length(Irf_APar));
    Irf_APerp=Irf_APerp + I_Aperp(1:length(Irf_APerp));
    end
 
    if draw_microtimeIRF
%         hold all
    semilogy(1E9*dt*edges_ss(1:length(Irf_DPar)),Irf_DPar,1E9*dt*edges_ss(1:length(Irf_DPar)),Irf_DPerp,1E9*dt*edges_ss(1:length(Irf_APar)),Irf_APar,1E9*dt*edges_ss(1:length(Irf_APar)),Irf_APerp)
%     semilogy(1E9*dt*edges_ss(1:length(Irf_APar)),Irf_APar,1E9*dt*edges_ss(1:length(Irf_APar)),Irf_APerp)
    set(gca,'YScale','log')
%     semilogy(1E9*dt*edges_ss(1:length(Irf_DPar)),Irf_DPar,1E9*dt*edges_ss(1:length(Irf_DPar)),Irf_DPerp)
    drawnow
%     hold off
    end
    
    clear ind  sstime
    
    dt=dt/16; %return dt to its unaltered state - or else it will acculumate dt=dt*16*16*16*16...
    
     NphDpar=sum(Irf_DPar);
     NphDperp=sum(Irf_DPerp);
     NphApar=sum(Irf_APar);
     NphAperp=sum(Irf_APerp);
     
     if talkative
         sprintf('NphDpar = %f \r\n NphDperp=%f',NphDpar,NphDperp)
         sprintf('NphApar = %f \r\n NphAperp=%f',NphApar,NphAperp)
     end
     
     if (NphDpar > MinPhIRF) && (NphDperp > MinPhIRF)
         missRecords=0; %don't bother entering the next loop
         break
     end
    
end %File Reading Loop



if missRecords~=0  %Missed records loop
%     [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,missRecords);
    [ind,sstime,timetag,synccount] = ReadT3FilesDouble_chunky(fid,Tpp,dt,synccount,numRecords);

    if ALEX
        %Only care about donor excitation since Red Laser is quasi-cw (us
        %modulation)
        [ind,sstime,~,~,~,~] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]);
    end
    
    clear timetag
    
    %remove special markers
    sstime=sstime(ind~=15);
    ind=ind(ind~=15);
    
    ind=double(ind);
    sstime=double(sstime);
    
    %Bin with 255 possible values
    edges_ss=0:16:4095;
    dt=16*dt;
    I_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
    I_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
    I_Apar=histc(sstime(ind==ind_Apar),edges_ss);
    I_Aperp=histc(sstime(ind==ind_Aperp),edges_ss);
    
    %Remove contigous zeros at the end ~Tpp to 4096*dt is all zeros
    I_Dpar=I_Dpar(1:floor(Tpp/dt)); %there may be a problem with changing Tpp causing changing vector length
    I_Dperp=I_Dperp(1:floor(Tpp/dt));
    I_Apar=I_Apar(1:floor(Tpp/dt)); %there may be a problem with changing Tpp causing changing vector length
    I_Aperp=I_Aperp(1:floor(Tpp/dt));
    
    %Update the global histogram of Irf
    if length(I_Dpar)<length(Irf_DPar)
    Irf_DPar=Irf_DPar(1:length(I_Dpar)) + I_Dpar;
    Irf_DPerp=Irf_DPerp(1:length(I_Dpar)) + I_Dperp;
    Irf_APar=Irf_APar(1:length(I_Apar)) + I_Apar;
    Irf_APerp=Irf_APerp(1:length(I_Apar)) + I_Aperp;
    else
    Irf_DPar=Irf_DPar + I_Dpar(1:length(Irf_DPar));
    Irf_DPerp=Irf_DPerp + I_Dperp(1:length(Irf_DPerp));
    Irf_APar=Irf_APar + I_Apar(1:length(Irf_APar));
    Irf_APerp=Irf_APerp + I_Aperp(1:length(Irf_APerp));
    end
 
%     if draw_microtimeIRF
% %         hold all
%     semilogy(1E9*dt*edges_ss(1:length(Irf_DPar)),Irf_DPar,1E9*dt*edges_ss(1:length(Irf_DPar)),Irf_DPerp)
% %     semilogy(1E9*dt*edges_ss(1:length(Irf_APar)),Irf_APar,1E9*dt*edges_ss(1:length(Irf_APar)),Irf_APerp)
%     drawnow
% %     hold off
%     end
    
    if draw_microtimeIRF
%         hold all
    semilogy(1E9*dt*edges_ss(1:length(Irf_DPar)),Irf_DPar,1E9*dt*edges_ss(1:length(Irf_DPar)),Irf_DPerp,1E9*dt*edges_ss(1:length(Irf_APar)),Irf_APar,1E9*dt*edges_ss(1:length(Irf_APar)),Irf_APerp)
%     semilogy()
    set(gca,'YScale','log')
%     semilogy(1E9*dt*edges_ss(1:length(Irf_DPar)),Irf_DPar,1E9*dt*edges_ss(1:length(Irf_DPar)),Irf_DPerp)
    drawnow
%     hold off
    end
 
    clear ind  sstime
   
    dt=dt/16;
    
end %Missed records loop
fclose(fid);

dt=dt*16; %Return dt after binning

end

