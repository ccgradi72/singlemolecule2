function [fx0,fy0,ftheta,fsigmax,fsigmay] = Fit2dGaussianGeneral(DATA,x,y)
%UNTITLED Summary of this function goes here
clear all
close all
clc;

% load('Etau','edgesX2','edgesY2','N')
% load('ES','edgesX2','edgesY2','N')
% load('ES','edgesX2','edgesY2','N')
% x=edgesX2;
% y=edgesY2;


z=[-1.0 -0.8 -0.6 -0.4 -0.2 0 0.2 0.4 0.6];
z=z*1000;
pixelstep=20; %nm
pixelnum=100;
x=-pixelnum/2:pixelnum/2;
x(end)=[];
xgv=x*pixelstep;
ygv=xgv;
[X,Y,Z] = meshgrid(xgv,ygv,z);

load('PSF.mat','VAA','VAD','VDD') 




DATA=VDD(:,:,6);
X=X(:,:,6);
Y=Y(:,:,6);



figure;
imagesc(DATA)

% DATA=N;
% %Give y and x axis
% x=0:1:100;
% y=0:1:100;
%Need grid of X and Y to make model function
% [X,Y] = meshgrid(x,y);

figure;
mesh(X,Y,DATA)
xlabel('X')
ylabel('Y')


n=DATA;


%Solver properties
maxiter=3000;
maxfunevals=10000;
tolfun=1e-8;
tolx=1e-6;
lsqOpt=[maxiter maxfunevals tolfun tolx];
options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');

%Try to Guess the best fit paramaters

% x00=[0.2 0.5 0.6];
% x00=[2 4];
x00=[0];
% y00=[0.8 0.5 0.3];
% y00=[0.1 0.2];
y00=[0];
sigmax0=[300];
sigmay0=[300];
% sigmax0=[1 1];
% sigmay0=[0.1 0.1];
% sigmax0=[0.05 0.05 0.05];
% sigmay0=[0.05 0.05 0.05];
% A0=[max(max(DATA))*sigmax0(1)*sqrt(pi/2) max(max(DATA))*sigmax0(2)*sqrt(pi/2) max(max(DATA))*sigmax0(2)*sqrt(pi/2)];
% theta0=[0 0 0];
% A0=[max(max(DATA))*sigmax0(1)*sqrt(pi/2) max(max(DATA))*sigmax0(2)*sqrt(pi/2)];
A0=[max(max(DATA))*sigmax0(1)*sqrt(pi/2)];
theta0=[0];
bb=[0]
param0=[x00 y00 theta0 sigmax0 sigmay0 A0 bb]
ng=length(x00);
% paramin=[zeros(size(x00)) zeros(size(y00)) zeros(size(theta0)) zeros(size(sigmax0)) zeros(size(sigmay0)) zeros(size(A0))]
% paramax=[ones(size(x00)) ones(size(y00)) 2*pi*ones(size(theta0)) ones(size(sigmax0)) ones(size(sigmay0)) Inf(size(A0))]
% paramin=[zeros(size(x00)) zeros(size(y00)) zeros(size(theta0)) zeros(size(sigmax0)) zeros(size(sigmay0)) zeros(size(A0))]
% paramin=[zeros(size(x00)) zeros(size(y00)) zeros(size(theta0)) zeros(size(sigmax0)) zeros(size(sigmay0)) zeros(size(A0))]
% paramax=[Inf(size(x00)) Inf(size(y00)) 2*pi*ones(size(theta0)) Inf(size(sigmax0)) Inf(size(sigmay0)) Inf(size(A0))]
% paramax=[Inf(size(x00)) Inf(size(y00)) zeros(size(theta0)) Inf(size(sigmax0)) Inf(size(sigmay0)) Inf(size(A0))]
paramin=[];
paramax=[];


%Find the best fit parameters
[param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,param0,paramin,paramax,options);

%Unpackage best fit parameters
fx0=param(1:ng)
        fy0=param(ng+1:2*ng)
        ftheta=param(2*ng+1:3*ng)
        fsigmax=2*param(3*ng+1:4*ng)
        fsigmay=2*param(4*ng+1:5*ng)
        fA=param(5*ng+1:6*ng)
        fbb=param(end)
        sprintf('Sigma are full waist at 1/e^2')
        
        

%Make the best fit model for display
[ffit,fsubf]=objfcn2(param);
figure;
hold all;
mesh(X,Y,DATA)
at=0.5
surf(X,Y,ffit,'FaceAlpha',at)
% view(gca,[90 0]);

view(gca,[88 40]);

xlim([-500 500])
ylim([-500 500])

%%Graphing stuff
fw='Normal';
fn='Helvetica';
axw='Normal';
cc=[255, 153, 0]/255
cc2=[48, 94 168]/255
fontsizeax=16;
fontsizel=12;
lwax=1;
ticksize=20;
linewidthbestfit=0.4;
linewidthErrBar=1;
markersize=5;
lw=4;
lwe=2;
ms=markersize;
set(gca,'XTick',[-500:250:500])
set(gca,'YTick',[-500:250:500])
% set(gca,'XTickLabel',{})
% set(gca,'YTickLabel',{})
set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'off' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
 set(gca,'ZColor','w')
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
        % Set the remaining axes properties
% set(gca,'CameraPosition',...
%     [7601.74748757839 -14647.6146415241 1.38310547956041],'CameraTarget',...
%     [147.320251364047 -142.989585769628 0.0584034712778099],'CameraUpVector',...
%     [0 0 1],'CameraViewAngle',10.030883705218,'DataAspectRatio',[4000 4000 1],...
%     'FontSize',20,'LineWidth',1,'TickLength',[0.02 0.02],'XColor',[0.1 0.1 0.1],...
%     'YColor',[0.1 0.1 0.1],'ZColor',[1 1 1]);
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
%         set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        print('-dpng','-r600','PSFfit')
        
 figure;
hold all;
mesh(X,Y,DATA)
at=0.5
surf(X,Y,ffit,'FaceAlpha',at)

xlim([-500 500])
ylim([-500 500])


% view(gca,[0 0]);

view(gca,[-2 40]);

%%Graphing stuff
fw='Normal';
fn='Helvetica';
axw='Normal';
cc=[255, 153, 0]/255
cc2=[48, 94 168]/255
fontsizeax=16;
fontsizel=12;
lwax=1;
ticksize=20;
linewidthbestfit=0.4;
linewidthErrBar=1;
markersize=5;
lw=4;
lwe=2;
ms=markersize;
set(gca,'XTick',[-500:250:500])
set(gca,'YTick',[-500:250:500])
% set(gca,'XTickLabel',{})
% set(gca,'YTickLabel',{})
set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'off' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
 set(gca,'ZColor','w')
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
        % Set the remaining axes properties
% set(gca,'CameraPosition',...
%     [7601.74748757839 -14647.6146415241 1.38310547956041],'CameraTarget',...
%     [147.320251364047 -142.989585769628 0.0584034712778099],'CameraUpVector',...
%     [0 0 1],'CameraViewAngle',10.030883705218,'DataAspectRatio',[4000 4000 1],...
%     'FontSize',20,'LineWidth',1,'TickLength',[0.02 0.02],'XColor',[0.1 0.1 0.1],...
%     'YColor',[0.1 0.1 0.1],'ZColor',[1 1 1]);
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
%         set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        print('-dpng','-r600','PSFfit2')       
        





return




figure;
mesh(X,Y,DATA-ffit)
title('residuals')

% figure;
% hold all
% imagesc(x,y,ffit)
% % load('StaticFRET','mE','rat')
% [ mE,rat] = GenerateStaticFRETLine(54.792,3.7519,9.5);
% plot(mE,rat,'r','LineWidth',3)
% [ mE,rat] = GenerateStaticFRETLine(54.792,3.7519,0);
% plot(mE,rat,'k','LineWidth',3)
% % [ mE,rat] = GenerateStaticFRETLine(50,3.75,10);
% % plot(mE,rat,'--r','LineWidth',3)
% % [ mE,rat] = GenerateStaticFRETLine(55,3.75,7);
% % plot(mE,rat,'g','LineWidth',3)
% % [ mE,rat] = GenerateStaticFRETLine(55,3.75,10);
% % plot(mE,rat,'--g','LineWidth',3)
% % [ mE,rat] = GenerateStaticFRETLine(45,3.75,7);
% % plot(mE,rat,'m','LineWidth',3)
% % [ mE,rat] = GenerateStaticFRETLine(45,3.75,10);
% % plot(mE,rat,'--m','LineWidth',3)
% legend('Modified Static: Ro 54.79 sigma 9.5 tauD0=3.75 ns','Static FRET')
% xlim([0 1])
% ylim([0 1])
% xlabel('E')
% ylabel('tauDA/tau')

DATASUM1=sum(DATA,1);
fitSUM1=sum(ffit,1);
fit1G1=sum(fsubf{1},1);
% fit1G2=sum(fsubf{2},1);
% fit1G3=sum(fsubf{3},1);

DATASUM2=sum(DATA,2);
fitSUM2=sum(ffit,2);
fit2G1=sum(fsubf{1},2);
% fit2G2=sum(fsubf{2},2);
% fit2G3=sum(fsubf{3},2);

figure;
hold all;
% plot(x,DATASUM1,'-k','linewidth',2) %is the first dimension of DATA and ffit really x? need to find out
bar(xgv,DATASUM1) %is the first dimension of DATA and ffit really x? need to find out
plot(xgv,fitSUM1,'-r','linewidth',2)
plot(xgv,fit1G1,'-g','linewidth',1)
% plot(x,fit1G2,'-g','linewidth',1)
% plot(x,fit1G3,'-g','linewidth',1)
xlabel('X')

figure;
hold all;
bar(ygv,DATASUM2) %is the first dimension of DATA and ffit really x? need to find out
plot(ygv,fitSUM2,'-r','linewidth',2)
plot(ygv,fit2G1,'-g','linewidth',1)
% plot(y,fit2G2,'-g','linewidth',1)
% plot(y,fit2G3,'-g','linewidth',1)
xlabel('Y')


%Finding gamma
% Lk=0.02; 
% di=0.05; 

% val=fy0(1);
% tmp = abs(rat-val);
% [idx idx] = min(tmp); %index of closest value
% % closest = rat(idx) %closest value
% Egoal(1)=mE(idx)
% 
% val=fy0(2);
% tmp = abs(rat-val);
% [idx idx] = min(tmp); %index of closest value
% % closest = rat(idx) %closest value
% Egoal(2)=mE(idx)
% 
% % [gammaout,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn3,1,0,2,options);
% [gammaout]=fminsearch(@objfcn3,1)
% gammaout
% 
% [ Epr(1) ] = Eraw2Epr( fx0(1),gammaout,Lk,di)
% [ Epr(2) ] = Eraw2Epr( fx0(2),gammaout,Lk,di)

    function [err]=objfcn(param)
        
        f=zeros(size(X));
        x0=param(1:ng);
        y0=param(ng+1:2*ng);
        theta=param(2*ng+1:3*ng);
        sigmax=param(3*ng+1:4*ng);
        sigmay=param(4*ng+1:5*ng);
        A=param(5*ng+1:6*ng);
        bb=param(end);
        
        for i=1:ng     
        a=((cos(theta(i))^2)/(2*sigmax(i)^2))+((sin(theta(i))^2)/(2*sigmay(i)^2));
        c=((sin(theta(i))^2)/(2*sigmax(i)^2))+((cos(theta(i))^2)/(2*sigmay(i)^2));
        b=-((sin(2*theta(i)))/(4*sigmax(i)^2))+((sin(2*theta(i)))/(4*sigmay(i)^2));
        f=A(i)*exp(-(a*(X-x0(i)).^2 + 2*b*(X-x0(i)).*(Y-y0(i)) + c*(Y-y0(i)).^2))+f;
        end
        f=f+bb;
        
        err=(n-f);
        err=err(:);
        
    end

    function [f,subf]=objfcn2(param)
        
        
         f=zeros(size(X));
        x0=param(1:ng);
        y0=param(ng+1:2*ng);
        theta=param(2*ng+1:3*ng);
        sigmax=param(3*ng+1:4*ng);
        sigmay=param(4*ng+1:5*ng);
        A=param(5*ng+1:6*ng);
        bb=param(end);
        for i=1:ng     
        a=((cos(theta(i))^2)/(2*sigmax(i)^2))+((sin(theta(i))^2)/(2*sigmay(i)^2));
        c=((sin(theta(i))^2)/(2*sigmax(i)^2))+((cos(theta(i))^2)/(2*sigmay(i)^2));
        b=-((sin(2*theta(i)))/(4*sigmax(i)^2))+((sin(2*theta(i)))/(4*sigmay(i)^2));
        f=A(i)*exp(-(a*(X-x0(i)).^2 + 2*b*(X-x0(i)).*(Y-y0(i)) + c*(Y-y0(i)).^2))+f;
        subf{i}=A(i)*exp(-(a*(X-x0(i)).^2 + 2*b*(X-x0(i)).*(Y-y0(i)) + c*(Y-y0(i)).^2));
        end
        
        f=f+bb;
        
        
        
    end

    function f=objfcn3(gamma)
        
        [ Epr(1) ] = Eraw2Epr( fx0(1),gamma,Lk,di);
        [ Epr(2) ] = Eraw2Epr( fx0(1),gamma,Lk,di);
        
        f=sum((Egoal-Epr).^2);
        
    
    end

    

end

