function [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=FitGaussMix(nEraw,cEraw,stdE,Ec0,fixE,lb,ub,nPh)



% FitGaussMix(nEraw,cEraw,stdE,Ec0,fixE,nPh)


% clc;
% % clear all;
% close all
% 
% % for l=1:100
% E=[repmat(0.2,1,18000/3) repmat(0.5,1,18000/3) repmat(0.8,1,18000/3)];
% 
% % E=[ 1 1 1 1 1 0.5 0.5 0.5 0 0 0 0 0 0.5 0.5 0.5 0.5 1 1 1 1 1 1 0.5 0.5 0.5 0.5]
% n=50;
% Fa=binornd(n,E);
% Et=Fa/n;
% figure;
% hold all
% xf=1;
%     xi=0;
%     nxBins=50;
%     dx=(xf-xi)/nxBins;
%     edges{1}=[xi:dx:xf]; % bin for x axis
% [nEraw,cEraw] = hist(Et,edges{1});
% 
% % saveE(:,l)=nEraw;
% % end
% % size(saveE)
% % aa=std(saveE,1,1)
% % aa.^2
% 
% % size(aa)
% 
% 
% 
% bar(cEraw,nEraw,'BarWidth',0.75,'FaceColor', [160 160 160]/256);
%         xlabel('E')
%         ylabel('Frequency')
%         xlim([xi xf])
%         
%         Ec0=[0.25 0.55 0.85];

nEraw=nEraw(:)';
cEraw=cEraw(:)';
stdE=stdE(:)';

        numG=length(Ec0);
        w0=sqrt(Ec0.*(1-Ec0)/nPh);
       
        for k=1:length(Ec0)
        [~,heightspos(k)]=min(abs(Ec0(k)-cEraw));
        
        end
        heights=nEraw(heightspos);
        A0=heights.*w0*sqrt(pi/2);      
        modelParam0=[Ec0 w0 A0];
        
%         fixParam=[0 0 0 0 0 0 0 0 0];
fixParam=[fixE zeros(1,length(modelParam0)-length(fixE))];
fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
nparam=length(modelParam0)-nnz(fixParam); %number of free parameters
lb=[lb zeros(1,length(w0)) zeros(1,length(A0))];
ub=[ub Inf(1,length(w0)) Inf(1,length(A0))];
% lb=zeros(1,length(modelParam0)); %lower bounds
% ub=Inf(1,length(modelParam0)); %upper bounds
%   lb=[];
%   ub=[];
        %% Fitting Preamble

%Solver properties
maxiter=5000;
maxfunevals=5000;
tolfun=1e-8;
tolx=1e-8;
lsqOpt=[maxiter maxfunevals tolfun tolx];
        
        %Set options for solver
%lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');



%the "heart" of the solver

if ~isempty(ub)||~isempty(lb)
    %if there are any upper or lower bounds, use them
    [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
else
    %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
    [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,[],[],options);
end

% modelParam
% 
%       fEc=modelParam(1:numG)
%         fw=modelParam(numG+1:2*numG)
%         fA=modelParam(2*numG+1:end)
%         
%         fx=linspace(xi,xf,100);
%         fy=zeros(size(fx));
%         for j=1:length(Ec)
%            
%             fy=fy+(fA(j)/(fw(j)*sqrt(pi/2)))*exp(-2*((fx-fEc(j)).^2)/(fw(j)^2));
% %             infy=(fA(j)/(fw(j)*sqrt(pi/2)))*exp(-2*((fx-fEc(j)).^2)/(fw(j)^2));
% %             plot(fx(infy>1),infy(infy>1),'LineWidth',2)
%         end
%         
% plot(fx,fy,'LineWidth',2,'Color','k')
% 
% fx=linspace(xi,xf,100);
%         fy=zeros(size(fx));
%         for j=1:length(Ec)
%            
% %             fy=fy+(fA(j)/(fw(j)*sqrt(pi/2)))*exp(-2*((fx-fEc(j)).^2)/(fw(j)^2));
%             infy=(fA(j)/(fw(j)*sqrt(pi/2)))*exp(-2*((fx-fEc(j)).^2)/(fw(j)^2));
%             plot(fx(infy>1),infy(infy>1),'LineWidth',2)
%         end
% 
%         figure;
%         plot(cEraw,residual)
%         
%         
% %errors of fit
% dof = length(residual)-nparam;
% redchi=resnorm/dof;
% Jacobianf=full(jacobian); %lsqnonlin returns  Jacobian as sparse matrix
% Jacobianf(:,fixParam)=[]; %the columns corresponding to fixed parameters should be deleted to avoid singular Jacobian inverse problem
% varp=resnorm*((Jacobianf'*Jacobianf)^-1)/dof;
% stdp=sqrt(diag(varp));
% 
% cinv=diag(varp^-1);
% c=diag(varp);
% 
% dep=1-(1./cinv.*c);%if eqn is overparameterized a mutual dependency exists
% %values close to 1 indicate strong dependnency
% dep=dep';
% %if some parameters are fixed, must rewritre stdp vector
% ind=find(fixParam); % eg, fixp= [1 0 0 0 1 0 1] Rinf and bgx fixed at zero
% % ind =[1,5,7]
% %stdp=[2 3 4 6] but should be [0 2 3 4 0 6 0]
% stdp=stdp';
% if ~isempty(ind)
%     for i=1:nnz(fixParam) %three iterations in thsi example
%         if ind(i)==1
%             stdp=[0 stdp]; %=[0 2 3 4 6] on iteration 1
%             dep=[0 dep];
%         elseif ind(i)==length(fixParam)
%             stdp=[stdp 0]; %=[0 2 3 4 0 6 0]
%             dep=[dep 0];
%         else
%             stdp=[stdp(1:ind(i)-1) 0 stdp(ind(i):end)];
%             %=[1 2 3 4 0 6] on iteration 2
%             dep=[dep(1:ind(i)-1) 0 dep(ind(i):end)];
%         end
%     end
% end
% 
% 
% str=sprintf('The dof = %f = length residual %f - number of parameters %f + number of fixed parameters %f',dof,length(residual),length(modelParam),nnz(fixParam));
% 
% str1 = ['Reduced ChiSq is ',num2str(redchi),'.'];
% logEntry=sprintf('%s \r\n \r\n %s \r\n \r\n %s \r\n \r\n %s',output.message,output.algorithm,str,str1)

%objective functions for solver to solver
    function [myfun]=objfcn(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        modelParam(fixParam)=modelParam0(fixParam);
        
              Ec=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(1,length(nEraw));
        for j=1:length(Ec)
           
            y=y+(A(j)/(w(j)*sqrt(pi/2)))*exp(-2*((cEraw-Ec(j)).^2)/(w(j)^2));
            
            
        end
        
        if ~isempty(stdE)
        myfun=(nEraw-y)./stdE;
        else
        myfun=(nEraw-y);
        end
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
    end

end