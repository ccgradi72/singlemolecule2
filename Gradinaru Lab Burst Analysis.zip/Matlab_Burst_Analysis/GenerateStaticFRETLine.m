function [ mE,rat] = GenerateStaticFRETLine(R0,tauD0,sigmaRDA)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
% clear all
% close all
% clc;
%Generated using SI from Detection of structural dynamics by FRET: A probability distribution and
%fluorescence lifetime analysis of systems with multiple states. Kanlin,
%Seidel J Phys Chem B, 2010, 114, 7983-7995.

% R0=51; %ansgtrom Forster radius
% tauD0=3.75; %ns donor only lifetime
RDA=linspace(0.1*R0,10*R0,200); %vector of "possible" RDA->E-->tauDA
% sigmaRDA=9.55; %sigmaDA eg., from Av simulations for FluoroscienNHSdT and Alexa647NHS averaged for 10bp and 14bp
% sigmaRDA=10; %sigmaDA eg., from Av simulations for FluoroscienNHSdT and Alexa647NHS averaged for 10bp and 14bp
nR=50000; %number of R for each RDA distance distribution

tauDA=tauD0*((1+((R0./RDA).^6)).^-1);
Estatic=(1+((RDA/R0).^6)).^-1;
tauf=zeros(size(RDA));
mE=zeros(size(RDA));

for i=1:length(RDA)
    
    cRDA=RDA(i); %current RDA
    R = normrnd(cRDA,sigmaRDA,1,nR);
    R(R<0)=[];
    numR=length(R);
%     hist(R,25)

    E=(1+((R/R0).^6)).^-1;
    xi=1/numR; %species fraction is just 1/num conformation
    mE(i)=sum(xi*E);
    tau=tauD0*((1+((R0./R).^6)).^-1);
    
    f=(xi*tau)/sum(xi*tau);
    
    tauf(i)=sum(f.*tau);
        
end

rat=tauf/tauD0;
% figure;
% hold all
% plot(Estatic,tauDA/tauD0);
% plot(mE,tauf/tauD0);
% legend('static','dynamic')
% % save('StaticFRET','mE','rat')




end

