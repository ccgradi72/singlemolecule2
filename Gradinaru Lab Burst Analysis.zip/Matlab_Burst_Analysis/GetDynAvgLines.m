function [Rg0,EGC,ESAW,EWLC,TauDAavGC,TauDAavSAW,TauDAavWLC]=GetDynAvgLines(Ro,TauD,Nr,coeff)

% close all
% clear all
% clc

% coeff='100rhc4';
% Ro=55; %nm
% TauD=4;
% Nr=100;


% Rg0=[0.75:0.1:15];
Rg0=linspace(0.1*Ro,5*Ro,2000);
% Rg0=30;
lp=linspace(0.05,10,length(Rg0));
LimSAW=5;
TauDAav=zeros(size(Rg0));
IntAvE=zeros(size(Rg0));
EGC=zeros(size(Rg0));
ESAW=zeros(size(Rg0));
EWLC=zeros(size(Rg0));
t=0:0.1:25; %ns
ItGC=zeros(size(t));
ItSAW=zeros(size(t));
ItWLC=zeros(size(t));
TauDAavGC=zeros(size(Rg0));
TauDAavSAW=zeros(size(Rg0));
TauDAavWLC=zeros(size(Rg0));
% TauD=3.76; %ns
lc=Nr*0.38;

% dr=0.05;
% r=0:dr:4.5*max(Ro);
% r=linspace(0.1*Rg0(j),10*Rg0(j),100);

% Er=1./(1+(r/Ro).^6);


for j=1:length(Rg0)
r=linspace(0.1*Rg0(j),20*Rg0(j),100);
Er=1./(1+(r/Ro).^6);


[PrRgOUT]=PrGaussianChain(r,Rg0(j)^2);

Io=10;

PrGC=PrRgOUT;
[PrRgOUT,w,rc]=PrSim(r,Rg0(j)^2);
PrSAW=SAW_Pr(6.26*Rg0(j),r);
[PrRgOUT]=PrWLC(r,lp(j));
Pr_WLC=PrRgOUT;

EGC(j)=trapz(r,PrGC.*Er);
ESAW(j)=trapz(r,PrSAW.*Er);
EWLC(j)=trapz(r,Pr_WLC.*Er);

% if j==1
%     figure;
%     plot(r,PrGC)
% end


for i=1:length(t)
TauR=TauD*(1-Er);
temp=PrGC.*exp(-t(i)./TauR);
temp(isnan(temp))=0;
ItGC(i)=Io*trapz(r,temp);
temp=PrSAW.*exp(-t(i)./TauR);
temp(isnan(temp))=0;
ItSAW(i)=Io*trapz(r,temp);
temp=Pr_WLC.*exp(-t(i)./TauR);
temp(isnan(temp))=0;
ItWLC(i)=Io*trapz(r,temp);
end

% figure;
% plot(t,ItGC)
% set(gca,'YScale','log')

temp=t.*ItGC;
temp(isnan(temp))=0;
TauDAavGC(j)=(trapz(t,temp))/trapz(t,ItGC);

temp=t.*ItSAW;
temp(isnan(temp))=0;
TauDAavSAW(j)=(trapz(t,temp))/trapz(t,ItSAW);

temp=t.*ItWLC;
temp(isnan(temp))=0;
TauDAavWLC(j)=(trapz(t,temp))/trapz(t,ItWLC);





end

% figure;
% plot(Rg0, TauDAavGC)
% xlabel('Rg')
% ylabel('TauDA')
% figure;
% plot(Rg0,EGC)
% xlabel('Rg')
% ylabel('E')
% figure;
% plot(EGC,TauDAavGC/TauD)
% xlabel('E')
% ylabel('TauDA')

function [PrRgOUT,w,rc]=PrSim(r,Rg2)
        
        
        C=2.02;  %Need to change this
        switch coeff
            case '90'
                %the original n=90 SAW
                Z1=-183.13063;
                B1=25.48613;
                B2=-1.08508;
                B3=0.01984;
                B4=-1.34651E-4;
                
                Z2=3.84207;
                ro=-37.14671;
                
            case '100'
                %the n100 SAW simulations
                Z1=-131.88027;
                B1=15.96999;
                B2=-0.48643;
                B3=0.00434;
                B4=1.0139E-5;
                
                Z2=3.77306;
                ro=-40.08632;
                
            case '100rhc4'
                 %the n100 SAW simulations with r_hc=3.14 angstrom
                Z1=-120.07183;
                B1=15.85754;
                B2=-0.52925;
                B3=0.00531;
                B4=1.02129E-5;
                
                Z2=3.73203;
                ro=-36.02189;
                
            case '100rhc3.14'
                %the n100 SAW simulations with r_hc=3.14 angstrom
                Z1=-107.95168;
                B1=15.29116;
                B2=-0.54329;
                B3=0.00584;
                B4=1.14823E-5;
                
                Z2=3.65224;
                ro=-32.01995;
                
            case 'GaussSim'
                %the n100 Gauss simulation
                Z1=1.68789;
                B1=-0.06726;
                B2=0.37797;
                B3=-0.02918;
                B4=6.38106E-4;
                
                Z2=3.10758;
                ro=-11.85742;
                
             case 'SH3'
                %the n100 Gauss simulation
                Z1=-127.72338;
                B1=22.87784;
                B2=-1.23328;
                B3=0.02843;
                B4=-2.41769E-4;
                
                Z2=3.73356;
                ro=-27.22449;   
                
                
        end
        Rg=sqrt(Rg2); %this will need to be converted to Angstrom (since Jianhui's results are in angstrom)
        
        Rg=Rg*10;
        r=r.*10;
        
        
        w=Z1+B1*Rg + B2*Rg^2 + B3*Rg^3 + B4*Rg^4;
        rc=ro+Z2*Rg;
        
        PrCond1=C/(w*sqrt(pi/2));
        PrCond2=exp(-2*(1/w^2)*(r-rc).^2);
        
        PrRgOUT=PrCond1*PrCond2;
        PrRgOUT=PrRgOUT/trapz(r/10,PrRgOUT); %normalize to unit area
        
    end
  function [PrRgOUT]=PrGaussianChain(r,Rg2)
        PrRg1=4*pi*r.^(2);
        PrRg2=(1/(4*pi*Rg2))^(1.5);
        PrRg3=exp(-(r.^2)/(4*Rg2));
        PrRgOUT=PrRg1.*PrRg2.*PrRg3;
  end

 function [PrRgOUT]=PrWLC(r,lp)
      PrRg1=4*pi*(r/lc).^2;
      PrRg2=lc*(1-(r/lc).^2).^(9/2);
      PrRg3=exp(-3*lc./(4*lp*(1-(r/lc).^2)));
      PrRgOUT=(PrRg1./PrRg2).*PrRg3;
      PrRgOUT=PrRgOUT/trapz(r,PrRgOUT);
 end
% % % % % 
% % % % %     function P=SAW_Pr(R,r)
% % % % %         
% % % % %         a1=0.299;
% % % % %         a2=1.269;
% % % % %         P1=4*pi*r.^(2);
% % % % %         P2=a1./(R.^3);
% % % % %         P3=(r./R).^0.269;
% % % % %         P4=exp(-a2*((r./R).^2.427));
% % % % %         P=P1.*P2.*P3.*P4;
% % % % %         
% % % % %     end
end