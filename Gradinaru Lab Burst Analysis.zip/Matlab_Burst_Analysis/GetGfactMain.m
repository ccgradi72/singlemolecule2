function [folder_name] = GetGfactMain(StartPath)
%UNTITLED2 Does Two things: Get offsets, get bkg removed IRF
%   Detailed explanation goes here

%% Global variables for time resolved
global cal_DPar cal_DPerp cal_APar cal_APerp t0 dt c_Dpar c_Dperp draw_microtimeG MinPhCal Gaa Gdd ALEX talkative T3mode
global c_Apar c_Aperp
% %For testing only
% draw_microtime=1;
% Irf_DPar=zeros(1,256);
% Irf_DPerp=zeros(1,256);
% t0=2.5;
% global ind_Dpar ind_Dperp ALEX numRecords
% ind_Dpar = 1;
% ind_Dperp = 2;
% ALEX = 0;
% numRecords = 50000;
% clc;
% close all;

%% Main Loop to build histogram
%Choose a directory
% StartPath='T:\14_May\2014, May28\Sarah\IRFCoverslip_1720h';
folder_name=uigetdir(StartPath,'Calibration for G factor');
d=dir(fullfile(folder_name,'*.bin'));
sync_count=0;
for i=1:numel(d) %Directory Loop
    if talkative
    sprintf('Analysing Calibration File %f of %f',i,numel(d)) 
    end
   [sync_count]= FileAnalysisCalib(strcat(folder_name,'\',d(i).name),sync_count);
   
   NphDpar=sum(cal_DPar);
   NphDperp=sum(cal_DPerp);
   NphApar=sum(cal_APar);
   NphAperp=sum(cal_APerp);
   
   if talkative
        sprintf('NphDpar = %f \r\n NphDperp=%f',NphDpar,NphDperp)
        if ~ALEX
            sprintf('Warning: NphAPar and NphAperp not due to direct acceptor excitation')
        end
        sprintf('NphApar = %f \r\n NphAperp=%f',NphApar,NphAperp)
    end
   
   if ~ALEX
        if (NphDpar> MinPhCal) && (NphDperp > MinPhCal)
            break
        end
    else
%         if (NphDpar> MinPhCal) && (NphDperp> MinPhCal) && (NphApar> MinPhCal) && (NphAperp> MinPhCal)
        if (NphDpar> MinPhCal) && (NphDperp> MinPhCal)
            break
        end
    end

end %Directory Loop

%% G factor for acceptor:
    %Ideally - this should include a background subtraction.
   if ALEX 
    Gaa=NphApar/NphAperp; %from r=0=(Ipar-G*Iperp)/Itot ==> G=Ipar/Iperp=numPhIperp/numPhIpar
    sprintf('Global Gaa set to %f',Gaa)
   end
   

   %% G factor for donor:
   %from fitting a monoexponential? from NphDpar/NphDperp? %from removing
   %rinf?
   %Remove bkg before G factor calulation?
   
   % %remove bkg
   % bkg_Dpar=mean(cal_DPar(end-floor(5*1E-9/dt):end)) %check out the last 5 ns of histogram
   % bkg_Dperp=mean(cal_DPerp(end-floor(5*1E-9/dt):end))
   % cal_DPar=cal_DPar-bkg_Dpar;
   % cal_DPerp=cal_DPerp-bkg_Dperp;
   
   %% Now we have histogram(s),
   %Apply temporal offsets to donor channel. Doesn't make sense to apply
   %to acceptor because acceptor exc is us modulated.
   if T3mode
       n = length(cal_DPar);
       tv = 1:n;
       tv=tv';
       [cal_DPar]=offsetter(cal_DPar,c_Dpar,tv,n);
       [cal_DPerp]=offsetter(cal_DPerp,c_Dperp,tv,n);
       [cal_APar]=offsetter(cal_APar,c_Apar,tv,n);
       [cal_APerp]=offsetter(cal_APerp,c_Aperp,tv,n);
       
       %Some clean up
       cal_DPar(cal_DPar<0 | isnan(cal_DPar))=0;
       cal_DPerp(cal_DPerp<0 | isnan(cal_DPerp))=0;
        cal_APar(cal_APar<0 | isnan(cal_APar))=0;
       cal_APerp(cal_APerp<0 | isnan(cal_APerp))=0;
       
       if draw_microtimeG
           figure;
           semilogy(1E9*dt*(0:length(cal_DPar)-1),cal_DPar,1E9*dt*(0:length(cal_DPar)-1),cal_DPerp,1E9*dt*(0:length(cal_APar)-1),cal_APar,1E9*dt*(0:length(cal_APar)-1),cal_APerp)
           drawnow
       end
       
       options=optimset('MaxIter',5000,...
           'TolX',1e-10,'Display','Iter');
       
       %Find optimal G
       if draw_microtimeG
           figure;
       end;
       Gdd=fminsearch(@obj_fcn,1,options);
   else
       
       Gdd=NphDpar/NphDperp;
       
   end

testGdd=NphDpar/NphDperp;
testGdd2=sum(cal_DPar(floor(((t0+2)*1E-9)/dt):end))./sum(cal_DPerp(floor(((t0+2)*1E-9)/dt):end));

sprintf('Global Gdd set to %f using fminsearch based calculation',Gdd)
sprintf('Using simple photon counting, G would be %f',testGdd)
sprintf('Using tail matching, G would be %f',testGdd2)

% if draw_microtime
%     %Test plot here
%     figure;
%     plot((0:length(cal_DPar)-1)*dt*1E9,cal_DPar,(0:length(cal_DPar)-1)*dt*1E9,cal_DPerp)
%     title('After bkg subtraction')
% end

    function output=obj_fcn(G)
        %Function to minimize
        [rD] = Aniso(cal_DPar,cal_DPerp,'',G);
        
        output=abs(mean(rD(floor(((t0+2)*1E-9)/dt):end))); %%Dye rot cor time is ~200 ps, 5*200 ps + t0 = t0+1ns later.
        if draw_microtimeG
            
            plot((0:length(rD)-1)*dt*1E9,rD,'k',(0:length(rD)-1)*dt*1E9,zeros(size(rD)),'r')
            
            title('Finding G factor')
            drawnow
        end
    end

end

