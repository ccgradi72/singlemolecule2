function [hCont,hx ,hy,hMain] = Histogram2d(xData,yData,varargin)
%UNTITLED Summary of this function goes here
%   OUTPUTS 
%   hCont is handle of contour plot
%   hx the handle for the x axis marginal histogram
%   hy the handle for the y axis marginal histogram
%   INPUTS
%   xData, yData are the data to be histogramed and plotted
%   Additional control over graphing can be called as follows:
%   [hCont,hx ,hy] = Histogram2d(xData,yData,xRange,yRange,nxBins,nyBins,ncont,xLabelStr,yLabelStr,xPlotRange,yPlotRange,myXtick,myYtick)
%   xRange, yRange are range to consider for histogramming, regardless of
%   plotting.
%   nxBins, nyBins are number of bins for histograms
%   ncont is number of contour levels in 2d contour map
%   xLabelStr and yLabelStr are the labels for the 2d histogram x, y
%   xPlotRange, yPlotRange are the range for plotting, regardless of what
%   range was histogrammed.
%   To not specify an input use [], e.g Histogram2d(xData,yData,xRange,yRange,[],[],ncont,xLabelStr,yLabelStr,xPlotRange,yPlotRange)
%   will use the defaults for nxBins and nyBins.

%% Specifics about plotting

%http://www.rapidtables.com/web/color/RGB_Color.htm
xBackColor=[102 205 170];
xBackColor=xBackColor/255;

yBackColor=[176 224 230];
yBackColor=yBackColor/255;

%% Get Data, create bins, histograms.

xData=xData(:);
yData=yData(:);

DATA=[xData,yData];


if  nargin>2 && ~isempty(varargin{1})
    xRange=varargin{1};
else
    xRange=[min(xData) max(xData)];
end
if  nargin>2 && ~isempty(varargin{2})
    yRange=varargin{2};
else
    yRange=[min(yData) max(yData)];
end

if  nargin>2 && ~isempty(varargin{3})
    nxBins=varargin{3};
else
    nxBins=50;
end

if  nargin>2 && ~isempty(varargin{4})
    nyBins=varargin{4};
else
    nyBins=50;
end

if  nargin>2 && ~isempty(varargin{5})
    ncont=varargin{5};
else
    ncont=5;
end

if  nargin>2 && ~isempty(varargin{6})
    xLabelStr=varargin{6};
else
    xLabelStr='';
end
if  nargin>2 && ~isempty(varargin{7})
    yLabelStr=varargin{7};
else
    yLabelStr='';
end
if  nargin>2 && ~isempty(varargin{8})
    xPlotRange=varargin{8};
else
    xPlotRange=xRange;
end

if  nargin>2 && ~isempty(varargin{9})
    yPlotRange=varargin{9};
else
    yPlotRange=yRange;
end

% myname=varargin{10};
    
xi=xRange(1);
xf=xRange(2);
yi=yRange(1);
yf=yRange(2);

xMin=xPlotRange(1);
xMax=xPlotRange(2);
yMin=yPlotRange(1);
yMax=yPlotRange(2);

if nargin>2 && ~isempty(varargin{10})
    myXtick=varargin{10};
else
    myXtick=linspace(xMin,xMax,4);    
end
if nargin>2 && ~isempty(varargin{11})
    myYtick=varargin{11};
else
    myYtick=linspace(yMin,yMax,4);    
end


dx=(xf-xi)/(nxBins-1);
dy=(yf-yi)/(nyBins-1);

edges{1}=[xi:dx:xf]; % bin for x axis
edges{2}=[yi:dy:yf]; %bin for y axis

n = hist3(DATA,'Edges',edges);
n1 = n';
yb = linspace(yi,yf,size(n,1)+1);
xb = linspace(xi,xf,size(n,1)+1);

[nx,cx] = hist(DATA(:,1),edges{1}); 
[ny,cy] = hist(DATA(:,2),edges{2});

% [nx,cx] = hist(DATA(:,1),xb); 
% [ny,cy] = hist(DATA(:,2),yb);


myxlim=[xi xf];
myylim=[yi yf];


%% Here is where I place the 2d histogram
subplot(2,2,2); 

[C,hCont]=contourf(edges{1},edges{2},n1,ncont);

% zdata=get(hCont,'ZData')
% figure;
% hist(zdata(:))
% zlevel=get(hCont,'LevelList');
% zlevel=zlevel(4:end);
% set(hCont,'LevelList',zlevel)

cm=flipud(gray);
% cm(1:4,:)=[];
colormap(cm);
hold on
h1 = gca;
xlim(gca,xPlotRange)
ylim(gca,yPlotRange)
getxlim=xlim();
getylim=ylim();

hXLabel = xlabel(xLabelStr,'Interpreter','latex');
hYLabel = ylabel(yLabelStr,'Interpreter','latex');
set( gca                       , ...
    'FontName'   , 'Helvetica' );
set([hXLabel, hYLabel], ...
    'FontName'   , 'Helvitica');
set([hXLabel, hYLabel]  , ...
    'FontSize'   , 11          );
hMain=gca;
set(gca, ...
  'Box'         , 'on'     , ...
  'TickDir'     , 'in'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      , ...
  'YGrid'       , 'off'      , ...
  'XColor'      , [.1 .1 .1], ...
  'YColor'      , [.1 .1 .1], ...
  'YTick'       , myYtick, ...
  'XTick'       , myXtick, ...
  'LineWidth'   , 1         );

% if ~isempty(varargin{12})
%     set(gca, 'XTickLabel',varargin{12})
% end
% if ~isempty(varargin{13})
%     set(gca, 'YTickLabel',varargin{13})
% end


%% This will be the x-axis marginal histogram
subplot(2,2,4);
bar(cx,nx,1,'FaceColor', 'k');
hx = gca; 

set(gca,'color',xBackColor)

xlim(getxlim); %links the x axis to that of the contour plot


h2YLabel=ylabel('frequency','Interpreter','latex');

% % trying to scale marginal histogram to give nice appearence
% if max(nx)/2>100
%     y_lim=roundn(max(nx),2);
%     if (y_lim < max(nx))
%         y_lim=y_lim+100; %otherwise histogram is partly cutoff
%     end
% elseif max(nx)>10 %maybe there aren't enough events to scale axis the way I like
%     y_lim=roundn(max(nx),1);
%     if (y_lim < max(nx))
%         y_lim=y_lim+10; %otherwise histogram is partly cutoff
%     end
% else
%     y_lim=max(nx);
% end
% 
% ylim(hx,[0 y_lim]);
y_lim=ylim(gca);
y_lim=y_lim(2);

set(gca, ...
    'Box'         , 'on'     , ...
    'TickDir'     , 'in'     , ...
    'TickLength'  , [.02 .02] , ...
    'XMinorTick'  , 'on'      , ...
    'YMinorTick'  , 'on'      , ...
    'YGrid'       , 'off'      , ...
    'XColor'      , [.1 .1 .1], ...
    'YColor'      , [.1 .1 .1], ...
    'YTick'       , [y_lim/2 y_lim], ... 
    'XTick'       , myXtick, ...
    'XTickLabel'  , [], ...
    'LineWidth'   , 1         );


set( gca                       , ...
    'FontName'   , 'Helvetica' );
set([h2YLabel], ...
    'FontName'   , 'Helvetica');
set(h2YLabel, ...
    'FontSize'   , 8         );

%% the y axis marginal histogram
subplot(2,2,1); 
hold on
barh(cy,ny,1,'FaceColor', 'k'); 
%set(gca,'XDir','reverse') %it will project away from main 2d plot

set(gca,'color',yBackColor)

% [muhat,sigmahat] = normfit(yData)
hy = gca; 
ylim(getylim)

% scale marginal histogram to have nice appearence
if max(ny)>100
    x_lim=roundn(max(ny),2);
    if (x_lim < max(ny))
        x_lim=x_lim+100; %otherwise histogram is partly cutoff
    end
elseif max(ny)>10
    x_lim=roundn(max(ny),1);
    if (x_lim < max(ny))
        x_lim=x_lim+10; %otherwise histogram is partly cutoff
    end
else
    x_lim=round(max(ny));
end

xlim(hy,[0 x_lim]);
h3XLabel=xlabel('frequency','Interpreter','latex');
set(gca, ...
  'Box'         , 'on'     , ...
  'TickDir'     , 'in'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      , ...
  'YGrid'       , 'off'      , ...
  'XColor'      , [.1 .1 .1], ...
  'YColor'      , [.1 .1 .1], ...
  'YTick'       , myYtick, ...
  'XTick'       , [x_lim/2 x_lim], ... 
  'YTickLabel'  , [], ...
  'LineWidth'   , 1         );


set( gca                       , ...
    'FontName'   , 'Helvetica' );
set(h3XLabel, ...
    'FontName'   , 'Helvetica');
set(h3XLabel, ...
    'FontSize'   , 8         );



% [left bottom width height]The left and bottom elements define the 
%distance from the lower-left corner of the container to the lower-left 
%corner of the axes. The width and height elements are the axes dimensions.

L= 0.1; %left
B= 0.1; %bottom
W= 0.55; %2d histogram width (shared with marginal x width)
H=0.55; %2d histogram heigh (shared with marginal y height)
mH=0.15; %marginal histogram height

% gap=0.03;
gap=0.0;

set(h1,'Position',[L B W H]); %main 2d histogram and overlay

%x marginal histogram shares its left edge with 2d hist and has same width
set(hx,'Position',[L B+H+gap W mH]); 
%y marginal histogram shares its bottom edge with 2d hist and has same
%height
set(hy,'Position',[L+W+gap B mH H]); %y marginal histogram




end

