function [Itotal] = Itotal(Ipar,Iperp,exc)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

global Gdd k1 k2 Gaa

Ipar=Ipar(:)';
Iperp=Iperp(:)';

%if Ipar or Iperp was not changed after initialization it will have 256
%elements but the other will likely have less, since we clip after t=Tpp
if length(Ipar)<length(Iperp)
    Iperp=Iperp(1:length(Ipar));
    sprintf('Warning Itotal(): Iperp clipped due to shorter length of Ipar')
elseif length(Iperp)<length(Ipar)
    Ipar = Ipar(1:length(Iperp));
    sprintf('Warning Itotal(): Ipar clipped due to shorter length of Iperp')
end

switch exc
    case 'D'
        G=Gdd;
    case 'd'
        G=Gdd;
    case 'a'
        G=Gaa;
    case 'A'
        G=Gaa;
end

Itotal=((1-3*k2)*(Ipar)+G*(2-3*k1)*Iperp);

% r=(Ipar-G*Iperp)./((1-3*k2)*(Ipar)+G*(2-3*k1)*Iperp);


end

