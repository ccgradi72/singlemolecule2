function [ ] = RASP( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%Notation/method follows closely to Hoffmann et al PCCP 2011
clc;
close all;

hl=0;
NewData=1;

xf=1.2;
xi=-0.2;
nxBins=20;
dx=(xf-xi)/nxBins;
edges{1}=[xi:dx:xf]; % bin for x axis

bin=10;
Erange=edges{1}(bin:bin+1)
Trange=[0 0.2] %in ms
Trange=Trange/1000; %now in s

if exist('BurstWorkstate.mat','file') && ~NewData
    %big BVAfiles take a long time to read text, better to load if you have
    %already worked with this BVAfile already.
    load('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading from .mat file\r\n')
else
    % Find Data
    [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)
end

%DATA is number of bursts by 27 columns with each column representing a
%parameter describing the burst (eg. duration, E, anisotropy, lifetime etc)

%recall bursts were saved as
%currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ...
%        Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...
%        Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...
%        Txd Txa Tdd Tad ...
%        tauD rD rA...
%        Eraw Sraw E S];

% size(DATA)

%Want to extract a subset of bursts (b1,b2) such that the bursts b2 must be
%detected during a time interval between t1 and t2 (the recurrence
%interval) after a a previous burst b1 (the initial burst). Second the
%initial bursts must be in a range  deltaE (the initial E range).

%First throw out parameters not of interest
DATA=DATA(:,[1 2 26]);
% DATA(1,:)

Efull=DATA(:,3);
E_start=DATA(:,3);
E_end=DATA(:,3);
b_start=DATA(:,1);
b_end=DATA(:,2);

%Delete first element of b_start (when first burst starts is irrelevent for
%recurrence since there are no bursts before it)
b_start(1)=[];

%the times in b_start now refer to  t2s t3s... tNs, (tis=time i start) ie these will be the end
%bursts. So do same operation to E_end.
E_end(1)=[];

%Now b_start is length N-1, need to make b_end become length N-1. Since
%there is no burst after burst N, its end time tNe (time i end) is irrelevant, and we can
%delete its last element.
b_end(end)=[];

% the times in b_end now correspond to t1e t2e t3e...tN-1e. So these will
% be the start bursts. Thus, make E_start match.
E_start(end)=[];

%first filter to get all bursts whose E_start is in E range
filt=E_start>=Erange(1) & E_start<= Erange(2);

R_E_start=E_start(filt);
R_b_start=b_start(filt);
R_b_end=b_end(filt);
R_E_end=E_end(filt);

%Next filter by recurrence interval
deltaT=R_b_start-R_b_end;
fprintf('-------------------\r\n')
fprintf('First filter (E1) results \r\n')
fprintf('The number of bursts with initial E in range %f to %f is %f \r\n',Erange(1),Erange(2),length(R_E_start))
fprintf('The average time between bursts with initial E in range %f to %f is %f ms\r\n',Erange(1),Erange(2),mean(deltaT)*1000)
fprintf('The minimum time between bursts with initial E in range %f to %f is %f ms\r\n',Erange(1),Erange(2),min(deltaT)*1000)
fprintf('The maximum time between bursts with initial E in range %f to %f is %f ms\r\n',Erange(1),Erange(2),max(deltaT)*1000)

filt=find(deltaT>=Trange(1) & deltaT<= Trange(2));
R_E_start=R_E_start(filt);
R_b_start=R_b_start(filt);
R_b_end=R_b_end(filt);
R_E_end=R_E_end(filt);
fprintf('-------------------\r\n')
fprintf('Second filter (deltaT) results \r\n')
% fprintf('The final set of burst pairs is of length %f \r\n',length(R_E_end))
deltaT=R_b_start-R_b_end;
fprintf('The number of bursts meeting both conditions is %f \r\n',length(R_E_start))
fprintf('The average time between bursts is %f ms\r\n',mean(deltaT)*1000)
fprintf('The minimum time between bursts is %f ms\r\n',min(deltaT)*1000)
fprintf('The maximum time between bursts is %f ms\r\n',max(deltaT)*1000)
fprintf('The average FRET of E1 bursts is %f \r\n',mean(R_E_start))
fprintf('The minimum FRET of E1 bursts is %f \r\n',min(R_E_start))
fprintf('The maximum FRET of E1 bursts is %f \r\n',max(R_E_start))
fprintf('The average FRET of E2 bursts is %f \r\n',mean(R_E_end))
fprintf('The minimum FRET of E2 bursts is %f \r\n',min(R_E_end))
fprintf('The maximum FRET of E2 bursts is %f \r\n',max(R_E_end))



[nE2,cE2] = hist(R_E_end,edges{1});
[nEfull,cEfull] = hist(Efull,edges{1});
Z=sum(nEfull)/sum(nE2); %normalization
nE2=nE2*Z;

figure;
hold all
h1=bar(cEfull,nEfull,'BarWidth',0.75,'FaceColor', [160 160 160]/255);
h2=bar(cE2,nE2,'BarWidth',0.75,'FaceColor', 'r');
cE2(bin)
nE2(bin)
h3=plot(0.5*(Erange(1)+Erange(2)),nE2(bin),'cd','MarkerFaceColor','k','MarkerSize',11);
ch = get(h2,'child');
set(ch,'facealpha',.3)
% ch = get(h3,'child');
% set(ch,'facealpha',.3)
xlabel('Eraw')
ylabel('Frequency')
title(sprintf('\\Delta E_{1}=[%.2f,%.2f], \\Delta T =[%.3f, %.3f] ms',Erange(1),Erange(2),Trange(1)*1000,Trange(2)*1000))
xlim([xi xf])


end

