function [ind,sstime,timetag,synccount] = ReadT2FilesDouble(fid,Tpp,dt,synccount,numRecords)
%UNTITLED Summary of this function goes here
%   Syncount: the first time this function is called syncount should be 0,
%   but if called multiple times, the synccount output should become
%   synccount input for next call.
%Adapted from:
% PicoHarp 300    File Access Demo in Matlab
% Peter Kapusta, Michael Wahl, PicoQuant GmbH 2006, updated May 2007


ind=zeros(1,numRecords,'uint8');
sstime=zeros(1,numRecords,'uint16');
timetag=zeros(1,numRecords);

% ofltime = synccount;
RESOL=4E-12;   % 4ps
WRAPAROUND=210698240; 


for i=1:numRecords

    T2RecordRead = fread(fid, 1, 'ubit32');     % all 32 bits:
%   +-------------------------------+  +-------------------------------+ 
%   |x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|  |x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|
%   +-------------------------------+  +-------------------------------+  
  
T2time = bitand(T2RecordRead,268435455);       % the lowest 28 bits:
%   +-------------------------------+  +-------------------------------+ 
%   | | | | |x|x|x|x|x|x|x|x|x|x|x|x|  |x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|
%   +-------------------------------+  +-------------------------------+  
  
chan = bitand(bitshift(T2RecordRead,-28),15);   % the upper 4 bits:

%   +-------------------------------+  +-------------------------------+ 
%   |x|x|x|x| | | | | | | | | | | | |  | | | | | | | | | | | | | | | | |
%   +-------------------------------+  +-------------------------------+


if chan==15
    
    markers=bitand(T2RecordRead,15); % where the lowest 4 bits are marker bits
    %   +-------------------------------+  +-------------------------------+ 
    %   | | | | | | | | | | | | | | | | |  | | | | | | | | | | | | |x|x|x|x|
    %   +-------------------------------+  +-------------------------------+
    if markers==0                   % then this is an overflow record
        synccount = synccount + WRAPAROUND; % and we unwrap the time tag overflow
        ind(i)=15;
    else                            % otherwise it is a true marker
        ind(i)=15-markers; %either 11 (15-3) or 13 (15-2) since special marker 1 is reserved for stage
    end;
else
    ind(i)=chan; %regular photon
end

timetag(i)=(T2time+synccount)*RESOL;
   % Strictly, in case of a marker, the lower 4 bits of time are invalid
	% because they carry the marker bits. So one could zero them out. 
	% However, the marker resolution is only a few tens of nanoseconds anyway,
	% so we can just ignore the few picoseconds of error.

end



end

