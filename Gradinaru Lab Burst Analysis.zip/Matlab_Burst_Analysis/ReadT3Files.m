function [ind,sstime,timetag,synccount] = ReadT3Files(fid,Tpp,dt,synccount,numRecords)
%UNTITLED Summary of this function goes here
%   Syncount: the first time this function is called syncount should be 0,
%   but if called multiple times, the synccount output should become
%   synccount input for next call.

%Note example: sst is uint16, dt is double, then sst*dt will still be
%uint16 and appears as zero! This is why I include double(sst)*dt and
%double(Tpp)

ind=zeros(1,numRecords,'uint8');
sstime=zeros(1,numRecords,'uint16');
timetag=zeros(1,numRecords);

for i=1:numRecords
T3RecordRead = fread(fid, 1, 'ubit32=>uint32');     % all 32 bits:
  
%   +-------------------------------+  +-------------------------------+ 
%   |x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|  |x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|
%   +-------------------------------+  +-------------------------------+  
  
nsync = bitand(T3RecordRead,65535);       % the lowest 16 bits:
nsync=uint16(nsync);  
%   +-------------------------------+  +-------------------------------+ 
%   | | | | | | | | | | | | | | | | |  |x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|
%   +-------------------------------+  +-------------------------------+  
  
chan = bitand(bitshift(T3RecordRead,-28),15);   % the upper 4 bits:
chan=uint8(chan);
%   +-------------------------------+  +-------------------------------+ 
%   |x|x|x|x| | | | | | | | | | | | |  | | | | | | | | | | | | | | | | |
%   +-------------------------------+  +-------------------------------+

sst = bitand(bitshift(T3RecordRead,-16),4095);   % the middle 12 bits:
sst=uint16(sst);

%   +-------------------------------+  +-------------------------------+ 
%   | | | | |x|x|x|x|x|x|x|x|x|x|x|x|  | | | | | | | | | | | | | | | | |
%   +-------------------------------+  +-------------------------------+

if  chan==15 && nsync+sst==0
    %An overflow marker
    synccount=synccount+1;
    timetag(i)=0;
    sstime(i)=sst;
    ind(i)=chan;   
elseif chan==15 && sst~=0
    %A special marker
    ind(i)=15-sst; %either 11 (15-3) or 13 (15-2) since special marker 1 is reserved for stage
    sstime(i)=0;
    timetag(i)=(synccount*65536 + double(nsync))*Tpp;
%     whos 'timetag'
else
    %A regular photon
    ind(i)=chan;
    sstime(i)=sst;
    timetag(i)=(synccount*65536 + double(nsync))*Tpp +double(sst)*dt;
%     whos 'timetag'
end

% ind=uint8(ind);
% sst=uint16(sst);

end



end

