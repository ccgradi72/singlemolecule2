function [i_start_out,i_end_out] = SlidingMLT(t,ind)
%UNTITLED3 Summary of this function goes here
%Inspired by Antonio Ingargioli FretBursts MLT code https://fretbursts.readthedocs.io/en/latest/


global M L T global_gamma ind_Dexc ind_Aexc ind_Dpar ind_Dperp ind_Apar ind_Aperp weightbursts ALEX

i_start_out = [];
i_end_out=[];
in_burst = false;


%real photons have ind= 0, 1 ,2, 3, 4, 5   usually 1,2,3,4
tR=t(ind<=5); % no special markers (ind ==15 or 11 or 13)
indR=ind(ind<=5); %R for Real photons
               
above_min_rate = (tR(M:end) - tR(1:length(tR)-M+1)) <= T;

for i=1:length(tR)-M +1
    
    if above_min_rate(i)
        if ~in_burst
            i_start=i;           
            in_burst=true;
        end
    elseif in_burst
        
        in_burst=false;
        i_end=i+M-1; %last photon in current time window
       
%         test=indR(i_start:i_end);
%         numPh=length(test(test~=15|test~=ind_Aexc |test~=ind_Dexc ));

        tempIND=indR(i_start:i_end);
        tempt=tR(i_start:i_end);
        if weightbursts
            if ALEX && 0
                %     fprintf('Sorting Burst Photons by ALEX . . .')
                [indDexc,~,~,indAexc,~,~,~,~] = SortPhotonByALEXReal(tempIND,zeros(size(tempIND)),tempt,[ind_Dexc ind_Aexc]);
                %     fprintf('Sorting Burst Photons by ALEX - [Done]')
                
                %How many photons in each channel after Donor excitation
                Sdd_par=length(indDexc(indDexc==ind_Dpar));
                Sdd_perp=length(indDexc(indDexc==ind_Dperp));
                Sad_par=length(indDexc(indDexc==ind_Apar));
                Sad_perp=length(indDexc(indDexc==ind_Aperp));
                
                %How many photons in each channel after Acceptor excitation
%                 Sda_par=length(indAexc(indAexc==ind_Dpar));
%                 Sda_perp=length(indAexc(indAexc==ind_Dperp));
                Saa_par=length(indAexc(indAexc==ind_Apar));
                Saa_perp=length(indAexc(indAexc==ind_Aperp));
                
                
                numPh=(1/global_gamma)*(Sad_par +Sad_perp) + (Sdd_par + Sdd_perp) + (1/global_gamma)*(Saa_par+Saa_perp);
            else
                Sdd_par=length(tempIND(tempIND==ind_Dpar));
                Sdd_perp=length(tempIND(tempIND==ind_Dperp));
                Sad_par=length(tempIND(tempIND==ind_Apar));
                Sad_perp=length(tempIND(tempIND==ind_Aperp));
                
                numPh=(1/global_gamma)*(Sad_par +Sad_perp) + (Sdd_par + Sdd_perp);
            end
        else
            
            numPh=length(indR(i_start:i_end));
        end


        if numPh >= L  
            
  %i_start_out and i_end_out are the positions in tR and indR where a burst
  %starts, but we want positions in the full photons stream (ie t and ind)
  %Thus, the task is to find the positions in the full stream 
  % Timetags are unique - so find the positions in the full stream (t)
  % which has the same timetag as the identified start-photon in the real
  % stream. (same with end)
           
            i_start_f=find(t==tR(i_start));
            i_end_f=find(t==tR(i_end));
            
            i_start_out=[i_start_out i_start_f];
            i_end_out=[i_end_out i_end_f];
            

        end
        
    end
    
end



end

