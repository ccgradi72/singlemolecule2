clc;
clear all;
close all


TauDA=0:0.1:9;
TauD0=3.7;

%Atto532 and Atto547N
E=1-((-0.0421 +0.508*TauDA + 0.2691*(TauDA.^2) -0.03589*(TauDA.^3))/TauD0);
E2=1-TauDA/TauD0;

plot(E,TauDA/TauD0)
hold all
plot(E2,TauDA/TauD0)

xlim([0 1])
ylim([0 1])