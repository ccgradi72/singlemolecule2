function [index,sstime,timetag] = TrimBurst(index,sstime,timetag,T)
%UNTITLED3 Cut burst photons whose timetag lies outside of T=[Tmin Tmax]
%   Detailed explanation goes here

index(timetag<T(1) | timetag>T(2))=[];
sstime(timetag<T(1) | timetag>T(2))=[];
timetag(timetag<T(1) | timetag>T(2))=[];

end

