function [ ] = UpdateGraphs()
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%One-D histograms
global Eraw_hist Sraw_hist TauD_hist burst_dur_hist InterBurst_hist

%Fluorescence Decay Histograms
global subens_fluorplot

%Anisotropy Decay Histograms
global subens_anisoplot

%2d histograms
global anisotau_hist SrawEraw_hist AsymE_hist

%The data
global AllRecords subEns1_Dpar subEns1_Dperp subEns2_Dpar subEns2_Dperp

%The figure handles so we don't create thousands of graphs
global hTauD hEraw hSraw hBdur hTbwBur hSubFluo hSubAniso



if TauD_hist
    xf=7;
    xi=1;
    nxBins=20;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
%     [nTauD,cTauD] = hist(AllRecords(:,21),edges{1});
     [nTauD,cTauD] = hist(AllRecords(:,21),25);
    
    if ishandle(hTauD)
        bar(hTauD,cTauD,nTauD,'BarWidth',0.75,'FaceColor', 'r');
    else
        figure;
        hTauD= bar(cTauD,nTauD,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Donor Lifetime (ns)')
        ylabel('Frequency')
    end
end

if Eraw_hist
    xf=1.1;
    xi=-0.1;
    nxBins=20;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
%     [nEraw,cEraw] = hist(AllRecords(:,24),edges{1});
    [nEraw,cEraw] = hist(AllRecords(:,24),25);
    if ishandle(hEraw)
        bar(hEraw,cEraw,nEraw,'BarWidth',0.75,'FaceColor', 'r');
    else
        figure;
        hEraw= bar(cEraw,nEraw,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Eraw')
        ylabel('Frequency')
    end
end

if Sraw_hist
    xf=1.1;
    xi=-0.1;
    nxBins=20;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
%     [nSraw,cSraw] = hist(AllRecords(:,25),edges{1});
    [nSraw,cSraw] = hist(AllRecords(:,25),25);
    
    if ishandle(hSraw)
        bar(hSraw,cSraw,nSraw,'BarWidth',0.75,'FaceColor', 'r');
    else
        figure;
        hSraw= bar(cSraw,nSraw,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Sraw')
        ylabel('Frequency')
    end
end

if burst_dur_hist
    xf=500;
    xi=0;
    nxBins=1000;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
%     [nBdur,cBdur] = hist(AllRecords(:,3)*1E6,edges{1});
    [nBdur,cBdur] = hist(AllRecords(:,3)*1E3,50);
    
    if ishandle(hBdur)
        bar(hBdur,cBdur,nBdur,'BarWidth',0.75,'FaceColor', 'r');
    else
        figure;
        hBdur= bar(cBdur,nBdur,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Burst Duration (milliseconds)')
        ylabel('Frequency')
    end
end

if InterBurst_hist
    xf=1000;
    xi=0;
    nxBins=100;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
%     [nTbwBur,cTbwBur] = hist(AllRecords(:,4)*1E3,edges{1});
     [nTbwBur,cTbwBur] = hist(AllRecords(:,4)*1E3,50);
    
    if ishandle(hTbwBur)
        bar(hTbwBur,cTbwBur,nTbwBur,'BarWidth',0.75,'FaceColor', 'r');
    else
        figure;
        hTbwBur= bar(cTbwBur,nTbwBur,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Time Between Bursts (milliseconds)')
        ylabel('Frequency')
    end
end

if subens_fluorplot
    
    if ishandle(hSubFluo)
        plot(hSubFluo,0:4095,Itotal(subEns1_Dpar,subEns1_Dperp,'D'),0:4095,Itotal(subEns2_Dpar,subEns2_Dperp,'D')) 
    else
        figure;
        hSubFluo= plot(0:4095,Itotal(subEns1_Dpar,subEns1_Dperp,'D'),0:4095,Itotal(subEns2_Dpar,subEns2_Dperp,'D'));
        xlabel('TCSPC Channels')
        ylabel('Fluorescence')
        legend('SubEnsemble1','SubEnsemble2')
    end
end

if subens_anisoplot
    
    if ishandle(hSubAniso)
        plot(hSubAniso,0:4095,Aniso(subEns1_Dpar,subEns1_Dperp,'D',[]),0:4095,Aniso(subEns2_Dpar,subEns2_Dperp,'D',[])) 
    else
        figure;
        hSubAniso= plot(0:4095,Aniso(subEns1_Dpar,subEns1_Dperp,'D',[]),0:4095,Aniso(subEns2_Dpar,subEns2_Dperp,'D',[]));
        xlabel('TCSPC Channels')
        ylabel('Anisotropy (No bkg Corr)')
        legend('SubEnsemble1','SubEnsemble2')
    end
end
    


drawnow
end

