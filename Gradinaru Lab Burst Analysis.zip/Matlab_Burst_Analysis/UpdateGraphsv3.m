function [ ] = UpdateGraphsv3(in)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%One-D histograms
% global Eraw_hist Sraw_hist TauD_hist burst_dur_hist InterBurst_hist
% 
% %Fluorescence Decay Histograms
% global subens_fluorplot
% 
% %Anisotropy Decay Histograms
% global subens_anisoplot
% 
% %2d histograms
% global anisotau_hist SrawEraw_hist AsymE_hist
% 

% 
% %The figure handles so we don't create thousands of graphs
% global hTauD hEraw hSraw hBdur hTbwBur hSubFluo hSubAniso

% global fid_burst_txt

% currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ... 4
%     Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ... 10
%     Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ... 16
%     Txd Txa Tdd Tad ... 20
%     tauD rD rA... 23
%     Eraw Sraw E S]; 27

if in
else
close all
end
% global AllRecords
% load('BurstInfo.mat','AllRecords')

% %The data
global AllRecords subEns1_Dpar subEns1_Dperp subEns2_Dpar subEns2_Dperp subEns1_Apar subEns1_Aperp subEns2_Apar subEns2_Aperp currName FRETfilt M L T Lacc

% ReadRecords=textscan(fid_burst_txt,repmat('%f',1,27));

Fd=AllRecords(:,5)+AllRecords(:,6) ;
Fa=AllRecords(:,7)+AllRecords(:,8);
tauD=AllRecords(:,21);
rD=AllRecords(:,22);
Faa=AllRecords(:,9)+AllRecords(:,10);
E=AllRecords(:,24);
S=AllRecords(:,25);
bdur=AllRecords(:,3);

PrefiltNum=length(E)

if FRETfilt
filt=(Fd +Fa <L);  % filter out acceptor only
E(filt)=[];
S(filt)=[];
Faa(filt)=[];
Fd(filt)=[];
Fa(filt)=[];
% Txd(filt)=[];
% Txa(filt)=[];
% Tdd(filt)=[];
% Tad(filt)=[];
tauD(filt)=[];
rD(filt)=[];
bdur(filt)=[];

filt=(Faa<Lacc); % filter out donor only
E(filt)=[];
S(filt)=[];
% Txd(filt)=[];
% Txa(filt)=[];
% Tdd(filt)=[];
% Tad(filt)=[];
tauD(filt)=[];
rD(filt)=[];
bdur(filt)=[];
Faa(filt)=[];
Fd(filt)=[];
Fa(filt)=[];

postFiltNum=length(E)

FRETRATE=postFiltNum/PrefiltNum
end
 
if postFiltNum< 100
    return
end

                                   %Histogram2d(xData,yData,xRange,yRange,nxBins,nyBins,ncont,xLabelStr,yLabelStr,xPlotRange,yPlotRange,myXtick,myYtick,xlabel,ylabel)
figure('visible','off');
%EvsS histogram
if 1
[edgesX2,edgesY2,N] =ndhist(E,S,'axis',[-0.1 1.05 -0.1 1.1],'binsx',0.5,'binsy',0.5);
% [edgesX2,edgesY2,N] =ndhist(Erand,tauRand/TauD,'axis',[-0.05 1.05 -0.05 1.05]);
xlabel('E')
ylabel('S')
xlim([-0.1 1.1])
ylim([-0.1 1.1])
% subplot(2,2,2); 
[Cm,hCont]=contourf(edgesX2,edgesY2,N,5);
cm=flipud(gray);
colormap(cm);
xlabel('E')
ylabel('S')
else
[hCont,hx ,hy,hMain] =Histogram2d(E,S,[-0.05 1.05],[-0.05 1.05],20,20,10,'$\rm E$','$\rm S$',[],[],[0 0.25 0.5 0.75 1],[0 0.25 0.5 0.75 1],{'0','0.25','0.5','0.75','1'},{'0','0.25','0.5','0.75','1'});
% smoothhist2D([E(:) S(:)],5,[100 100])
set(hCont,'LineColor','none')
% set(hMain,'XTick',[0 0.5 1])
% set(hMain,'XTickLabel',{'0'; '0.5'; '1'})
% set(hMain,'YTick',[0 0.5 1])
% set(hMain,'YTickLabel',{'0'; '0.5'; '1'})
end

set(gcf, 'PaperPositionMode', 'auto');

set(gcf,'PaperUnits','inches');
papersizex=6;
papersizey=5;
marginx=0.5;
marginy=0.5;
% fontsizeax=12;
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
           papersizey-2*(marginy)]);
  set(gcf, 'PaperPositionMode','auto');
set(gcf, 'color', 'w');

print('-dpng','-r150',sprintf('%s_EvsSBurstUpdate',currName)); %save in same directory as input data

figure('visible','off');

% [hCont,hx ,hy,hMain] =Histogram2d(Fd+Fa,Faa,[L 100],[L 100],15,15,10,'$\rm Fd+Fa$','$\rm Faa$',[],[],[],[],[],[])
% set(hCont,'LineColor','none')
% % set(hMain,'XTick',[0 0.5 1])
% % set(hMain,'XTickLabel',{'0'; '0.5'; '1'})
% % set(hMain,'YTick',[0 0.5 1])
% % set(hMain,'YTickLabel',{'0'; '0.5'; '1'})
% 
% set(gcf, 'PaperPositionMode', 'auto');
% 
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% % fontsizeax=12;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% 
% print('-dpng','-r150',sprintf('%s_FdvsFaaBurstUpdate',currName)); %save in same directory as input data

figure('visible','off');
%lifetime
subplot(2,2,1)
 xf=10;
    xi=0;
    nxBins=20;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
    [nTauD,cTauD] = hist(tauD(tauD>xi),edges{1});
%      [nTauD,cTauD] = hist(ReadRecords(:,21),25);
    bar(cTauD,nTauD,'BarWidth',0.75,'FaceColor', 'r');
     xlabel('Donor Lifetime (ns)')
        ylabel('Frequency')
        axis tight
        xlim([xi xf])

%burst duration
subplot(2,2,2)
    xf=5;
    xi=T*1E3;
    nxBins=25;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
%     [nBdur,cBdur] = hist(AllRecords(:,3)*1E6,edges{1});
    [nBdur,cBdur] = hist(bdur*1E3,edges{1});
      bar(cBdur,nBdur,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Burst Duration (milliseconds)')
        axis tight
        xlim([xi xf])

subplot(2,2,3)
xf=0.8;
    xi=-0.4;
    nxBins=25;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
%     [nBdur,cBdur] = hist(AllRecords(:,3)*1E6,edges{1});
    [nBdur,cBdur] = hist(rD,edges{1});
      bar(cBdur,nBdur,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Donor Anisotropy')
        axis tight
        xlim([xi xf])

subplot(2,2,4)
% xf=0.8;
%     xi=-0.4;
%     nxBins=25;
%     dx=(xf-xi)/nxBins;
%     edges{1}=[xi:dx:xf]; % bin for x axis
%     [nBdur,cBdur] = hist(AllRecords(:,3)*1E6,edges{1});
    [nBdur,cBdur] = hist((Fd+Fa)./bdur);
      bar(cBdur,nBdur,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Burst Intensity CPS')
        axis tight
%         xlim([xi xf])
 
 
set(gcf, 'PaperPositionMode', 'auto');

set(gcf,'PaperUnits','inches');
papersizex=6;
papersizey=5;
marginx=0.5;
marginy=0.5;
% fontsizeax=12;
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
           papersizey-2*(marginy)]);
  set(gcf, 'PaperPositionMode','auto');
set(gcf, 'color', 'w');

print('-dpng','-r150',sprintf('%s_OtherBurstUpdate',currName)); %save in same directory as input data

        
        
        
% if subens_fluorplot
%     
%     if ishandle(hSubFluo)
%         plot(hSubFluo,0:4095,Itotal(subEns1_Dpar,subEns1_Dperp,'D'),0:4095,Itotal(subEns2_Dpar,subEns2_Dperp,'D')) 
%     else
%         figure;
%         hSubFluo= plot(0:4095,Itotal(subEns1_Dpar,subEns1_Dperp,'D'),0:4095,Itotal(subEns2_Dpar,subEns2_Dperp,'D'));
%         xlabel('TCSPC Channels')
%         ylabel('Fluorescence')
%         legend('SubEnsemble1','SubEnsemble2')
%     end
% end
% 
% if subens_anisoplot
%     
%     if ishandle(hSubAniso)
%         plot(hSubAniso,0:4095,Aniso(subEns1_Dpar,subEns1_Dperp,'D',[]),0:4095,Aniso(subEns2_Dpar,subEns2_Dperp,'D',[])) 
%     else
%         figure;
%         hSubAniso= plot(0:4095,Aniso(subEns1_Dpar,subEns1_Dperp,'D',[]),0:4095,Aniso(subEns2_Dpar,subEns2_Dperp,'D',[]));
%         xlabel('TCSPC Channels')
%         ylabel('Anisotropy (No bkg Corr)')
%         legend('SubEnsemble1','SubEnsemble2')
%     end

%  clear AllRecords   %Why the fuck did I put this here? This is the
%  stupidest thing I have done in a while.


% drawnow

close all
end

