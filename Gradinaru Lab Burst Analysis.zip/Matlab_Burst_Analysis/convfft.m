function c = convfft(a, b)
    P = numel(a);
    Q = numel(b);
    L = P + Q - 1;
    K = 2^nextpow2(L);

    c = ifft(fft(a, K) .* fft(b, K));
    c = c(1:L);
end