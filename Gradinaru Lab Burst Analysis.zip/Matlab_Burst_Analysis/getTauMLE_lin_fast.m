function [tau_out, err_out]=getTauMLE_lin_fast(irf,N,dt,p,c,Tmax)

close all
drawmode=0; %don't draw fitting procedure
%N is the decay to fit.
%c is a color offset in TCSPC channels, which can be varied if known, set to 0 if not known.
%p is the periodicity of the excitation pulse, ie p=Tpp=12.5, 25, 37.5, 50
%etc ns. dt and p must be in the same units. irf and N must be of same
%length.
%An additional assumption is that the bkg contribution is 0%, which is
%close to the actual value when count rates within burst are high.
%Tmax, delete all values after Tmax

%% Make inputs insesnitive to row or column

irf=irf(:);
N=N(:);

%convert dt, p and Tmax all to ns
dt=dt*1E9;
% p=p*1E9;
% Tmax=Tmax*1E9;

%% Rebin to be faster


% finalsize=256;
%     
% %Rebin from k=4096 channels to k=256 channels
% %first zero pad to 4096
% Npad=zeros(4096-length(N),1); %if we don't have 4096 bins (maybe we cut some out) zero pad until 4096 bins
% N=[N; Npad];
% N = sum(reshape(N,4096/finalsize,finalsize) ,1);
% % size(N)
% N=N';
% 
% Npad=zeros(4096-length(irf),1);
% irf=[irf; Npad];
% irf = sum(reshape(irf,4096/finalsize,finalsize) ,1);
% % size(irf)
% 
% dt=(4096/finalsize)*dt; %16 bins are added together to get time bins space 16*dt apart, eg [ 0 0.128 0.256]
N(floor(Tmax/dt):end)=[];
irf(floor(Tmax/dt):end)=[];

% figure;
% plot(0:dt:dt*(finalsize-1),N)

%% Some prep work

p = p/dt; %in channels
n = length(irf);
t = 1:n;
tp = (1:p)';
% c = 0; %color offset, can vary if known
irs = (1-c+floor(c))*irf(rem(rem(t-floor(c)-1, n)+n,n)+1) + (c-floor(c))*irf(rem(rem(t-ceil(c)-1, n)+n,n)+1); %a shifted irf by c channels
IRS=irs/sum(irs); %normalized scatter
Ntot=sum(N);

%% Iteratively searching grid

dtaumin=0.064;

taustart=0.010/dt;
taustop=9/dt;
range=taustop-taustart;
j=1;
while range>dtaumin/dt %we desire an accuracy of 10ps
    
    if drawmode
    hold all
    plot(j,taustart*dt,'ob',j,taustop*dt,'og')
    drawnow 
    j=j+1;
    end
    
    tauv=linspace(taustart,taustop,10); %a grid with  approx 1ns spacing on the first iteration, in TCSPC channel units
    
    err=mlelin(tauv);
    
%     err=zeros(1,length(tauv));
%     for i=1:length(tauv)
%     err(i)=mlelin(tauv(i));     
%     end
    
    if drawmode
    hold all
    plot(tauv*dt,err)
    end
    
    [~,imin]=min(err);
    
    if imin~=1 
    taustart=tauv(imin-1) ;
    end
    if imin~=length(tauv)
    taustop=tauv(imin+1);
    end
    
    range=taustop-taustart;
    tau_out=tauv(imin)*dt; %the tau output is in same units as dt now
    err_out=mlelin(tauv(imin));    
end


%% Functions used.

    function err = mlelin(tau)
        
        
        err=Inf(1,length(tau));
        x = exp(-(tp-1)*(1./tau)); 
        %         X=x./sum(x);
        z = Convol(IRS, x);
        Z=sum(z,1);
        for i=1:length(tau)
            z(:,i)=z(:,i)/Z(i);
        end
        
        %         zz=z/sum(z);
        %         s_zz=size(zz)
        M=Ntot*z; %model function
        M(M<0)=0;
        %         s_M=size(M)
        %         s_N=size(N)
        ind = N>0;
        %         s_Nind=size(N(ind))
        %         s_Mind=size(M(ind))
        for i=1:length(tau)
            err(i) = (2./(length(N(ind))-1-1))*sum(N(ind).*log(N(ind)./M(ind,i))); %only 1 fit parameter
        end
        
        
        
        
        
        
        
        
        
        % % % % % % % %         x = exp(-(tp-1)*(1./tau)); %repetive excitation period
        % % % % % % % %         X=x./sum(x);
        % % % % % % % %         z = Convol(IRS, X);
        % % % % % % % %         zz=z/sum(z);
        % % % % % % % % %         s_zz=size(zz)
        % % % % % % % %         M=Ntot*zz; %model function
        % % % % % % % % %         s_M=size(M)
        % % % % % % % % %         s_N=size(N)
        % % % % % % % %         ind = N>0;
        % % % % % % % % %         s_Nind=size(N(ind))
        % % % % % % % % %         s_Mind=size(M(ind))
        % % % % % % % %         err = (2./(length(N(ind))-1-1))*sum(N(ind).*log(N(ind)./M(ind))); %only 1 fit parameter
        
    end
end



