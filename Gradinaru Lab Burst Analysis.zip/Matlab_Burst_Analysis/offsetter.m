function [I_out]=offsetter(I_in,c,tv,n)

I_out= (1-c+floor(c))*I_in(rem(rem(tv-floor(c)-1, n)+n,n)+1) + (c-floor(c))*I_in(rem(rem(tv-ceil(c)-1, n)+n,n)+1); %shifted by c channels

end

