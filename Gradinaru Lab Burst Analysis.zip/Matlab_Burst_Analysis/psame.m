function [  ] = psame(  )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

clear all
close all
clc

td=0.200 %ms
tau=0.01:td/2:30;
n=1/(45-10);

g=1+(1/n)*(1+tau./td).^(-3/2)

figure;
plot(tau/td,g)

p=1-1./g


figure;
plot(log10(tau/td),p)

ind=find(p<0.9,1,'first');
tau(ind)

end

