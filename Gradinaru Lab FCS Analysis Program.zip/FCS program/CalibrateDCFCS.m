function [ output_args ] = CalibrateFCS( ~ )
%UNTITLED2 This will find w, s based on standard dyes
%   Detailed explanation goes here


%% Preamble
clc;
clear all;
close all;

%user must choose mode
% Construct a questdlg with three options
choice = questdlg('Choose data source', ...
	'Data Source', ...
	'DcFCS','SM-MPF','SM-MPF not combined','DcFCS');
% Handle response
switch choice
    case 'DcFCS'
        disp([choice ' Selected'])
        mode = 1;
        prompt={'Enter the column number with correlation curve to analyze:',...
            'Enter corresponding standard deviation:'};
        name='Correlation Curve Selection';
        numlines=1;
        defaultanswer={'4','8'};
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        FCS_col = str2num(answer{1});
        STD_col = str2num(answer{2});
    case 'SM-MPF'
        disp([choice ' Selected'])
        mode = 2;
        prompt={'Enter the column number with correlation curve to analyze:',...
            'Enter corresponding standard deviation:'};
        name='Correlation Curve Selection';
        numlines=1;
        defaultanswer={'2','7'}; %I found this gives best results
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        FCS_col = str2num(answer{1});
        STD_col = str2num(answer{2});
        case 'SM-MPF not combined'
        disp([choice ' Selected'])
        mode = 3;
        prompt={'Enter the column number with correlation curve to analyze:',...
            'Enter corresponding standard deviation:'};
        name='Correlation Curve Selection';
        numlines=1;
        defaultanswer={'2','3'}; %I found this gives best results
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        FCS_col = str2num(answer{1});
        STD_col = str2num(answer{2});
end


% Construct a questdlg with three options
choice = questdlg('Choose calibration dye', ...
	'Calibration dye', ...
	'R110','R6G','Cy5');
% Handle response
switch choice
    case 'R110'
        disp([choice ' Selected'])
        D = 4.7;
    case 'R6G'
        disp([choice ' Selected'])
        D = 4.14;
    case 'Cy5'
        disp([choice ' Selected'])
        D = 3.6;
end

% mode=1; %mode=1, data is from dcFCS, mode=2 data is from confocal

%text reading
if mode==1
format = repmat('%f', [1 9]); %format for textscan for how many columns, user can change in ui.
hl=0; %header lines in textfiles 
elseif mode==2
format = repmat('%f', [1 8]); %format for textscan for how many columns, user can change in ui.
hl=0; %header lines in textfiles
elseif mode==3
format = repmat('%f', [1 3]); %format for textscan for how many columns, user can change in ui.
hl=0; %header lines in textfiles
end
    
%Plotting
lwthick=2;
lwthin=1;
nhistbin=50; %for residual plot

%% Fitting Preamble

%Solver properties
maxiter=1000;
maxfunevals=5000;
tolfun=1e-6;
tolx=1e-6;
lsqOpt=[maxiter maxfunevals tolfun tolx];

%% Find Data
[FileName,PathName] = uigetfile('*.txt','Select the data file', 'C:\Users\LabUser\Dropbox\Sic1-Cdc4 projects\Analysis\FCS\May 29 2014\');
%To replace with a permament location of text file:
%Example: PathName='E:\May 22 Data\';
%Example:FileName='IRF.txt';

disp('Now analyzing:')
disp(FileName)
disp(PathName)

% Read the file into matrix
fid = fopen(strcat(PathName,FileName));
DATA=textscan(fid,format,'headerlines',hl);
%close(fid)
t=DATA{1}; %A
t=t';
if mode==1
    disp('Fitting data from dcFCS set-up')
    % FCS1=DATA{2}; %B
    % FCS2=DATA{3}; %C
    % FCS3=DATA{4};  %D
    % FCS4=DATA{5}; %E
    % STD1=DATA{6}; %F
    % STD2=DATA{7}; %G
    % STD3=DATA{8}; %H
    % STD4=DATA{9}; %I
    % FCS1=FCS1';
    % FCS2=FCS2';
    % FCS3=FCS3';
    % FCS4=FCS4';
    % STD1=STD1';
    % STD2=STD2';
    % STD3=STD3';
    % STD4=STD4';
    FCS3=DATA{FCS_col};
    STD3=DATA{STD_col};
    FCS3=FCS3';
    STD3=STD3';
elseif mode==2
    
    disp('Fitting data from SM-MPF set-up')
    %SM-MPF data file format (by an adapted version of Yuchongs add up
    %multiple FCS curves program.
    %Col1=Time
    %Col2=MeanACF
    %col3=SDPropagated
    %col4=MeanACFNorm
    %col5=SDACFNorm
    %col6=ReNorm ACF
    %Col7=ReNormSD
    
    
    FCS3=DATA{FCS_col};
    STD3=DATA{STD_col};
    FCS3=FCS3';
    STD3=STD3';
    
    elseif mode==3
    
    disp('Fitting data from SM-MPF set-up')
    %SM-MPF data file format (by an adapted version of Yuchongs add up
    %multiple FCS curves program.
    %Col1=Time
    %Col2=MeanACF
    %col3=SDPropagated
    %col4=MeanACFNorm
    %col5=SDACFNorm
    %col6=ReNorm ACF
    %Col7=ReNormSD
    
    
    FCS3=DATA{FCS_col};
    STD3=DATA{STD_col};
 
    FCS3=FCS3';
    STD3=STD3';
end

%initial guesses, fixing parameters and lowerbound/upperbound constraints
w=250; %in nm 
s=8;
%make a good guess at concentration
Veff=((pi)^(3/2))*((w*10^(-9))^(3))*s %in m^3
Veff=Veff*10^(3) %now in L
G0=mean(FCS3(t<2E-6 & t>1E-7))
Neff=1/G0 %in molecules
Na=6.022E23; %molecules/mol avagadroes number
Neff=Neff/Na; %now in mol
molar=(Neff/Veff)*10^(9) %concentration in (mol/L)*10E-9= nM

model=1; %model =1 gives calibration for volumes, model=2 gives simple diffusion
% molar=10; %in nM 
% D=4.7; %D=4.7 for R110 
tt=10; 
Tr=0.2; 
tt2=1;
Tr2=0;
ginf=0;
name={'$C$ [nM]' '$w$ [nm]' '$s$' '$D$ [$10^{-6}cm^{2}/s$]' '$t_t$ [$\mu$s]' '$T_r$' '$t_{t2}$ [$\mu$s]' '$T_{r2}$'  '$g_{inf}$'};
    modelParam0=[molar w s D tt Tr tt2 Tr2 ginf];
    fixParam=[0 0 0 1 0 0 1 1 1]; %eg [0 0 0 1 0 0 1 1 1 fixes D Tr2 tt2 ginf
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    nParam=length(modelParam0)-nnz(fixParam); %number of free parameters
    lb=[0 0 0 0 0 0 0 0 0]; %lower bounds
    ub=[inf inf inf inf inf 1 inf 1 inf]; %upper bounds
    
%% UI Table for fitting

f = figure('Name','Fitting Parameters and fixing','NumberTitle','off','Position',[200 200 550 500]);
set(f,'CloseRequestFcn',@my_closefcn) %give it a new closing function that will update table values on close of figure

col1 = name'; %param column
col2 = num2cell(modelParam0)'; %value column
col3 = num2cell(logical(fixParam))'; %fix?
col4 = repmat({'-'},size(col3)); %error column
col5 = repmat({'-'},size(col3)); %dependency column
col6 = num2cell(lb)'; %lb
col7 = num2cell(ub)'; %ub

dat=[col1 col2 col3 col4 col5 col6 col7]; %assemble for table

columnformat = {'char', 'numeric', 'logical', 'numeric' 'numeric' 'numeric' 'numeric'};
cnames = {'Param.','Value','Fix?','SD.','Dep.','lb','ub'};
columneditable =  [true true true true true true true];
t1 = uitable('Parent',f,'Data',dat,'ColumnName',cnames,...
    'ColumnFormat', columnformat,...
    'ColumnEditable', columneditable,...
    'RowName',[],...
    'Position',[20 20 530 480]);

%when f is closed, custom close request function updates global variable tabValues
%so wait for f to be deleted before getting the updated tabValues
waitfor(f)

%Get modelParam0 and other table values
% tabValues=get(t,'Data');
modelParam0=cell2mat(tabValues(:,2));
fixParam=cell2mat(tabValues(:,3)); %eg [0 0 0 0 1 0]
fixParam=logical(fixParam); %make sure its logical so it can be used for indexing


lb=cell2mat(tabValues(:,6))
ub=cell2mat(tabValues(:,7))

nParam=length(modelParam0)-nnz(fixParam); %number of free parameters     
    
%Display results so far
%% Choose fitting range
figure;
semilogx(t,FCS3,'LineWidth',lwthick)
xlim([1E-9 0.1])
ylim([0 (max(FCS3)+(1/4)*max(FCS3))])
h = msgbox('Please select a fitting range');
uiwait(h);
[getx, ~] = ginput(2);
% xpos1=floor((getx(1)/dt)+1);
% xpos2=floor((getx(2)/dt)+1);
[~,xpos1]=min(abs(t-getx(1))); %find closest t values
[~,xpos2]=min(abs(t-getx(2)));
if isempty(xpos1)||isempty(xpos2)
    error('fitting range ill-defined')
else
    msgstr=sprintf('Fitting from t=%f to t=%f',t(xpos1),t(xpos2));
    hbox = msgbox(msgstr,'Fitting range');
    uiwait(hbox)
end

%% Call the solver

[modelParam,stdp,dep,redchi,res,logEntry] = FCSSolver(t,FCS3,STD3,modelParam0,fixParam,xpos1,xpos2,lsqOpt,nParam,lb,ub,model);

x=t; %too lazy to re-write equations with t instead of x

%generate best fits from modelParam   
    %Assign Parameters
    molar=modelParam(1)
    w=modelParam(2)
    s=modelParam(3)
    D=modelParam(4)
    tt=modelParam(5)
    Tr=modelParam(6)
    tt2=modelParam(7)
    Tr2=modelParam(8)
    ginf=modelParam(9)
    
    disp('uncertainty of w');
    disp (stdp(2));
    disp('uncertainty of s')
    disp(stdp(3));
    
    const=((molar*6.022*(10^-10)*((pi)^1.5)*(w^3)*s)^(-1));
    diff1=(1+x*(10^8)*4*D/(w^2)).^(-1);
    diff2=(1+x*(10^8)*4*D/(w^2)/(s^2)).^(-0.5);
    trip1=1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt);
    trip2=1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2);
    
    myModel=const*diff1.*diff2.*trip1.*trip2+ginf;
    
%% Generate warning for bad fit or alignment

if s>10
    warningstring=sprintf('s value is greater than 10, s = %f \r\n Check alignment\r\n Overfill or underfill back aperture of objective?',s)
    h = warndlg(warningstring,'Bad alignment')
    uiwait(h)
end
if w>300
    warningstring=sprintf('w value is greater than 300, w = %f \r\n Check alignment\r\n Overfill or underfill back aperture of objective?',w)
    h = warndlg(warningstring,'Bad alignment')
    uiwait(h)
end
if tt<1
    warningstring=sprintf('Triplet time is less than 1 microsecond, tt = %f \r\n Fix Tr to 0',tt)
    h = warndlg(warningstring,'Bad fit')
    uiwait(h)
end

%% Analysis of Residuals 

res(isnan(res))=0;
res(isinf(res))=0;
res=real(res);

[muhatx,sigmahatx] = normfit(res);
[h_x,p_x,stats_x] = runstest(res,'ud','alpha',0.05);
[p2_x,h2_x,stats2_x] = signtest(res,0,'alpha',0.05);
[h3_x,p3_x]=lillietest(res);

str_normfitx=sprintf('Gaussian fit \r\n mu = %f sigma = %f', muhatx,sigmahatx);

if h_x==0
    %residuals are non-random
    runpassfailx='PASS';
else
    %reject null hypothesis that values of residuals come in random order
    runpassfailx='FAIL';
end
str_runstestx=sprintf('Runs Test (Random?) \r\n %s \r\n p-value: %f \r\n nruns: %f \r\n n(+): %f \r\n n(-): %f \r\n z statistic: %f',runpassfailx,p_x,stats_x.nruns,stats_x.n1,stats_x.n0,stats_x.z);

if h2_x==0
    %Fails to reject null hypothesis of zero median
    signpassfailx='PASS';
else
    %Rejects null hypothesis of zero median
    signpassfailx='FAIL';
end

str_signtestx=sprintf('Sign Test (Zero median?) \r\n %s \r\n p-value: %f \r\n test statistic: %f \r\n z statistic: %f',signpassfailx,p2_x,stats2_x.sign,stats2_x.zval);

if h3_x==0
    %Fails to reject null hypothesis
    lilliepassfailx='PASS';
else
    %Rejects null hypothesis that residuals come from normal family
    lilliepassfailx='FAIL';
end

str_lillietestx=sprintf('Lilliefors Test (Normally Distributed?) \r\n %s \r\n p-value: %f',lilliepassfailx,p3_x);

logresx=sprintf('Perpendicular Channel Residual Analysis \r\n \r\n %s \r\n \r\n %s \r\n \r\n %s \r\n \r\n %s',str_normfitx,str_runstestx,str_signtestx,str_lillietestx);

txtbox=sprintf('%s \r\n %s \r\n %s \r\n %s',logEntry,logresx)

%% Plotting
hfig=figure('Name', 'Fitting results');
clf(hfig)
hTabGroup = uitabgroup;
%drawnow;
tab1 = uitab(hTabGroup, 'title','Measured and fitted curves');
a1 = axes('parent', tab1);
cla(a1)

semilogx(t,FCS3,t,myModel,'LineWidth',lwthick)
legend(a1,'Data','Fit','Location','Best')
ylim(a1,[0 1.25*max(myModel)])
xlim(a1,[1E-6 0.1])
xlabel(a1,'Lag (ns)')
ylabel(a1,'Autocorr.')

tab2 = uitab(hTabGroup, 'title','Residuals');
a2=axes('parent', tab2);
cla(a2)
semilogx(t(xpos1:xpos2),res)
line([t(xpos1) t(xpos2)] ,[0 0],'Color','r','LineWidth',lwthick)
legend('Weighted residuals')
xlabel(a2,'Lag (ns)')
ylabel(a2,'weighted residual')

tab3 = uitab(hTabGroup, 'title','Autocorrelation of Residuals');
a3=axes('parent', tab3);
cla(a3)
corp=autom(res);
semilogx(corp(2:end))
xlabel(a3,'lags of residuals')
ylabel(a3,'Autocorrelation')
title('Autocorrelation of residuals')

tab4 = uitab(hTabGroup, 'title','Histogram of Residuals');

a4=axes('parent', tab4);
cla(a4)
hist(res,nhistbin);
hp=histfit(res,nhistbin);
set(hp(2),'LineWidth',lwthick)
title('Histogram of residuals')

%maximize figure on first display
jFrame = get(handle(gcf),'JavaFrame');
jFrame.setMaximized(true);   % to maximize the figure

%% Figure with Table of fit results

f2 = figure('Name','Fitting Parameters and fixing','NumberTitle','off','Position',[200 200 550 500]);

col1 = name'; %param column
col2 = num2cell(modelParam); %value column
col3 = num2cell(logical(fixParam)); %fix?
col4 = num2cell(stdp)'; %value column
col5 = num2cell(dep)'; %value column
col6 = num2cell(lb); %lb
col7 = num2cell(ub); %ub

dat=[col1 col2 col3 col4 col5 col6 col7]; %assemble for table

columnformat = {'char', 'numeric', 'logical', 'numeric' 'numeric' 'numeric' 'numeric'};
cnames = {'Param.','Value','Fix?','SD.','Dep.','lb','ub'};
columneditable =  [true true true true true true true];
t2 = uitable('Parent',f2,'Data',dat,'ColumnName',cnames,...
    'ColumnFormat', columnformat,...
    'ColumnEditable', columneditable,...
    'RowName',[],...
    'Position',[15 20 530 480]);

waitfor(f2)




    button = questdlg('Keep calibration and find another file?','Continue','Yes');
    switch button
        case 'Yes'
            
            %% TEMPORARY TEMPORARY!!!!!!!!!!!!!!!%%%%
            w=repmat(w,[1 2]);
            s=repmat(s,[1 2]);
            %%%%%%%%%%%%%%%%%%%
            FCSFitterThreeCurve(w,s,PathName,mode)
        case 'No'
            disp('Finished')
            close all
        case 'Cancel'
            disp('Finished')
            close all
    end



    function my_closefcn(src,evnt)
        % User-defined close request function
        % to update tabValues global variable
        
        tabValues=get(t1,'Data');
        delete(gcf)
        
    end
end

