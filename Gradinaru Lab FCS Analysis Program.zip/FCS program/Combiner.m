function [ output_args ] = Combiner(varargin)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%% Preamble
clc;
% clear all;
close all;

%Plotting
lwthick=1.75;
papersizex=7;
papersizey=4.72; 
marginx=0.5;
marginy=0.5;
fontsizeax=12;
fontsizeleg=10;
ticksize=12;

disp('-------------------------------------------------------------')

disp('-------------------------------------------------------------')

disp('-------------------------------------------------------------')

disp('----------------Fitting new file -------------------')

disp('-------------------------------------------------------------')



format = repmat('%f', [1 2]); %format for textscan for how many columns, user can change in ui.
format = ['%s' format]
hl=1; %header lines in textfiles

%Normalize and remove Ginf?
Norm=true;

%Plotting
lwthick=1.75;
lwthin=1;
nhistbin=50; %for residual plot
nr=-1; %round residuals plot ticks to power of 10^n

%Display type things to change
% tmax=20; %ns, where does the data become pure noise
ymin=0.0;
ymax=1.1;

t=logspace(-6,-1,1000);

%% Find Data
tfmark=true;
hold all
h=[];
firstIter=true;
modelParamMAT=[];
stdMAT=[];
while tfmark==true;
    if firstIter==true
[FileName,PathName] = uigetfile('*.txt','Select the data file','C:\Users\LabUser\Dropbox\Sic1-Cdc4 projects\Analysis\For Claudiu\Results');
    else
        [FileName,PathName] = uigetfile('*.txt','Select the data file',PathName);
    end
%To replace with a permament location of text file:
%Example: PathName='E:\May 22 Data\';
%Example:FileName='IRF.txt';

disp('Now analyzing:')
disp(FileName)

% Read the file into matrix
[fid,message] = fopen(strcat(PathName,FileName))
DATA=textscan(fid,format,'headerlines',hl)
fclose(fid);
modelParam=DATA{2}
stdParam=DATA{3};

try
modelParamMAT=[modelParamMAT modelParam]
stdMAT=[stdMAT stdParam]
catch
    modelParamMAT=[]
    stdMAT=[]
end

x=t; %too lazy to rewrite equations.

if length(modelParam)==16
    disp('Two component')
    %two component
    %Assign Parameters
    molar=modelParam(1)
    w=modelParam(2)
    s=modelParam(3)
    f1=modelParam(4)
    td=modelParam(5)
    td2=modelParam(6)
    Tr=modelParam(7)
    tt=modelParam(8)
    Tr2=modelParam(9)
    tt2=modelParam(10)
    ginf=modelParam(11)
    
    const=(molar*(10^(-9))*(6.022*10^23)*((pi)^1.5)*(((w*10^(-9))^3)*s*10^3))^(-1);
    diff1=((1+x*(10^6)/td).^(-1));
    diff2=((1+x*(10^6)/td/(s^2)).^(-0.5));
    diff12=((1+x*(10^6)/td2).^(-1));
    diff22=((1+x*(10^6)/td2/(s^2)).^(-0.5));
    trip1=(1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt));
    trip2=(1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2));
    if Norm==true
        myModel=1.*(f1*diff1.*diff2 + (1-f1)*diff12.*diff22);
        myModel=myModel./myModel(1);
    else
        myModel=const.*(f1*diff1.*diff2 + (1-f1)*diff12.*diff22).*trip1.*trip2 +ginf;
    end
else
     disp('One component')
    %one component
    %Assign Parameters
    molar=modelParam(1)
    w=modelParam(2)
    s=modelParam(3)
    td=modelParam(4)
    Tr=modelParam(5)
    tt=modelParam(6)
    Tr2=modelParam(7)
    tt2=modelParam(8)
    ginf=modelParam(9)
    
    const=(molar*(10^(-9))*(6.022*10^23)*((pi)^1.5)*(((w*10^(-9))^3)*s*10^3))^(-1);
    diff1=((1+x*(10^6)/td).^(-1));
    diff2=((1+x*(10^6)/td/s^2).^(-0.5));
    trip1=(1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt));
    trip2=(1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2));
    
    
    if Norm==true
        myModel=1.*diff1.*diff2;
        myModel=myModel./myModel(1);    
    else
        myModel=const.*diff1.*diff2.*trip1.*trip2 +ginf;
    end
end


hi=plot(t,myModel,'LineWidth',lwthick);
h=[h hi];


firstIter=false;
% Construct a questdlg with three options
choice = questdlg('More files?', ...
    'More files?', ...
    'Yes','No','Yes');
% Handle response
switch choice
    case 'Yes'
        %save table
        tfmark=true;
    case 'No'
        %save table
        tfmark=false;
    case 'None'
        disp('No table')
end
% clear fid DATA modelParam FileName PathName
end
%or just continually update plot in loop
set(gca,'XScale','log')
%  hleg=legend('Sic1 90c','pSic1 90c','WD40 + pSic1 90c');


legendentry=1:length(h);
legendentry=5*legendentry;
legendentry=strread(num2str(legendentry),'%s')
hleg=legend(legendentry)
 set(hleg,'FontSize',fontsizeleg)
        
        ylim([ymin ymax])
        xlim([min(t) max(t)])
        hAx1=gca;
        hXLabel1 = xlabel(hAx1,'log($\tau$) [s]','Interpreter','latex');
        hYLabel1 = ylabel(hAx1,'G($\tau$)','Interpreter','latex');
        set( gca                       , ...
            'FontName'   , 'Helvetica' );

        
        %Adjust ticks
% set(gca,'LineWidth', linewidth);
set(gca,'FontSize', ticksize);
% set(gca,'FontWeight','Bold');
set(gca,'TickDir','in', ...
    'TickLength'  , [.02 .02] , ...
                'XMinorTick'  , 'on'      , ...
                'YMinorTick'  , 'on'      , ...
                'YGrid'       , 'off'      , ...
                'XColor'      , [.1 .1 .1], ...
                'YColor'      , [.1 .1 .1], ...
                'LineWidth', 1) ;
set(gca, 'YTick',[0 0.25 0.5 0.75 1])  
set(gca,'YTickLabel',{'0';'0.25';'0.50';'0.75';'1'})
set(gca,'XTick', [1E-6 1E-5 1E-4 1E-3 1E-2 1E-1])
set(gca,'PlotBoxAspectRatio',[2 1 1])
set(gca, 'Box' , 'on' )

        
        %paper position and background color
set(gcf,'PaperUnits','inches');
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
    papersizey-2*(marginy)]);
set(gcf, 'PaperPositionMode','manual');
% set(gcf, 'color', 'w');
set(gcf,'color','none')

%Axes label fonts
set(get(gca,'xlabel'),'FontSize',fontsizeax...
    ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
set(get(gca,'ylabel'),'FontSize',fontsizeax...
    ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
        
        
        
        print('-dpng','-r600','FCScombined')
hold off        
    meanModelParam=mean(modelParamMAT,2)
stdModelParam=std(modelParamMAT,0,2);
stdMean=stdModelParam/sqrt(length(h))

meanFittingSTD=mean(stdMAT,2)

stdPredictionRatio=stdMean./meanFittingSTD %how does the std provided by fitting program compare with measured std of mean from repeated measurements    

figure;
plot(modelParamMAT(6,:),'o')

figure;
plot(1-modelParamMAT(4,:),'o')

figure;
plot(modelParamMAT(14,:),'o')


end

