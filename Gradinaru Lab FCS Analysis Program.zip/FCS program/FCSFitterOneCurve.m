function [ output_args ] = FCSFitterOneCurve(varargin)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%% Preamble
% clc;
% clear all;
% close all;

%IMPROVEMENTS TO DO:
%Guess Ginf from end values and if above a certain value don't fix at zero
%in the suggestion table



disp('-------------------------------------------------------------')

disp('-------------------------------------------------------------')

disp('-------------------------------------------------------------')

disp('----------------Fitting new file -------------------')

disp('-------------------------------------------------------------')

 fbut = figure('Name','Fitting Model','NumberTitle','off','Position',[100 100 310 900]);
% Create the button group.
% hbut = uibuttongroup('Parent',fbut,'visible','on','Position',[20 20 530 480]);
hbut = uibuttongroup('Parent',fbut,'visible','on','Position',[0 0 .9 1],'SelectionChangeFcn',@selcbk);
% Create three radio buttons in the button group.
u0 = uicontrol(hbut,'Style','radiobutton','String','Calibration',...
    'pos',[10 850 500 30],'HandleVisibility','off','Tag','1');
u1 = uicontrol(hbut,'Style','radiobutton','String','Simple Diffusion',...
    'pos',[10 800 500 30],'HandleVisibility','off','Tag','2');
u2 = uicontrol(hbut,'Style','radiobutton','String','Two Component Diffusion',...
    'pos',[10  750 500 30],'HandleVisibility','off','Tag','3');
u3 = uicontrol(hbut,'Style','radiobutton','String','Two Component Three Triplet',...
    'pos',[10  700 500 30],'HandleVisibility','off','Tag','4');
u4 = uicontrol(hbut,'Style','radiobutton','String','One Component Three Triplet',...
    'pos',[10  650 500 30],'HandleVisibility','off','Tag','5');

% Initialize some button group properties. 
% set(hbut,);
set(hbut,'SelectedObject',[]);  % No selection
% set(fbut,'Visible','on');
set(hbut,'Visible','on');
waitfor(gcf) %do not excecute anymore code until fbut has been closed
sprintf('You chose model %f',modell)

%Below is old way of selecting model.
%user must choose model
% Construct a questdlg with three options
% choice = questdlg('Choose a fitting model', ...
%     'Model Selection', ...
%     'Calibration','Simple Diffusion','Two Component Diffusion','Three Triplet');
% % Handle response
% switch choice
%     case 'Calibration'
%         disp([choice ' Selected'])
%         modell = 1;
%         D=4.7;
%     case 'Simple Diffusion'
%         disp([choice ' Selected'])
%         modell = 2;
%     case 'Two Component Diffusion'
%         disp([choice ' Selected'])
%         modell = 3;
%     case 'Other'
%         disp([choice ' Selected'])
%         modell = 4;
% end

try
    mode=varargin{4};
    if mode==1
        disp('dcFCS File Source Selected')
    elseif mode==2
        disp('sm-MPF File Source Selected')
        elseif mode==3
        disp('sm-MPF File Source Selected')
    else
        disp('Error: Not a valid file source')
    end
catch
    %user must choose mode
    % Construct a questdlg with three options
    choice = questdlg('Choose data source', ...
        'Data Source', ...
        'DcFCS','SM-MPF','SM-MPF not combined','DcFCS');
    % Handle response
    switch choice
        case 'DcFCS'
            disp([choice ' Selected'])
            mode = 1;
        case 'SM-MPF'
            disp([choice ' Selected'])
            mode = 2;
            case 'SM-MPF not combined'
            disp([choice ' Selected'])
            mode = 3;
    end
end

%text reading
if mode==1
    format = repmat('%f', [1 9]); %format for textscan for how many columns, user can change in ui.
    hl=0; %header lines in textfiles
    
    prompt={'Enter the column number with correlation curve to analyze:',...
            'Enter corresponding standard deviation:'};
        name='Correlation Curve Selection';
        numlines=1;
        defaultanswer={'4','8'};
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        FCS_col = str2num(answer{1});
        STD_col = str2num(answer{2});
elseif mode==2
    format = repmat('%f', [1 8]); %format for textscan for how many columns, user can change in ui.
    hl=0; %header lines in textfiles
     prompt={'Enter the column number with correlation curve to analyze:',...
            'Enter corresponding standard deviation:'};
        name='Correlation Curve Selection';
        numlines=1;
        defaultanswer={'2','7'}; %I found this gives best results
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        FCS_col = str2num(answer{1});
        STD_col = str2num(answer{2});
        
        elseif mode==3
format = repmat('%f', [1 3]); %format for textscan for how many columns, user can change in ui.
hl=0; %header lines in textfiles
 prompt={'Enter the column number with correlation curve to analyze:',...
            'Enter corresponding standard deviation:'};
        name='Correlation Curve Selection';
        numlines=1;
        defaultanswer={'2','3'}; %I found this gives best results
        answer=inputdlg(prompt,name,numlines,defaultanswer);
        FCS_col = str2num(answer{1});
        STD_col = str2num(answer{2});
end

%Plotting
lwthick=2;
lwthin=1;
nhistbin=50; %for residual plot
nr=-1; %round residuals plot ticks to power of 10^n

%% Fitting Preamble

%Solver properties
maxiter=1000;
maxfunevals=5000;
tolfun=1e-6;
tolx=1e-6;
lsqOpt=[maxiter maxfunevals tolfun tolx];

%% Find Data
try
    [FileName,PathName] = uigetfile('*.txt','Select the data file',varargin{3}); %vargin{3} should be pathname from calibration call
catch
    [FileName,PathName] = uigetfile('*.txt','Select the data file','C:\Users\Owner\Dropbox\Sic1-Cdc4 projects\Analysis\FCS\');
end
%To replace with a permament location of text file:
%Example: PathName='E:\May 22 Data\';
%Example:FileName='IRF.txt';

disp('Now analyzing:')
disp(FileName)

% Read the file into matrix
fid = fopen(strcat(PathName,FileName));
DATA=textscan(fid,format,'headerlines',hl);
%close(fid)
t=DATA{1}; %A
t=t';
if mode==1
    disp('Fitting data from dcFCS set-up')
    %     FCS1=DATA{2}; %B
    %     FCS2=DATA{3}; %C
    %     FCS3=DATA{4};  %D
    %     FCS4=DATA{5}; %E
    %     STD1=DATA{6}; %F
    %     STD2=DATA{7}; %G
    %     STD3=DATA{8}; %H
    %     STD4=DATA{9}; %I
    %     FCS1=FCS1';
    %     FCS2=FCS2';
    %     FCS3=FCS3';
    %     FCS4=FCS4';
    %     STD1=STD1';
    %     STD2=STD2';
    %     STD3=STD3';
    %     STD4=STD4';
    FCS3=DATA{FCS_col};
    STD3=DATA{STD_col};
    FCS3=FCS3';
    STD3=STD3';
elseif mode==2
    disp('Fitting data from SM-MPF set-up')
    %SM-MPF data file format (by an adapted version of Yuchongs add up
    %multiple FCS curves program.
    %Col1=Time
    %Col2=MeanACF
    %col3=SDPropagated
    %col4=MeanACFNorm
    %col5=SDACFNorm
    %col6=ReNorm ACF
    %Col7=ReNormSD
    
    FCS3=DATA{FCS_col};
    STD3=DATA{STD_col};
    FCS3=FCS3';
    STD3=STD3';
    
    elseif mode==3
    
    disp('Fitting data from SM-MPF set-up')
    %SM-MPF data file format (by an adapted version of Yuchongs add up
    %multiple FCS curves program.
    %Col1=Time
    %Col2=MeanACF
    %col3=SDPropagated
    %col4=MeanACFNorm
    %col5=SDACFNorm
    %col6=ReNorm ACF
    %Col7=ReNormSD
    
    
    FCS3=DATA{FCS_col};
    STD3=DATA{STD_col};
 
    FCS3=FCS3';
    STD3=STD3';
end

%% % testttt

if nnz(~isnan(STD3))==0
    %this is the case where STD is all NaN
    %perform coded
    disp('all NAN, STD replaced')
    % Find Data
    try
        [FileName,PathName] = uigetfile('*.txt','Select the data file w std', 'C:\Users\LabUser\Dropbox\Sic1-Cdc4 projects\Analysis\FCS\May 29 2014\');
        % Read the file into matrix
        fid = fopen(strcat(PathName,FileName));
        DATA=textscan(fid,format,'headerlines',hl);
        STD3=DATA{8}; %H
        STD3=STD3';
    catch
        STD3=ones(1,length(STD3)); %replace all NaNs with ones
    end
end

%% initial guesses, fixing parameters and lowerbound/upperbound constraints
% model=3; %model =1 gives calibration for volumes, model=2 gives simple diffusion, model=3 gives two component
molar=10; %in nM
try
    w=varargin{1} %in nm
    s=varargin{2}
catch
    %lets FCSfitter run without running calibration by using this w,s if
    %none is given.
    disp('Using user input w and s')
    w = 222.4729
    
    
    s = 8
    
end


tt=20;
Tr=0.1;
tt2=15;
Tr2=0;
tt3=15;
Tr3=0;
ginf=0;
f1=0.5;

%make a good guess at concentration
Veff=((pi)^(3/2))*((w*10^(-9))^(3))*s %in m^3
Veff=Veff*10^(3) %now in L
G0=mean(FCS3(t<2E-6 & t>1E-7))
Neff=1/G0 %in molecules
Na=6.022E23; %molecules/mol avagadroes number
Neff=Neff/Na; %now in mol
molar=(Neff/Veff)*10^(9) %concentration in (mol/L)*10E-9= nM

%make good guess at td
[~,ind_td]=min(abs(FCS3-(G0/2))); %find index of FCS3 value closest to one half G(0)
td=t(ind_td);
td=td/1E-6 %now in microseconds

% td=100; %td~50 for Att488
td2=td*2.3;

if modell==1 %user chose calibration
    modelParam0=[molar w s D tt Tr tt2 Tr2 ginf];
    fixParam=[0 0 0 1 0 0 1 1 0]; %eg [0 0 0 1 0 0 0 1] fixes D Tr2
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    nParam=length(modelParam0)-nnz(fixParam); %number of free parameters
    lb=[0 0 0 0 0 0 0 0 0]; %lower bounds
    ub=[inf inf inf inf inf inf inf inf inf]; %upper bounds
    
elseif modell==2 %user chose simple diffusion
    name={'$C$ [nM]' '$w$ [nm]' '$s$' '$t_d$ [$\mu$s]' '$T_r$' '$t_t$ [$\mu$s]' '$T_{r2}$' '$t_{t2}$ [$\mu$s]' '$g_{inf}$'};
    modelParam0=[molar w s td Tr tt Tr2 tt2 ginf];
    fixParam=[0 1 1 0 0 0 1 1 1];
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    nParam=length(modelParam0)-nnz(fixParam); %number of free parameters
    lb=[0 0 0 0 0 0 0 0 0]; %lower bounds
    ub=[inf inf inf inf 1 inf 1 inf inf]; %upper bounds
    
elseif modell==3 %user chose simple diffusion two components
    name={'$C$ [nM]' '$w$ [nm]' '$s$' '$f_{1}$' '$t_{d1}$ [$\mu$s]' '$t_{d2}$ [$\mu$s]' '$T_r$' '$t_t$ [$\mu$s]' '$T_{r2}$' '$t_{t2}$ [$\mu$s]' '$g_{inf}$'};
    modelParam0=[molar w s f1 td td2 Tr tt Tr2 tt2 ginf];
    fixParam=[0 1 1 0 0 0 0 0 1 1 0];
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    nParam=length(modelParam0)-nnz(fixParam); %number of free parameters
    lb=[0 0 0 0 0 0 0 0 0 0 0]; %lower bounds
    ub=[inf inf inf 1 inf inf 1 80 1 inf inf]; %upper bounds
    
elseif modell==4 %user chose Two-component diffusion three triplet model
    name={'$C$ [nM]' '$w$ [nm]' '$s$' '$f_{1}$' '$t_{d1}$ [$\mu$s]' '$t_{d2}$ [$\mu$s]' '$T_r$' '$t_t$ [$\mu$s]' '$T_{r2}$' '$t_{t2}$ [$\mu$s]' '$T_{r3}$' '$t_{t3}$ [$\mu$s]' '$g_{inf}$'};
    modelParam0=[molar w s f1 td td2 Tr tt Tr2 tt2 Tr3 tt3 ginf];
    fixParam=[0 1 1 0 0 0 0 0 1 1 1 1 1];
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    nParam=length(modelParam0)-nnz(fixParam); %number of free parameters
    lb=[0 0 0 0 0 0 0 0 0 0 0 0 0]; %lower bounds
    ub=[inf inf inf inf inf inf inf inf inf inf inf inf inf]; %upper bounds
    
elseif modell==5 %user chose simple diffusion three component triplet model
    name={'$C$ [nM]' '$w$ [nm]' '$s$' '$t_{d}$ [$\mu$s]' '$T_r$' '$t_t$ [$\mu$s]' '$T_{r2}$' '$t_{t2}$ [$\mu$s]' '$T_{r3}$' '$t_{t3}$ [$\mu$s]' '$g_{inf}$'};
    modelParam0=[molar w s td Tr tt Tr2 tt2 Tr3 tt3 ginf];
    fixParam=[0 1 1 0 0 0 0 1 1 1 0];
    fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
    nParam=length(modelParam0)-nnz(fixParam); %number of free parameters
    lb=[0 0 0 0 0 0 0 0 0 0 0]; %lower bounds
    ub=[inf inf inf inf inf inf inf inf inf inf inf]; %upper bounds
end

%% UI Table for fitting

f = figure('Name','Fitting Parameters and fixing','NumberTitle','off','Menu','none','Position',[200 200 550 500]);
set(f,'CloseRequestFcn',@my_closefcn) %give it a new closing function that will update table values on close of figure

col1 = name'; %param column
col2 = num2cell(modelParam0)'; %value column
col3 = num2cell(logical(fixParam))'; %fix?
col4 = repmat({'-'},size(col3)); %error column
col5 = repmat({'-'},size(col3)); %dependency column
col6 = num2cell(lb)'; %lb
col7 = num2cell(ub)'; %ub

dat=[col1 col2 col3 col4 col5 col6 col7]; %assemble for table

columnformat = {'char', 'numeric', 'logical', 'numeric' 'numeric' 'numeric' 'numeric'};
cnames = {'Param.','Value','Fix?','SD.','Dep.','lb','ub'};
columneditable =  [true true true true true true true];
t1 = uitable('Parent',f,'Data',dat,'ColumnName',cnames,...
    'ColumnFormat', columnformat,...
    'ColumnEditable', columneditable,...
    'RowName',[],...
    'Position',[20 20 530 480]);

%when f is closed, custom close request function updates global variable tabValues
%so wait for f to be deleted before getting the updated tabValues
waitfor(f)

%Get modelParam0 and other table values
% tabValues=get(t,'Data');
modelParam0=cell2mat(tabValues(:,2));
fixParam=cell2mat(tabValues(:,3)); %eg [0 0 0 0 1 0]
fixParam=logical(fixParam); %make sure its logical so it can be used for indexing


lb=cell2mat(tabValues(:,6))
ub=cell2mat(tabValues(:,7))

nParam=length(modelParam0)-nnz(fixParam); %number of free parameters

%% Choose fitting range
figure;
semilogx(t,FCS3,'LineWidth',lwthick)
xlim([1E-7 1])
ylim([0 (max(FCS3)+(1/4)*max(FCS3))])
h = msgbox('Please select a fitting range');
uiwait(h);
[getx, ~] = ginput(2);
% xpos1=floor((getx(1)/dt)+1);
% xpos2=floor((getx(2)/dt)+1);
[~,xpos1]=min(abs(t-getx(1))); %find closest t values
[~,xpos2]=min(abs(t-getx(2)));
if isempty(xpos1)||isempty(xpos2)
    error('fitting range ill-defined')
else
    msgstr=sprintf('Fitting from t=%f to t=%f',t(xpos1),t(xpos2));
    hbox = msgbox(msgstr,'Fitting range');
    uiwait(hbox)
end

%% Call the solver

[modelParam,stdp,dep,redchi,res,logEntry] = FCSSolver(t,FCS3,STD3,modelParam0,fixParam,xpos1,xpos2,lsqOpt,nParam,lb,ub,modell);

x=t; %too lazy to re-write equations with t instead of x

%generate best fits from modelParam
if modell==1
    
    %Assign Parameters
    molar=modelParam(1)
    w=modelParam(2)
    s=modelParam(3)
    D=modelParam(4)
    tt=modelParam(5)
    Tr=modelParam(6)
    tt2=modelParam(7)
    Tr2=modelParam(8)
    ginf=modelParam(9)
    
    
    const=((molar*6.022*(10^-10)*((pi)^1.5)*(w^3)*s)^(-1)); %why is this const different from simple diff const
    diff1=(1+x*(10^8)*4*D/(w^2)).^(-1);
    diff2=(1+x*(10^8)*4*D/(w^2)/(s^2)).^(-0.5);
    trip1=1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt);
    trip2=1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2);
    
    myModel=const*diff1.*diff2.*trip1.*trip2 +ginf;
    
    
elseif modell==2
    
    %Assign Parameters
    molar=modelParam(1)
    w=modelParam(2)
    s=modelParam(3)
    td=modelParam(4)
    Tr=modelParam(5)
    tt=modelParam(6)
    Tr2=modelParam(7)
    tt2=modelParam(8)
    ginf=modelParam(9)
    
    Dcalc=(w^2)/(400*td)
    w
    td
    RhCalc=rotCorCalc(Dcalc,20)
    
    const=(molar*(10^(-9))*(6.022*10^23)*((pi)^1.5)*(((w*10^(-9))^3)*s*10^3))^(-1);
    diff1=((1+x*(10^6)/td).^(-1));
    diff2=((1+x*(10^6)/td/s^2).^(-0.5));
    trip1=(1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt));
    trip2=(1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2));
    myModel=const.*diff1.*diff2.*trip1.*trip2 +ginf;
    
elseif modell==3
    %Assign Parameters
    molar=modelParam(1)
    w=modelParam(2)
    s=modelParam(3)
    f1=modelParam(4)
    td=modelParam(5)
    td2=modelParam(6)
    Tr=modelParam(7)
    tt=modelParam(8)
    Tr2=modelParam(9)
    tt2=modelParam(10)
    ginf=modelParam(11)
    
    
    Dcalc1=(w^2)/(400*td)
    Dcalc2=(w^2)/(400*td2)
    Dcalc=[Dcalc1 Dcalc2];
    RhCalc1=rotCorCalc(Dcalc1,20)
    RhCalc2=rotCorCalc(Dcalc2,20)
    RhCalc=[RhCalc1 RhCalc2];
    
    const=(molar*(10^(-9))*(6.022*10^23)*((pi)^1.5)*(((w*10^(-9))^3)*s*10^3))^(-1);
    diff1=((1+x*(10^6)/td).^(-1));
    diff2=((1+x*(10^6)/td/(s^2)).^(-0.5));
    diff12=((1+x*(10^6)/td2).^(-1));
    diff22=((1+x*(10^6)/td2/(s^2)).^(-0.5));
    trip1=(1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt));
    trip2=(1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2));
    myModel=const.*(f1*diff1.*diff2 + (1-f1)*diff12.*diff22).*trip1.*trip2 +ginf;
    
elseif modell==4
    %Assign Parameters
    molar=modelParam(1)
    w=modelParam(2)
    s=modelParam(3)
    f1=modelParam(4)
    td=modelParam(5)
    td2=modelParam(6)
    Tr=modelParam(7)
    tt=modelParam(8)
    Tr2=modelParam(9)
    tt2=modelParam(10)
    Tr3=modelParam(11)
    tt3=modelParam(12)
    ginf=modelParam(13)
    
    
    Dcalc1=(w^2)/(400*td)
    Dcalc2=(w^2)/(400*td2)
    Dcalc=[Dcalc1 Dcalc2];
    RhCalc1=rotCorCalc(Dcalc1,20)
    RhCalc2=rotCorCalc(Dcalc2,20)
    RhCalc=[RhCalc1 RhCalc2];
    
    const=(molar*(10^(-9))*(6.022*10^23)*((pi)^1.5)*(((w*10^(-9))^3)*s*10^3))^(-1);
    diff1=((1+x*(10^6)/td).^(-1));
    diff2=((1+x*(10^6)/td/(s^2)).^(-0.5));
    diff12=((1+x*(10^6)/td2).^(-1));
    diff22=((1+x*(10^6)/td2/(s^2)).^(-0.5));
    trip1=(1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt));
    trip2=(1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2));
    trip3=(1+(Tr3/(1-Tr3)).*exp(-x*(10^6)/tt3));
    myModel=const.*(f1*diff1.*diff2 + (1-f1)*diff12.*diff22).*trip1.*trip2.*trip3 +ginf;
    
elseif modell==5
    %Assign Parameters
    molar=modelParam(1)
    w=modelParam(2)
    s=modelParam(3)
    td=modelParam(4)
    Tr=modelParam(5)
    tt=modelParam(6)
    Tr2=modelParam(7)
    tt2=modelParam(8)
    Tr3=modelParam(9)
    tt3=modelParam(10)
    ginf=modelParam(11)
    
    
    Dcalc=(w^2)/(400*td)
    w
    td
    RhCalc=rotCorCalc(Dcalc,20)
    
    const=(molar*(10^(-9))*(6.022*10^23)*((pi)^1.5)*(((w*10^(-9))^3)*s*10^3))^(-1);
    diff1=((1+x*(10^6)/td).^(-1));
    diff2=((1+x*(10^6)/td/(s^2)).^(-0.5));
    trip1=(1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt));
    trip2=(1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2));
    trip3=(1+(Tr3/(1-Tr3)).*exp(-x*(10^6)/tt3));
    myModel=const.*diff1.*diff2.*trip1.*trip2.*trip3 +ginf;
end

%% Warnings
if tt<1
    %we start fitting at 1E-6 usually so <1 does not make sense
    warningstring=sprintf('Triplet time is less than 1 microsecond, tt = %f \r\n Fix Tr to 0',tt)
    h = warndlg(warningstring,'Bad fit')
    uiwait(h)
end

if modell~=5
    if Tr+Tr2>=1
        %triplet fractions describe populations
        warningstring=sprintf('Triplet fraction 1 + Triplet fraction 2 is greater than or equal to 1\r\n Tr+Tr2 = %f',(Tr+Tr2))
        h = warndlg(warningstring,'Bad fit?')
        uiwait(h)
    end
else
    if Tr+Tr2+Tr3>=1
        %triplet fractions describe populations
        warningstring=sprintf('Triplet fraction 1 + Triplet fraction 2 +Triplet 3 is greater than or equal to 1\r\n Tr+Tr2+Tr3 = %f',(Tr+Tr2 +Tr3))
        h = warndlg(warningstring,'Bad fit?')
        uiwait(h)
    end
end

if tt>=td||tt2>td
    warningstring=sprintf('One or more triplet times are greater than diffusion times \r\n Largest tt = %f',max(tt,tt2))
    h = warndlg(warningstring,'Bad fit?')
    uiwait(h)
end

if max(td,td2)/min(td,td2)<1.6
    warningstring=sprintf('Diffusion times are not well seperated (must be >=1.6 Vogel Biophys J. 1999) \r\n ratio = %f',(max(td,td2)/min(td,td2)))
    h = warndlg(warningstring,'Bad fit?')
    uiwait(h)
end

%% For binding studies
% 
% %Expected results from theory
% MWSic1=10;% kDA
% MWWD40=40; %
% [Ratio,TauComplex]=RatioCalc(MWSic1,MWWD40,td);
% disp('                ')
% disp('                ')
% disp('                ')
% disp('For binding studies:')
% theorymsg=sprintf('The complex should diffuse %f times slower with tdComplex= %f',1/Ratio, TauComplex)

%% Analysis of Residuals

res(isnan(res))=0;
res(isinf(res))=0;
res=real(res);

[muhatx,sigmahatx] = normfit(res);
[h_x,p_x,stats_x] = runstest(res,'ud','alpha',0.05);
[p2_x,h2_x,stats2_x] = signtest(res,0,'alpha',0.05);
[h3_x,p3_x]=lillietest(res);

str_normfitx=sprintf('Gaussian fit \r\n mu = %f sigma = %f', muhatx,sigmahatx);

if h_x==0
    %residuals are non-random
    runpassfailx='PASS';
else
    %reject null hypothesis that values of residuals come in random order
    runpassfailx='FAIL';
end
str_runstestx=sprintf('Runs Test (Random?) \r\n %s \r\n p-value: %f \r\n nruns: %f \r\n n(+): %f \r\n n(-): %f \r\n z statistic: %f',runpassfailx,p_x,stats_x.nruns,stats_x.n1,stats_x.n0,stats_x.z);

if h2_x==0
    %Fails to reject null hypothesis of zero median
    signpassfailx='PASS';
else
    %Rejects null hypothesis of zero median
    signpassfailx='FAIL';
end

str_signtestx=sprintf('Sign Test (Zero median?) \r\n %s \r\n p-value: %f \r\n test statistic: %f \r\n z statistic: %f',signpassfailx,p2_x,stats2_x.sign,stats2_x.zval);

if h3_x==0
    %Fails to reject null hypothesis
    lilliepassfailx='PASS';
else
    %Rejects null hypothesis that residuals come from normal family
    lilliepassfailx='FAIL';
end

str_lillietestx=sprintf('Lilliefors Test (Normally Distributed?) \r\n %s \r\n p-value: %f',lilliepassfailx,p3_x);

logresx=sprintf('Perpendicular Channel Residual Analysis \r\n \r\n %s \r\n \r\n %s \r\n \r\n %s \r\n \r\n %s',str_normfitx,str_runstestx,str_signtestx,str_lillietestx);

txtbox=sprintf('%s \r\n %s \r\n %s \r\n %s',logEntry,logresx)

%% Plotting
hfig=figure('Name', 'Fitting results');
clf(hfig)
hTabGroup = uitabgroup;
%drawnow;
tab1 = uitab(hTabGroup, 'title','Measured and fitted curves');
a1 = axes('parent', tab1);
cla(a1)

semilogx(t,FCS3,t,myModel,'LineWidth',lwthick)
legend(a1,'Data','Fit','Location','Best')
% ylim(a1,[1E-4 1])
xlim(a1,[1E-7 1])
xlabel(a1,'Lag (ns)')
ylabel(a1,'Autocorr.')

tab2 = uitab(hTabGroup, 'title','Residuals');
a2=axes('parent', tab2);
cla(a2)
semilogx(t(xpos1:xpos2),res)
line([t(xpos1) t(xpos2)] ,[0 0],'Color','r','LineWidth',lwthick)
legend('Weighted residuals')
xlabel(a2,'Lag (ns)')
ylabel(a2,'weighted residual')

tab3 = uitab(hTabGroup, 'title','Autocorrelation of Residuals');
a3=axes('parent', tab3);
cla(a3)
corp=autom(res);
plot(corp(2:end))
xlabel(a3,'lags of residuals')
ylabel(a3,'Autocorrelation')
title('Autocorrelation of residuals')

tab4 = uitab(hTabGroup, 'title','Histogram of Residuals');

a4=axes('parent', tab4);
cla(a4)
hist(res,nhistbin);
hp=histfit(res,nhistbin);
set(hp(2),'LineWidth',lwthick)
title('Histogram of residuals')

%maximize figure on first display
jFrame = get(handle(gcf),'JavaFrame');
jFrame.setMaximized(true);   % to maximize the figure

%% Figure with Table of fit results

f2 = figure('Name','Fitting Parameters and fixing','NumberTitle','off','Menu','none','Position',[200 200 550 500]);

col1 = name'; %param column
col2 = num2cell(modelParam); %value column
col3 = num2cell(logical(fixParam)); %fix?
col4 = num2cell(stdp)'; %value column
col5 = num2cell(dep)';%value column
col6 = num2cell(lb); %lb
col7 = num2cell(ub); %ub

dat=[col1 col2 col3 col4 col5 col6 col7]; %assemble for table

columnformat = {'char', 'numeric', 'logical', 'numeric' 'numeric' 'numeric' 'numeric'};
cnames = {'Param.','Value','Fix?','SD.','Dep.','lb','ub'};
columneditable =  [true true true true true true true];
t2 = uitable('Parent',f2,'Data',dat,'ColumnName',cnames,...
    'ColumnFormat', columnformat,...
    'ColumnEditable', columneditable,...
    'RowName',[],...
    'Position',[15 20 530 480]);

waitfor(f2)

%% Saving things
button = questdlg('Save presentation quality image','Save?','Yes');
switch button
    case 'Yes'
        
        
        
        %create image
        hfig2=figure('Name', 'Fitting results');
        clf(hfig2)
        
        % Bottom plot
        subplot(2,1,2)
        %             hold on
        semilogx(t,FCS3,t(xpos1:xpos2),myModel(xpos1:xpos2),'LineWidth',lwthick)
        legend('Data','Fit','Location','Best')
        ylim([0 1.25*max(myModel)])
        xlim([1E-7 1])
        hAx1=gca;
        hXLabel1 = xlabel(hAx1,'\bf $\tau$ [s]','Interpreter','latex');
        hYLabel1 = ylabel(hAx1,'\bf G($\tau$)','Interpreter','latex');
        set( gca                       , ...
            'FontName'   , 'Helvetica' );
        
        
        % The top plot
        subplot(2,1,1)
        hold on
        line([t(xpos1) t(xpos2)] ,[0 0],'Color','r','LineWidth',lwthick)
        semilogx(t(xpos1:xpos2),res,'LineWidth',lwthick)
        hold off
        ylim([-max(abs(res)) max(abs(res))])
        xlim([1E-7 1])
        hAx2=gca;
        set(hAx2,'XScale','log');
        %             hXLabel2 = xlabel(hAx2,'\bf $\tau$ [s]','Interpreter','latex');
        hXLabel2 = xlabel(hAx2,'','Interpreter','latex');
        hYLabel2 = ylabel(hAx2,'\bf res.','Interpreter','latex');
        set( gca                       , ...
            'FontName'   , 'Helvetica' );
        
        
        try
            set(hAx1,'YTick', roundn(linspace(0,max(ylim(hAx1)),4),-1),'YColor', [0.3 0.3 0.3])
        catch
            try
            set(hAx1,'YTick', roundn(linspace(0,max(ylim(hAx1)),4),-2),'YColor', [0.3 0.3 0.3])
            catch
                set(hAx1,'YColor', [0.3 0.3 0.3])
            end
        end
        %              set(hAx2,'YTick',[-roundn(max(abs(res)),nr) 0 roundn(max(abs(res)),nr)],'YColor', [0.3 0.3 0.3])
        if max(abs(res))<1
            set(hAx2,'YTick',[-0.6 0 0.6],'YColor', [0.3 0.3 0.3])
        else
            set(hAx2,'YTick',[-2 0 2],'YColor', [0.3 0.3 0.3])
        end
        set(hAx1,'XTick', [1e-7 1E-6 1E-5 1E-4 1E-3 1E-2 1E-1 1])
        set(hAx2,'XTick', [1e-7 1E-6 1E-5 1E-4 1E-3 1E-2 1E-1 1])
        
        set([hXLabel1, hYLabel1,hXLabel2,hYLabel2], ...
            'FontName'   , 'AvantGarde');
        
        set([hXLabel1, hYLabel1,hXLabel2,hYLabel2]  , ...
            'FontSize'   , 12          );
        
        
        set(hAx1, ...
            'Box'         , 'on'     , ...
            'TickDir'     , 'in'     , ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'on'      , ...
            'YMinorTick'  , 'on'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.3 .3 .3], ...
            'YColor'      , [.3 .3 .3], ...
            'LineWidth'   , 2         );
        set(hAx2, ...
            'Box'         , 'on'     , ...
            'TickDir'     , 'in'     , ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'on'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.3 .3 .3], ...
            'YColor'      , [.3 .3 .3], ...
            'XTickLabel'  , [], ...
            'LineWidth'   , 2         );
        
        left1=0.1;
        left2=left1;
        width1=0.85;
        width2=width1;
        
        height1=0.55;
        height2=0.15;
        
        bottom1=0.15;
        bottom2=bottom1+height1+0.03;
        
        
        % set(hAx1,'Position',[0.08 0.1 0.75 0.55]); %1
        % set(hAx2,'Position',[0.08 .68 0.75 .15]); %2
        set(hAx1,'Position',[left1 bottom1 width1 height1]); %1
        set(hAx2,'Position',[left2 bottom2 width2 height2]); %2
        
        
        set(gcf, 'PaperPositionMode', 'auto');
        imgname=strcat(PathName,FileName(1:end-4));
        if ~exist(imgname,'file');
        print('-dpng','-r300',imgname)
        else
            b=questdlg('The file allready exist', 'Do you want to overwrite', ...
                'Yes','No','No');
            switch b
                case 'Yes'
                    print('-dpng','-r300',imgname)
                case 'No'
                    if isnumeric(str2double(imgname(end)))
                        apnd=str2double(imgname(end))+1;
                        imgname(end)=num2str(apnd);
                        disp(imgname)
                    else
                        imgname(end+1)='1';
                        disp(imgname)
                    end
                    
            end
        end
        
        
    case 'No'
        disp('No image saved')
    case 'Cancel'
        disp('No image saved')
end

%user must choose mode
% Construct a questdlg with three options
choice = questdlg('Save table of fits?', ...
    'Fitting Table', ...
    'LaTex','Tab Dlm','None','LaTex');
% Handle response
switch choice
    case 'LaTex'
        %save table
        tablemaker(name,modelParam,stdp,RhCalc,Dcalc,redchi)
    case 'Tab Dlm'
        %save table
        tablemakerUNFORMAT(name,modelParam,stdp,RhCalc,Dcalc,redchi)
    case 'None'
        disp('No table')
end



button = questdlg('Keep calibration and find another file?','Continue','Yes');
switch button
    case 'Yes'
        FCSFitterOneCurve(w,s,PathName)
    case 'No'
        disp('Finished')
    case 'Cancel'
        disp('Finished')
end


    function []=tablemaker(names,modelParamf,stdf,Rh,D,redchisq)
        
        mystring=strcat(PathName,FileName(1:end-4),'_LATEX_TABLE.txt');
        if ~exist(mystring,'file');
            fileID = fopen(mystring,'w');
        else
            z=questdlg('The file allready exist', 'Do you want to overwrite', ...
                'Yes','No','No');
            switch z
                case 'Yes'
                    fileID = fopen(mystring,'w');
                case 'No'
                    if isnumeric(str2double(mystring(end-4)))
                        apnd2=str2double(mystring(end-4))+1;
                        mystring=strcat(mystring(1:end-5),num2str(apnd2),mystring(end-4:end));
                        disp(mystring)
                    else
                        mystring(end+1)='1';
                        disp(mystring)
                    end
                    
            end
        end
        
        fprintf(fileID,'\\centering \r\n');
        fprintf(fileID,'\\begin{tabular}{ccc} \r\n');
        fprintf(fileID,'\\hline \\bf Param. & \\bf Fit & \\bf Std. \\\\ \r\n \\hline ');
        for i=1:length(modelParamf)
            if modelParamf(i)<1E-13
                fprintf(fileID,'%s & 0  & 0 \\\\ \r\n',names{i});
            elseif stdf(i)==0
                fprintf(fileID,'%s & %.2f  & 0  \\\\ \r\n',names{i},modelParamf(i));
            else
                fprintf(fileID,'%s & %.2f  & %.2f  \\\\ \r\n',names{i},modelParamf(i),stdf(i));
            end
            
        end
        if length(Rh)==1
            fprintf(fileID,'\\hline $R_{h}$ [�] & %.2f  &  \\\\ \r\n',Rh);
            fprintf(fileID,'$D$ & %.2f  &  \\\\ \r\n',D);
        elseif length(Rh)==2
            fprintf(fileID,'\\hline $R_{h1}$ [�] & %.2f  &  \\\\ \r\n',Rh(1));
            fprintf(fileID,'$D_{1}$ & %.2f  &  \\\\ \r\n',D(1));
            fprintf(fileID,'$R_{h2}$ [�] & %.2f  &  \\\\ \r\n',Rh(2));
            fprintf(fileID,'$D_{2}$ & %.2f  &  \\\\ \r\n',D(2));
        end
        fprintf(fileID,'\\hline $\\chi^{2}_{\\nu}$ & %.2f  &  \\\\ \r\n',redchisq);
        fprintf(fileID,'\\hline \r\n');
        fprintf(fileID,'\\end{tabular}  \r\n');
        
        fclose(fileID);
        
    end

    function []=tablemakerUNFORMAT(names,modelParamf,stdf,Rh,D,redchisq)
        
%         mystring=strcat(FileName(1:end-4),'_TABLE.txt');
%         fileID = fopen(strcat(PathName,mystring),'w');
        
        mystring=strcat(PathName,FileName(1:end-4),'_TABLE.txt');
        if ~exist(mystring,'file');
            fileID = fopen(mystring,'w');
        else
            z=questdlg('The file allready exist', 'Do you want to overwrite', ...
                'Yes','No','No');
            switch z
                case 'Yes'
                    fileID = fopen(mystring,'w');
                case 'No'
                    if isnumeric(str2double(mystring(end-4)))&& ~isnan(str2double(mystring(end-4)))
                        apnd2=str2double(mystring(end-4))+1;
                        mystring(end-4)=num2str(apnd2);
                        fileID = fopen(mystring,'w');
                    else
                        mystring=strcat(mystring(1:end-4),'1',mystring(end-3:end));
                        fileID = fopen(mystring,'w');
                    end
                    
            end
        end
        
        
        fprintf(fileID,'Param.\tFit\tStd.\r\n');
        for i=1:length(modelParamf)
            if modelParamf(i)<1E-13 %this parameter was likely fixed around 0
                fprintf(fileID,'%s\t0\t0\r\n',names{i});
            elseif stdf(i)==0 %this paramater was fixed
                fprintf(fileID,'%s\t%.2f\t0\r\n',names{i},modelParamf(i));
            else %normal writing
                fprintf(fileID,'%s\t%.2f\t%.2f\r\n',names{i},modelParamf(i),stdf(i));
            end
            
        end
        if length(Rh)==1
            fprintf(fileID,'R_{h}\t%.2f\r\n',Rh);
            fprintf(fileID,'D\t%.2f\r\n',D);
        elseif length(Rh)==2
            fprintf(fileID,'R_{h1}\t%.2f\r\n',Rh(1));
            fprintf(fileID,'D_{1}\t%.2f\r\n',D(1));
            fprintf(fileID,'R_{h2}\t%.2f\r\n',Rh(2));
            fprintf(fileID,'D_{2}\t%.2f\r\n',D(2));
        end
        fprintf(fileID,'chi^{2}\t%.2f\r\n',redchisq);
        fclose(fileID);
        
    end

    function [Rh]=rotCorCalc(D,T)
        D=D*1E-6; %D is now in cm^2/s
        D=D/(100*100); %D is now in m^2/s
        k=1.3807E-23;%Boltzman constant J/K
        %eta=1; %the viscosity in cP;
        T=T+273.15; %T in Kelvin
        A=2.414E-5; %Pa*S
        B=247.8;
        C=140;
        eta=A*10^(B/(T-C)); %Pa*s
        eta=1.05;
        eta=eta*10^(-3); %convert to Pa*s
        %T=25; %temperature in celsius
        
        
        Rh=k*T/(6*pi*eta*D);
        %J/(Pa*s*m^2/s)=J/(Pa*m^2)={N*m}/({N/m^2}*m^2)=N*m/N=m
        
        Rh=Rh/(1E-10); %from m to angstrom
        
    end

    function [Ratio,TauComplex]=RatioCalc(MW1,MW2,TauFree)
        
        %MW1= free ligand
        %MW2= Free substrate
        
        MWComplex=MW1+MW2;
        Ratio=(MW1/MWComplex)^(1/3);
        TauComplex=TauFree/Ratio;
        
        
    end

    function my_closefcn(src,evnt)
        % User-defined close request function
        % to update tabValues global variable
        
        tabValues=get(t1,'Data');
        delete(gcf)
        
    end

    function selcbk(source,eventdata)
%         disp(source);
%         disp([eventdata.EventName,'  ',...
%             get(eventdata.OldValue,'String'),'  ', ...
%             get(eventdata.NewValue,'String')]);
        disp('Model:')
        disp(get(get(source,'SelectedObject'),'String'));
        modell=str2double(get(get(source,'SelectedObject'),'Tag'));
    end

end

