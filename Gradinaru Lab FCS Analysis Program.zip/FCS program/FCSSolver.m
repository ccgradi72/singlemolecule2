function [modelParam,stdp,dep,redchi,residual,logEntry] = FCSSolver(x,FCS,STD,modelParam0,fixParam,xpos1,xpos2,lsqOpt,nparam,lb,ub,model)
%UNTITLED2 Summary of this function goes here
%   x - time vector

%   modelParam0 - vector of initial guesses
%   fixParam - logical vector of which parameters to fix
%   xpos1:xpos2 - fitting range for chi sq minimization
%   lsqOpt - options for lsqnonlin

%   nparam - cell array containing the number of paramters in each model

%Set options for solver
%lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');

% if nnz(~isnan(STD))==0
%     %this is the case where STD is all NaN
%     %perform coded
%     disp('all NAN')
%     STD=ones(1,length(STD)); %replace all NaNs with ones
% end

%the "heart" of the solver
if model==1 %user chose calibration
    
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCal,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnCal,modelParam0,[],[],options);
    end
elseif model==2 %user chose simple difusion
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnSimp,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnSimp,modelParam0,[],[],options);
    end
elseif model==3 %user chose two component
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnTwoComp,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnTwoComp,modelParam0,[],[],options);
    end
    
elseif model==4 %user chose two component
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnThreeTrip,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnThreeTrip,modelParam0,[],[],options);
    end
    
elseif model==5 %user chose two component
    if ~isempty(ub)||~isempty(lb)
        %if there are any upper or lower bounds, use them
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnOneDifThreeTrip,modelParam0,lb,ub,options);
    else
        %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
        [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnThreeTrip,modelParam0,[],[],options);
    end 
end

%errors of fit
dof = length(residual)-nparam;
redchi=resnorm/dof;
Jacobianf=full(jacobian); %lsqnonlin returns  Jacobian as sparse matrix
Jacobianf(:,fixParam)=[]; %the columns corresponding to fixed parameters should be deleted to avoid singular Jacobian inverse problem
varp=resnorm*((Jacobianf'*Jacobianf)^-1)/dof;
stdp=sqrt(diag(varp));

cinv=diag(varp^-1);
c=diag(varp);

dep=1-(1./cinv.*c);%if eqn is overparameterized a mutual dependency exists
%values close to 1 indicate strong dependnency
dep=dep';
%if some parameters are fixed, must rewritre stdp vector
ind=find(fixParam); % eg, fixp= [1 0 0 0 1 0 1] Rinf and bgx fixed at zero
% ind =[1,5,7]
%stdp=[2 3 4 6] but should be [0 2 3 4 0 6 0]
stdp=stdp';
if ~isempty(ind)
    for i=1:nnz(fixParam) %three iterations in thsi example
        if ind(i)==1
            stdp=[0 stdp]; %=[0 2 3 4 6] on iteration 1
            dep=[0 dep];
        elseif ind(i)==length(fixParam)
            stdp=[stdp 0]; %=[0 2 3 4 0 6 0]
            dep=[dep 0];
        else
            stdp=[stdp(1:ind(i)-1) 0 stdp(ind(i):end)];
            %=[1 2 3 4 0 6] on iteration 2
            dep=[dep(1:ind(i)-1) 0 dep(ind(i):end)];
        end
    end
end


str=sprintf('The dof = %f = length residual %f - number of parameters %f + number of fixed parameters %f',dof,length(residual),length(modelParam),nnz(fixParam));

str1 = ['Reduced ChiSq is ',num2str(redchi),'.'];
logEntry=sprintf('%s \r\n \r\n %s \r\n \r\n %s \r\n \r\n %s',output.message,output.algorithm,str,str1)

%objective functions for solver to solver
    function [myfun]=objfcnCal(modelParam)
        
        %modelParam0=[molar w s D tt Tr tt2 Tr2];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        modelParam(fixParam)=modelParam0(fixParam);
        
        %Assign Parameters
        molar=modelParam(1);
        w=modelParam(2);
        s=modelParam(3);
        D=modelParam(4);
        tt=modelParam(5);
        Tr=modelParam(6);
        tt2=modelParam(7);
        Tr2=modelParam(8);
        ginf=modelParam(9);
        
       const=((molar*6.022*(10^-10)*((pi)^1.5)*(w^3)*s)^(-1));
       diff1=(1+x*(10^8)*4*D/(w^2)).^(-1);
       diff2=(1+x*(10^8)*4*D/(w^2)/(s^2)).^(-0.5);
       trip1=1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt);
       trip2=1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2);
        
        myModel=const*diff1.*diff2.*trip1.*trip2 +ginf;
        wx=1./(STD); %weight each by variance, which is STD squared
        myfun=(FCS-myModel).*wx;
        myfun=myfun(xpos1:xpos2);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
    end

 function [myfun]=objfcnSimp(modelParam)
        
        %modelParam0=[molar w s td Tr tt Tr2 tt2 ginf];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        modelParam(fixParam)=modelParam0(fixParam);
        
        %Assign Parameters
        molar=modelParam(1);
        w=modelParam(2);
        s=modelParam(3);
        td=modelParam(4);
        Tr=modelParam(5);
        tt=modelParam(6);
        Tr2=modelParam(7);
        tt2=modelParam(8);
        ginf=modelParam(9);
        
     const=(molar*(10^(-9))*(6.022*10^23)*((pi)^1.5)*(((w*10^(-9))^3)*s*10^3))^(-1);
        diff1=((1+x*(10^6)/td).^(-1));
        diff2=((1+x*(10^6)/td/(s^2)).^(-0.5));
        trip1=(1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt));
        trip2=(1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2));
        myModel=const.*diff1.*diff2.*trip1.*trip2 +ginf; 
        wx=1./(STD); %weight each by variance, which is STD squared 
        myfun=(FCS-myModel).*wx;
        myfun=myfun(xpos1:xpos2);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
 end

function [myfun]=objfcnTwoComp(modelParam)
        
        %modelParam0=[molar w s td Tr tt Tr2 tt2 ginf];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        modelParam(fixParam)=modelParam0(fixParam);
        
        %Assign Parameters
        molar=modelParam(1);
        w=modelParam(2);
        s=modelParam(3);
        f1=modelParam(4);
        td=modelParam(5);
        td2=modelParam(6);
        Tr=modelParam(7);
        tt=modelParam(8);
        Tr2=modelParam(9);
        tt2=modelParam(10);
        ginf=modelParam(11);
        
     const=(molar*(10^(-9))*(6.022*10^23)*((pi)^1.5)*(((w*10^(-9))^3)*s*10^3))^(-1);
        diff1=((1+x*(10^6)/td).^(-1));
        diff2=((1+x*(10^6)/td/(s^2)).^(-0.5));
        diff12=((1+x*(10^6)/td2).^(-1));
        diff22=((1+x*(10^6)/td2/(s^2)).^(-0.5));
        trip1=(1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt));
        trip2=(1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2));
        myModel=const.*(f1*diff1.*diff2 + (1-f1)*diff12.*diff22).*trip1.*trip2 +ginf; 
        wx=1./(STD); %weight each by variance, which is STD squared 
        myfun=(FCS-myModel).*wx;
        myfun=myfun(xpos1:xpos2);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
end

function [myfun]=objfcnThreeTrip(modelParam)
        
        %modelParam0=[molar w s td Tr tt Tr2 tt2 ginf];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        modelParam(fixParam)=modelParam0(fixParam);
        
        %Assign Parameters
        molar=modelParam(1);
        w=modelParam(2);
        s=modelParam(3);
        f1=modelParam(4);
        td=modelParam(5);
        td2=modelParam(6);
        Tr=modelParam(7);
        tt=modelParam(8);
        Tr2=modelParam(9);
        tt2=modelParam(10);
        Tr3=modelParam(11);
        tt3=modelParam(12);
        ginf=modelParam(13);
        
     const=(molar*(10^(-9))*(6.022*10^23)*((pi)^1.5)*(((w*10^(-9))^3)*s*10^3))^(-1);
        diff1=((1+x*(10^6)/td).^(-1));
        diff2=((1+x*(10^6)/td/(s^2)).^(-0.5));
        diff12=((1+x*(10^6)/td2).^(-1));
        diff22=((1+x*(10^6)/td2/(s^2)).^(-0.5));
        trip1=(1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt));
        trip2=(1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2));
        trip3=(1+(Tr3/(1-Tr3)).*exp(-x*(10^6)/tt3));
        myModel=const.*(f1*diff1.*diff2 + (1-f1)*diff12.*diff22).*trip1.*trip2.*trip3 +ginf; 
        wx=1./(STD); %weight each by variance, which is STD squared 
        myfun=(FCS-myModel).*wx;
        myfun=myfun(xpos1:xpos2);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
    end

function [myfun]=objfcnOneDifThreeTrip(modelParam)
        
        %modelParam0=[molar w s td Tr tt Tr2 tt2 ginf];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]
        modelParam(fixParam)=modelParam0(fixParam);
        
        %Assign Parameters
        molar=modelParam(1);
        w=modelParam(2);
        s=modelParam(3);
        td=modelParam(4);
        Tr=modelParam(5);
        tt=modelParam(6);
        Tr2=modelParam(7);
        tt2=modelParam(8);
        Tr3=modelParam(9);
        tt3=modelParam(10);
        ginf=modelParam(11);
        
    const=(molar*(10^(-9))*(6.022*10^23)*((pi)^1.5)*(((w*10^(-9))^3)*s*10^3))^(-1);
        diff1=((1+x*(10^6)/td).^(-1));
        diff2=((1+x*(10^6)/td/(s^2)).^(-0.5));
        trip1=(1+(Tr/(1-Tr)).*exp(-x*(10^6)/tt));
        trip2=(1+(Tr2/(1-Tr2)).*exp(-x*(10^6)/tt2));
        trip3=(1+(Tr3/(1-Tr3)).*exp(-x*(10^6)/tt3));
        myModel=const.*diff1.*diff2.*trip1.*trip2.*trip3 +ginf;
        wx=1./(STD); %weight each by variance, which is STD squared 
        myfun=(FCS-myModel).*wx;
        myfun=myfun(xpos1:xpos2);
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
    end
end

