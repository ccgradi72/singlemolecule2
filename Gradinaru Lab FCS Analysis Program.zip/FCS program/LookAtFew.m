clear all
close all
clc;

format = repmat('%f', [1 5]); %format for textscan for how many columns, user can change in ui.
hl=0; %header lines in textfiles
%  prompt={'Enter the column number with correlation curve to analyze:',...
%             'Enter corresponding standard deviation:'};
%         name='Correlation Curve Selection';
%         numlines=1;
%         defaultanswer={'2','3'}; %I found this gives best results
%         answer=inputdlg(prompt,name,numlines,defaultanswer);
        FCS_col = 3;
%         STD_col = str2num(answer{2});
        
        
%Plotting
lwthick=2;
lwthin=1;
nhistbin=50; %for residual plot
nr=-1; %round residuals plot ticks to power of 10^n


[FileName,PathName] = uigetfile('*.txt','Select the data file','C:\Users\Owner\Dropbox');
%To replace with a permament location of text file:
%Example: PathName='E:\May 22 Data\';
%Example:FileName='IRF.txt';

disp('Now analyzing:')
disp(FileName)

% Read the file into matrix
fid = fopen(strcat(PathName,FileName));
DATA=textscan(fid,format,'headerlines',hl);
%close(fid)
t=DATA{1}; %A
t=t';


    FCS3=DATA{FCS_col};
%     STD3=DATA{STD_col};
    FCS3=FCS3'-1;
    FCS3=FCS3/mean(FCS3(t>1E-6 & t<10E-6));
    FCS3=FCS3-0.0066;
    FCS3=FCS3/mean(FCS3(t>1E-6 & t<10E-6));

%     FCS3=FCS3-mean(FCS3(t>10E-2));
%     FCS3=FCS3-mean(FCS3(end-10:end));
%     FCS3=FCS3/mean(FCS3(1:10));
    
        FCSPrt=FCS3;
    tPrt=t;
    
    [FileName,PathName] = uigetfile('*.txt','Select the data file','C:\Users\Owner\Dropbox');
%To replace with a permament location of text file:
%Example: PathName='E:\May 22 Data\';
%Example:FileName='IRF.txt';

disp('Now analyzing:')
disp(FileName)

% Read the file into matrix
fid = fopen(strcat(PathName,FileName));
DATA=textscan(fid,format,'headerlines',hl);
%close(fid)
t=DATA{1}; %A
t=t';


    FCS3=DATA{FCS_col};
%     STD3=DATA{STD_col};
    FCS3=FCS3'-1;
    FCS3=FCS3/mean(FCS3(t>1E-6 & t<10E-6));
    FCS3=FCS3-0.0197
     FCS3=FCS3/mean(FCS3(t>1E-6 & t<10E-6));

%     FCS3=FCS3-mean(FCS3(t>10E-2));
%     FCS3=FCS3/mean(FCS3(t>1E-6 & t<10E-6));
    
    FCSDye=FCS3;
    tDye=t;
 
hold all
semilogx(tPrt,FCSPrt,'LineWidth',lwthick)
semilogx(tDye,FCSDye,'LineWidth',lwthick)
set(gca,'XScale','log')
        legend('Alexa647','WD40+Atto647N','Location','Best')
        ylim([0 1.25])
        xlim([1E-6 0.1])
        hAx1=gca;
        hXLabel1 = xlabel(hAx1,'\bf $\tau$ [s]','Interpreter','latex');
        hYLabel1 = ylabel(hAx1,'\bf G($\tau$)','Interpreter','latex');
        set( gca                       , ...
            'FontName'   , 'Helvetica' );