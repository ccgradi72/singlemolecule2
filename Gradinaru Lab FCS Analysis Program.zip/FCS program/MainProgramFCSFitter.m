function [ output_args ] = MainProgramFCSFitter( ~ )
%MainProgramFCSFitter Performs FCS fitting with possible calibration
%   

clc;
clear all;
close all;

DoCal=1; %Change this to 0 if you don't want to do a calibration
w=299; %If you don't do a calibration it will use this w and this s
s=14;

if DoCal==1
    CalibrateFCS %Works as of July 3 2014
else
    
    %% TEMPOARAY!!!!!!!!!!%%%
    w=repmat(w,[1 2]);
    s=repmat(s,[1 2]);
    %%%%%%%%%%%%%%%%%%%%%
    % FCSFitterThreeCurve(w,s) %works as of July 3 2014
    FCSFitterOneCurve(w,s) %works as of July 3 2014
end


end

