function [ output_args ] = TimeSeries_Tester( input_args )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

clc;
close all;
clear all;
format = repmat('%f', [1 3]); %format for textscan for how many columns, user can change in ui.
hl=0; %header lines in textfiles

%Plotting
lwthick=1.75;
papersizex=7;
papersizey=4.72; 
marginx=0.5;
marginy=0.5;
fontsizeax=12;
fontsizeleg=8;
ticksize=12;


%% Find Data
[FileName,PathName] = uigetfile('*.txt','Select the data file', 'C:\Users\LabUser\Desktop\Oct 15 2014 FCS building','MultiSelect','On');
%To replace with a permament location of text file:
%Example: PathName='E:\May 22 Data\';
%Example:FileName='IRF.txt';
set(0,'DefaultAxesLineStyleOrder',{'-','-.','--'})
hold all

for i=1:length(FileName)
disp('Now analyzing:')
disp(FileName{i})
disp(PathName)

% Read the file into matrix
fid = fopen(strcat(PathName,FileName{i}));
DATA=textscan(fid,format,'headerlines',hl);
%close(fid)
t=DATA{1}; %A
t=t';

  FCS3=DATA{2};
  STD3=DATA{3};
  
  
 
  FCS3=FCS3';
  STD3=STD3';
  
  FCS3=FCS3./mean(FCS3(1:40));
  semilogx(t,FCS3,'LineWidth',1.5)
  
  set(gca,'XScale','Log')
end

legendentry=1:length(FileName);
legendentry=5*legendentry;
legendentry=strread(num2str(legendentry),'%s')
hleg=legend(gca,legendentry)
% hleg=legend(gca,FileName{:})
set(gca,'Ylim',[0 1.1],'Xlim',[1E-6 0.1])

set(hleg,'FontSize',fontsizeleg)
 hAx1=gca;
        hXLabel1 = xlabel(hAx1,'$\tau$ [ns]','Interpreter','latex');
        hYLabel1 = ylabel(hAx1,'G($\tau$)','Interpreter','latex');
        set( gca                       , ...
            'FontName'   , 'Helvetica' );

       %Adjust ticks
% set(gca,'LineWidth', linewidth);
set(gca,'FontSize', ticksize);
% set(gca,'FontWeight','Bold');
set(gca,'TickDir','in', ...
    'TickLength'  , [.02 .02] , ...
                'XMinorTick'  , 'on'      , ...
                'YMinorTick'  , 'on'      , ...
                'YGrid'       , 'off'      , ...
                'XColor'      , [.1 .1 .1], ...
                'YColor'      , [.1 .1 .1], ...
                'LineWidth', 1) ;
% set(gca, 'YTick',[0 0.1 0.2 0.3 0.4])  
% set(gca,'XTickLabel','0';'0.1';'0.2';'0.3';'0.4'})
% set(gca,'YTickLabel',{'0';'0.1';'0.2';'0.3';'0.4'})
set(gca,'PlotBoxAspectRatio',[2 1 1])

set(gca, 'Box' , 'on' )

        
        %paper position and background color
set(gcf,'PaperUnits','inches');
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
    papersizey-2*(marginy)]);
set(gcf, 'PaperPositionMode','manual');
set(gcf, 'color', 'w');
% set(gcf,'color','none')

%Axes label fonts
set(get(gca,'xlabel'),'FontSize',fontsizeax...
    ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
set(get(gca,'ylabel'),'FontSize',fontsizeax...
    ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
        
        
        
        print('-dpng','-r600','TimeSeriesFCS')


end

