    function [Rh]=rotCorCalc(D,T)
        D=D*1E-6; %D is now in cm^2/s
        D=D/(100*100); %D is now in m^2/s
        k=1.3807E-23;%Boltzman constant J/K
        %eta=1; %the viscosity in cP;
        T=T+273.15; %T in Kelvin
        A=2.414E-5; %Pa*S
        B=247.8;
        C=140;
        eta=A*10^(B/(T-C)); %Pa*s
        eta=1.05;
        eta=eta*10^(-3); %convert to Pa*s
%       T=25; %temperature in celsius
        
        
        Rh=k*T/(6*pi*eta*D);
        %J/(Pa*s*m^2/s)=J/(Pa*m^2)={N*m}/({N/m^2}*m^2)=N*m/N=m
        
        Rh=Rh/(1E-10); %from m to angstrom