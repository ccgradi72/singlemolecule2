function [] = AICChooser(AIC)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
clc;


%The AIC values
AIC=[19.9026 15.6139];

%The relative AIC values, relative to the best model
delAIC=AIC-min(AIC);

%The weights normalized to 1.
wAIC=exp(-0.5*delAIC)/sum(exp(-0.5*delAIC));

%How much more preferable the best model is to the other models.
pPref=max(wAIC)./wAIC;

P=[(1:length(AIC))' AIC'  delAIC' wAIC'];
[~,m]=min(AIC);

fprintf('--------------------------------\r\n')
fprintf('--------Results-----------------\r\n')
fprintf('The preferred model is model %d \r\n',m)

for i=1:length(AIC)
    
    fprintf('It is %f times more likely than model %d \r\n',pPref(i),i)

end



fprintf('Model \t AIC \t delAIC \t wAIC\r\n')
fprintf('%f  \t %f \t %f \t %f \r\n',P')

fprintf('--------------------------------\r\n')
fprintf('------------------------------\r\n')

end

