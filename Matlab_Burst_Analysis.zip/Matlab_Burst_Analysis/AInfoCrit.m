function [AIC]=AInfoCrit(redchi,N,k)
        AIC=(N-k)*redchi+2*k;
        %Prefer lower AIC
    end