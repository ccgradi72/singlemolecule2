function [AIC]=AInfoCrit_c(redchi,N,k)
        AIC=(N-k)*(redchi)+2*k*(k+1)*(1/(N-k-1))+2*k;
        %Prefer lower AIC
    end