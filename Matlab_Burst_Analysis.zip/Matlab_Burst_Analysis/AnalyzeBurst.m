function [ output_args ] = AnalyzeBurst(ind,sstime,timetag,indBKG,sstimeBKG,timetagBKG,Tpp,dt,TimeSinceLastBurst)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
%ind,sstime,timetag are all within burst identified by MLT algorithm


%Possible future features:
%MLE estimate bkg (See Antonino Ingargiola's FretBursts Python Project)
%Probability over bkg (probability of false positive)
%FCS within bust

%If background estimate for a particular channel is formed from <10 photons
%won't it be very large error? For example with only two values the
%difference in arrival times might be very small causing B to be very
%large. Maybe have a running average B= (B +currB)/2


%% Global Variables for Picoharp and Router
global ind_Dpar ind_Dperp ind_Apar ind_Aperp ind_Dexc ind_Aexc

%% Global Variables for Lifetime
global Irf_DPar Irf_DPerp c_Dpar c_Dperp subEns1_Dpar subEns1_Dperp subEns2_Dpar subEns2_Dperp

%% Global Variables for Workflow
global ALEX pol lifetime FRET AllRecords fid_burst_txt subEnsemble1_condition subEnsemble2_condition T3mode

%% Global Variables related to bkg estimation

global Mbkg Tbkg_dd_par Tbkg_dd_perp Tbkg_ad_par Tbkg_ad_perp Tbkg_aa_par Tbkg_aa_perp Bdd_par_prev Bdd_perp_prev Bad_par_prev Bad_perp_prev Baa_par_prev Baa_perp_prev

%% Unused Global Variables that I didn't end up using but am too afraid to forget about completley

% global Tbkg_da_par Tbkg_da_perp draw_microtimeB t0 Irf_APar Irf_APerp Gdd k1 k2 Gaa

%% Burst duration and start time

%Note: I have some concerns about whether last photon is timetag(end)
%or timetag(end-1). See MLT algorithm.

burst_start=timetag(1);
burst_end=timetag(end); %last photon in burst
burst_duration=burst_end-burst_start; %in same units as timetag (seconds)


%% Count Photons by Classifiaction

if ALEX
    sprintf('Sorting Burst Photons by ALEX . . .')
    [indDexc,sstimeDexc,timetagDexc,indAexc,~,timetagAexc] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]);
    sprintf('Sorting Burst Photons by ALEX - [Done]')
    
    sprintf('Sorting Bkg Photons by ALEX . . .')
    [indDexcBKG,~,timetagDexcBKG,indAexcBKG,~,timetagAexcBKG] = SortPhotonByALEXReal(indBKG,sstimeBKG,timetagBKG,[ind_Dexc ind_Aexc]);
    sprintf('Sorting Bkg Photons by ALEX - [Done]')
    
    %How many photons in each channel after Donor excitation
    Sdd_par=length(indDexc(indDexc==ind_Dpar));
    Sdd_perp=length(indDexc(indDexc==ind_Dperp));
    Sad_par=length(indDexc(indDexc==ind_Apar));
    Sad_perp=length(indDexc(indDexc==ind_Aperp));
    
    %How many photons in each channel after Acceptor excitation
%     Sda_par=length(indAexc(indAexc==ind_Dpar));
%     Sda_perp=length(indAexc(indAexc==ind_Dperp));
    Saa_par=length(indAexc(indAexc==ind_Apar));
    Saa_perp=length(indAexc(indAexc==ind_Aperp));
    
    %Correct for background
    
    %The first way uses the fact that the waiting time between photons is
    %exponentially distributed (Poisson). The rate B=1/dt_bkg where dt_bkg
    %is the mean waiting time between photons, since the first moment is an
    %estimate of the rate parameter of the exponential.
    
    %Another way would be to create a histogram of dt_bkg and fit using MLE
    %A third way would be to take Nph/(timetagBKG(end)-timetagbkg(1)); where N
    %is the Nph in the bkg sample window.
    
    Bdd_par=GetBkg(timetagDexcBKG(indDexcBKG==ind_Dpar),Tbkg_dd_par);
    Bdd_perp=GetBkg(timetagDexcBKG(indDexcBKG==ind_Dperp),Tbkg_dd_perp);
    Bad_par=GetBkg(timetagDexcBKG(indDexcBKG==ind_Apar),Tbkg_ad_par);
    Bad_perp=GetBkg(timetagDexcBKG(indDexcBKG==ind_Aperp),Tbkg_ad_perp);
    
%     Bda_par=GetBkg(timetagAexcBKG(indAexcBKG==ind_Dpar),Tbkg_da_par);
%     Bda_perp=GetBkg(timetagAexcBKG(indAexcBKG==ind_Dperp),Tbkg_da_perp);
    Baa_par=GetBkg(timetagAexcBKG(indAexcBKG==ind_Apar),Tbkg_aa_par);
    Baa_perp=GetBkg(timetagAexcBKG(indAexcBKG==ind_Aperp),Tbkg_aa_perp);
   
    
    if isnan(Bdd_par)||isinf(Bdd_par)
        Bdd_par=Bdd_par_prev;
    end
    if isnan(Bdd_perp)||isinf(Bdd_perp)
        Bdd_perp=Bdd_perp_prev;
    end
    if isnan(Bad_par)||isinf(Bad_par)
        Bad_par=Bad_par_prev;
    end
    if isnan(Bad_perp)||isinf(Bad_perp)
        Bad_perp=Bad_perp_prev;
    end
     if isnan(Baa_par)||isinf(Baa_par)
        Baa_par=Baa_par_prev;
    end
    if isnan(Baa_perp)||isinf(Baa_perp)
        Baa_perp=Baa_perp_prev;
    end
    
      Bdd_par_prev=Bdd_par;
    Bdd_perp_prev=Bdd_perp;
    Bad_par_prev=Bad_par;
    Bad_perp_prev=Bad_perp;
     Baa_par_prev=Baa_par;
    Baa_perp_prev=Baa_perp;
    
    %Mean arrival times within burst: See Kudryavtsev/Lamb/Seidel 2012
    %ChemPhysChem 2012, vol 13, 1060-1078 for an interesting discussion on
    %the merits of abs(T_{GG+GR} - T_{RR}) < Threshold in order to filter
    %out photobleaching without filtering dynamics!1072-1074 Figure 8
    %especially
    
    %Mean photon arrival time after donor excitation (all photons)
    Txd=mean(timetagDexc(indDexc~=15));
    %Mean photon arrival time after acceptor excitation (all photons)
    Txa=mean(timetagAexc(indAexc~=15));
    %Mean photon arrival time in donor channel after donor excitation
    Tdd=mean(timetagDexc(indDexc==ind_Dpar | indDexc==ind_Dperp));
    %Mean photon arrival time in acceptor channel after donor excitation
    Tad=mean(timetagDexc(indDexc==ind_Apar | indDexc==ind_Aperp));
    
    if lifetime
        %User wants time-resolved data within ALEX
        
        Irf_D=Itotal(Irf_DPar,Irf_DPerp,'D'); %if data was acquired without polarizers this should still be fine - Irf_DPerp will be zeros(1,256) - size may disagree due to clipping after Tpp
        
        edges_ss=0:16:4095; %rebinned
        dtb=16*dt; %the dt for binned data
        I_Dpar=histc(sstimeDexc(indDexc==ind_Dpar),edges_ss);
        I_Dperp=histc(sstimeDexc(indDexc==ind_Dperp),edges_ss);
        
        %offset and Itotal
        n = length(I_Dpar);
        tv = 1:n;
        tv=tv';
        [I_Dpar]=offsetter(I_Dpar,c_Dpar,tv,n);
        [I_Dperp]=offsetter(I_Dperp,c_Dperp,tv,n);       
        I_D=Itotal(I_Dpar,I_Dperp,'D');
 
        [tauD,~]=getTauMLE_lin_fast(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9); %Tpp was converted to ns, all inputs should be ns.
        
    else
        tauD=0;
%         errD=0;
    end
    
    if pol
        
        %calculate steady state anisotropy here
        [rD] = Aniso(Sdd_par-Bdd_par*burst_duration,Sdd_perp - Bdd_perp*burst_duration,'D',[]);
         %calculate steady state anisotropy here
        [rA] = Aniso(Saa_par-Baa_par*burst_duration,Saa_perp - Baa_perp*burst_duration,'A',[]);      
    else        
        rD=0;
        rA=0;
    end
    
    if FRET
       [Eraw] = ProximityRatio((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration));
       [Sraw] =UncorrStoich((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration),(Saa_par-Baa_par*burst_duration)+(Saa_perp-Baa_perp*burst_duration));
       %Using ALEX with global corection factors - meaningless if gamma,lk,dir are not already known:
        [E] = correct_E_gamma_leak_dir((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration),(Saa_par-Baa_par*burst_duration)+(Saa_perp-Baa_perp*burst_duration),[],[],[],'ALEX');  
        [S] = correct_Stoich_gamma_leak_dir((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration),(Saa_par-Baa_par*burst_duration)+(Saa_perp-Baa_perp*burst_duration),[],[],[],'ALEX'); 
    else
        Eraw=0;
        Sraw=0;
        E=0;
        S=0;
    end
    
else   %ie, non-ALEX
     
   %How many photons in each channel after Donor excitation
    Sdd_par=length(ind(ind==ind_Dpar));
    Sdd_perp=length(ind(ind==ind_Dperp));
    Sad_par=length(ind(ind==ind_Apar));
    Sad_perp=length(ind(ind==ind_Aperp));
    
    %How many photons in each channel after Acceptor excitation - ZERO for
    %non ALEX
%     Sda_par=0;
%     Sda_perp=0;
    Saa_par=0;
    Saa_perp=0;
    
    %Correct for background
    
    %The first way uses the fact that the waiting time between photons is
    %exponentially distributed (Poisson). The rate B=1/dt_bkg where dt_bkg
    %is the mean waiting time between photons, since the first moment is an
    %estimate of the rate parameter of the exponential.
    
    %Another way would be to create a histogram of dt_bkg and fit using MLE
    %A third way would be to take Nph/(timetagBKG(end)-timetagbkg(1)); where N
    %is the Nph in the bkg sample window.
    
    Bdd_par=GetBkg(timetagBKG(indBKG==ind_Dpar),Tbkg_dd_par);
    Bdd_perp=GetBkg(timetagBKG(indBKG==ind_Dperp),Tbkg_dd_perp);
    Bad_par=GetBkg(timetagBKG(indBKG==ind_Apar),Tbkg_ad_par);
    Bad_perp=GetBkg(timetagBKG(indBKG==ind_Aperp),Tbkg_ad_perp);
    
    if isnan(Bdd_par)||isinf(Bdd_par)
        Bdd_par=Bdd_par_prev;
    end
    if isnan(Bdd_perp)||isinf(Bdd_perp)
        Bdd_perp=Bdd_perp_prev;
    end
    if isnan(Bad_par)||isinf(Bad_par)
        Bad_par=Bad_par_prev;
    end
    if isnan(Bad_perp)||isinf(Bad_perp)
        Bad_perp=Bad_perp_prev;
    end
    
     Bdd_par_prev=Bdd_par;
    Bdd_perp_prev=Bdd_perp;
    Bad_par_prev=Bad_par;
    Bad_perp_prev=Bad_perp;
%     Bda_par=0;
%     Bda_perp=0;
    Baa_par=0;
    Baa_perp=0;
   
    %Mean arrival times within burst: See Kudryavtsev/Lamb/Seidel 2012
    %ChemPhysChem 2012, vol 13, 1060-1078 for an interesting discussion on
    %the merits of abs(T_{GG+GR} - T_{RR}) < Threshold in order to filter
    %out photobleaching without filtering dynamics!1072-1074 Figure 8
    %especially
    
    %Mean photon arrival time after donor excitation (all photons) NOT
    %DEFINED FOR NON-ALEX
    Txd=0;
    %Mean photon arrival time after acceptor excitation (all photons) NOT
    %DEFINED FOR NON-ALEX
    Txa=0;
    %Mean photon arrival time in donor channel after donor excitation
    Tdd=mean(timetag(ind==ind_Dpar | ind==ind_Dperp));
    %Mean photon arrival time in acceptor channel after donor excitation
    Tad=mean(timetag(ind==ind_Apar | ind==ind_Aperp));
    
    
    if lifetime
        %copy lifetime but for non-ALEX
        %User wants time-resolved data within ALEX
        
        Irf_D=Itotal(Irf_DPar,Irf_DPerp,'D'); %if data was acquired without polarizers this should still be fine - Irf_DPerp will be zeros(1,256) - size may disagree due to clipping after Tpp
        
        edges_ss=0:16:4095; %rebinned
        dtb=16*dt; %the dt for binned data
        I_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
        I_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
        
        %offset and Itotal
        n = length(I_Dpar);
        tv = 1:n;
        tv=tv';
        [I_Dpar]=offsetter(I_Dpar,c_Dpar,tv,n);
        [I_Dperp]=offsetter(I_Dperp,c_Dperp,tv,n);       
        I_D=Itotal(I_Dpar,I_Dperp,'D');
 
        dtb
        Tpp
        Tpp/dtb
        [tauD, ~]=getTauMLE_lin_fast(Irf_D,I_D,dtb,Tpp,0,Tpp); %Tpp was converted to ns, all inputs should be ns.
    else
        tauD=0;
%         errD=0;
    end
    
    if pol
        %calculate anisotropy
        %calculate steady state anisotropy here
        [rD] = Aniso(Sdd_par-Bdd_par*burst_duration,Sdd_perp - Bdd_perp*burst_duration,'D',[]);
         %calculate steady state anisotropy here
        rA = 0 ;
    else
        rD=0;
        rA=0;
    end
    
    if FRET
       [Eraw] = ProximityRatio((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration));
       [Sraw] =0;
       %Not using ALEX with global corection factors - meaningless if gamma,lk,dir are not already known (dir is from absorption crossections):
        [E] = correct_E_gamma_leak_dir((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration),[],[],[],[],'ABS');  
        [S] = 0; 
    else
        Eraw=0;
        Sraw=0;
        E=0;
        S=0;
    end
    
end

%% Save all burst data to textfile for post-processing



currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ...
    Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...
    Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...
    Txd Txa Tdd Tad ...
    tauD rD rA...
    Eraw Sraw E S];

fprintf(fid_burst_txt,[repmat('%f \t',size(currRecord)) '\r\n'],currRecord);

AllRecords=[AllRecords;currRecord];


%Option to save photons from this burst if it passes some test
%For example: If lb<E<ub save index,sstime,timetag as T3 record with a
%custom special marker denoting seperate bursts.

if eval(subEnsemble1_condition) && T3mode
    %A logical expression using the values in currRecord as a condition for
    %saving a subensemble. Can be constructed from AND, OR, XOR etc.
    %Eg. 0.3<Eraw && Eraw < 0.7 && (Saa_perp+Saa_par)>10 && abs(Txd-Txa)<0.7
    
    edges_ss=0:1:4095; %rebinned
    if ~ALEX
        subEns1_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
        subEns1_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
    else
        subEns1_Dpar=histc(sstimeDexc(indDexc==ind_Dpar),edges_ss);
        subEns1_Dperp=histc(sstimeDexc(indDexc==ind_Dperp),edges_ss);
    end
    
    %offset and Itotal
    n = length(subEns1_Dpar);
    tv = 1:n;
    tv=tv';
    [subEns1_Dpar]=offsetter(subEns1_Dpar,c_Dpar,tv,n);
    [subEns1_Dperp]=offsetter(subEns1_Dperp,c_Dperp,tv,n);
    
end

if eval(subEnsemble2_condition) && T3mode
    %A logical expression using the values in currRecord as a condition for
    %saving a subensemble. Can be constructed from AND, OR, XOR etc.
    %Eg. 0.3<Eraw && Eraw < 0.7 && (Saa_perp+Saa_par)>10 && abs(Txd-Txa)<0.7
    
    edges_ss=0:1:4095; %rebinned
    if ~ALEX
        subEns2_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
        subEns2_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
    else
        subEns2_Dpar=histc(sstimeDexc(indDexc==ind_Dpar),edges_ss);
        subEns2_Dperp=histc(sstimeDexc(indDexc==ind_Dperp),edges_ss);
    end
    
    %offset and Itotal
    n = length(subEns2_Dpar);
    tv = 1:n;
    tv=tv';
    [subEns2_Dpar]=offsetter(subEns2_Dpar,c_Dpar,tv,n);
    [subEns2_Dperp]=offsetter(subEns2_Dperp,c_Dperp,tv,n);
    
end

%Or option to create a cumulative sstime histogram for a population.

    function B=GetBkg(t,Tbkg)
        
        temp=diff(t);
        dtime=mean(temp>Tbkg);
        B=1/dtime;       
    end

function B=GetBkgOld(t,Tbkg)
        
        below_max_rate = BackgroundMask(t,Tbkg);
        dtime=mean(diff(t(below_max_rate)));
        B=1/dtime;
        
        function below_max_rate = BackgroundMask(t,Tbkg)
            
            %Searches with sliding window size Mbkg
            %for photons in regions where the local count rate is <
            %Mbkg/Tbkg, ie interphohton spacing should be > Tbkg
            
            below_max_rate = (t(Mbkg:end) - t(1:length(t)-Mbkg+1)) >= Tbkg;
            
        end
    end

    

end

