function [ ] = AnalyzeBurst_v2(ind,sstime,timetag,BKG,Tpp,dt,TimeSinceLastBurst)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
%ind,sstime,timetag are all within burst identified by MLT algorithm

% V2: Background calculation is performed on "numRecords" level ~7 seconds
% of data - this is more accurate since it has more photons from which to
% calculate background in each channel: especially for channels with low
% bkg.

%July 12 2017 Greg added 2D MLE for lifetime + scattering. Fixes problem of
%lifetimes being too short.

%March 2019: Did a lot of changes to make faster!!


%Possible future features:
%MLE estimate bkg (See Antonino Ingargiola's FretBursts Python Project)
%Probability over bkg (probability of false positive)
%FCS within bust

%% Global Variables for Picoharp and Router
global ind_Dpar ind_Dperp ind_Apar ind_Aperp ind_Dexc ind_Aexc

%% Global Variables for Lifetime
global Irf_DPar Irf_DPerp c_Dpar c_Dperp subEns1_Dpar subEns1_Dperp subEns2_Dpar subEns2_Dperp subEns1_Apar subEns1_Aperp subEns2_Apar subEns2_Aperp subEns3_Apar subEns3_Aperp subEns3_Dpar subEns3_Dperp
global Irf_APar Irf_APerp c_Apar c_Aperp subEns4_Apar subEns4_Aperp subEns4_Dpar subEns4_Dperp

%% Global Variables for Workflow
global ALEX pol lifetime FRET  fid_burst_txt subEnsemble1_condition subEnsemble2_condition T3mode BVA subEnsemble3_condition subEnsemble4_condition
global AllRecords Nth nBVA runLength BVARecord anisoBVA anisoBVARecord
global repExc MLE1d
%% Unused Global Variables that I didn't end up using but am too afraid to forget about completley

% global Tbkg_da_par Tbkg_da_perp draw_microtimeB t0 Irf_APar Irf_APerp Gdd k1 k2 Gaa



%%
% if IgnoreBKG
%     %sometimes I don't want to deal with finding the right setttings for
%     %automatic bkg subrtraction.
%    BKG=zeros(size(BKG)); 
% end

%% Burst duration and start time

%Note: I have some concerns about whether last photon is timetag(end)
%or timetag(end-1). See MLT algorithm.

burst_start=timetag(1);
burst_end=timetag(end); %last photon in burst
burst_duration=burst_end-burst_start; %in same units as timetag (seconds)

if length(ind(ind<=5))> Nth
    %bursts with more than Nth photons are likely aggregates, or multiple
    %molecules, or just plain difficult to do computations with as
    %computations on bursts usually scale with ~Nphotons^3
    return
end

%% Count Photons by Classifiaction

if ALEX
%     fprintf('Sorting Burst Photons by ALEX . . .')
    [indDexc,sstimeDexc,timetagDexc,indAexc,~,timetagAexc,~,~] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]);
%     fprintf('Sorting Burst Photons by ALEX - [Done]')
    
    %How many photons in each channel after Donor excitation
    Sdd_par=length(indDexc(indDexc==ind_Dpar));
    Sdd_perp=length(indDexc(indDexc==ind_Dperp));
    Sad_par=length(indDexc(indDexc==ind_Apar));
    Sad_perp=length(indDexc(indDexc==ind_Aperp));
    
    %How many photons in each channel after Acceptor excitation
        Sda_par=length(indAexc(indAexc==ind_Dpar));
        Sda_perp=length(indAexc(indAexc==ind_Dperp));
    Saa_par=length(indAexc(indAexc==ind_Apar));
    Saa_perp=length(indAexc(indAexc==ind_Aperp));
    
    %Correct for background
    
    Bdd_par=BKG(1);
    Bdd_perp=BKG(2);
    Bad_par=BKG(3);
    Bad_perp=BKG(4);
    Baa_par=BKG(5);
    Baa_perp=BKG(6);
    
    %Mean arrival times within burst: See Kudryavtsev/Lamb/Seidel 2012
    %ChemPhysChem 2012, vol 13, 1060-1078 for an interesting discussion on
    %the merits of abs(T_{GG+GR} - T_{RR}) < Threshold in order to filter
    %out photobleaching without filtering dynamics!1072-1074 Figure 8
    %especially
    
    %Mean photon arrival time after donor excitation (all photons)
    Txd=mean(timetagDexc(indDexc~=15));
    %Mean photon arrival time after acceptor excitation (all photons)
    Txa=mean(timetagAexc(indAexc~=15));
    %Mean photon arrival time in donor channel after donor excitation
    Tdd=mean(timetagDexc(indDexc==ind_Dpar | indDexc==ind_Dperp));
    %Mean photon arrival time in acceptor channel after donor excitation
    Tad=mean(timetagDexc(indDexc==ind_Apar | indDexc==ind_Aperp));
    
    if lifetime
        %User wants time-resolved data within ALEX
        
        Irf_D=Itotal(Irf_DPar,Irf_DPerp,'D'); %if data was acquired without polarizers this should still be fine - Irf_DPerp will be zeros(1,256) - size may disagree due to clipping after Tpp
        Irf_A=Itotal(Irf_APar,Irf_APerp,'A'); %if data was acquired without polarizers this should still be fine - Irf_DPerp will be zeros(1,256) - size may disagree due to clipping after Tpp
        
        edges_ss=0:16:4095; %rebinned
        dtb=16*dt; %the dt for binned data
        I_Dpar=histc(sstimeDexc(indDexc==ind_Dpar),edges_ss);
        I_Dperp=histc(sstimeDexc(indDexc==ind_Dperp),edges_ss);
        I_Apar=histc(sstimeDexc(indDexc==ind_Apar),edges_ss);
        I_Aperp=histc(sstimeDexc(indDexc==ind_Aperp),edges_ss);
        
        if isempty(I_Dpar)||isempty(I_Dperp)
            tauD=0;
        else
        %offset and Itotal
        n = length(I_Dpar);
        tv = 1:n;
        tv=tv';
               
        [I_Dpar]=offsetter(I_Dpar,c_Dpar,tv,n);
        [I_Dperp]=offsetter(I_Dperp,c_Dperp,tv,n);
        [I_Apar]=offsetter(I_Apar,c_Apar,tv,n);
        [I_Aperp]=offsetter(I_Aperp,c_Aperp,tv,n);
        
        I_D=Itotal(I_Dpar,I_Dperp,'D');
        I_A=Itotal(I_Apar,I_Aperp,'A');
        
        tbins=edges_ss*dtb*1E9;
        mTauA=(sum(tbins.*I_A)/sum(I_A))-(sum(tbins(1:length(Irf_A)).*Irf_A)/sum(Irf_A)); %average delay time of acc photons
        mTauD=(sum(tbins.*I_D)/sum(I_D))-(sum(tbins(1:length(Irf_D)).*Irf_D)/sum(Irf_D)); %avg delay for donor
        %these are too high by 16.divide by 16 because it seems edges is
        %already binned 16's and then you have additional 16 from dtb???
          
        
        if MLE1d
            [tauD,~]=getTauMLE_lin_fast(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9); %Tpp was converted to ns, all inputs should be ns.
        else
            if repExc
                [tauD,~,~]=getTauMLE_lin_fast_2d_repExc(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9);
            else
                [tauD,~,~]=getTauMLE_lin_fast_2d(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9);
            end
        end
        
        end
    else
        tauD=0;
        %         errD=0;
    end
    
    if pol
        
        %calculate steady state anisotropy here
        [rD] = Aniso(Sdd_par-Bdd_par*burst_duration,Sdd_perp - Bdd_perp*burst_duration,'D',[]);
        [rDBkg] = Aniso(Sdd_par,Sdd_perp,'D',[]);
        %calculate steady state anisotropy here
        [rA] = Aniso(Saa_par-Baa_par*burst_duration,Saa_perp - Baa_perp*burst_duration,'A',[]);
    else
        rD=0;
        rA=0;
    end
    
    if FRET
        [Eraw] = ProximityRatio((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration));
        [Ebkg] = ProximityRatio((Sdd_par)+(Sdd_perp),(Sad_par)+(Sad_perp));
        [Sraw] =UncorrStoich((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration),(Saa_par-Baa_par*burst_duration)+(Saa_perp-Baa_perp*burst_duration));
% %         [Sbkg] =UncorrStoich((Sdd_par)+(Sdd_perp),(Sad_par)+(Sad_perp),(Saa_par)+(Saa_perp));
        %Using ALEX with global corection factors - meaningless if gamma,lk,dir are not already known:
        [E] = correct_E_gamma_leak_dir((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration),(Saa_par-Baa_par*burst_duration)+(Saa_perp-Baa_perp*burst_duration),[],[],[],'ALEX');
        [S] = correct_Stoich_gamma_leak_dir((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration),(Saa_par-Baa_par*burst_duration)+(Saa_perp-Baa_perp*burst_duration),[],[],[],'ALEX');
        
        if BVA
            
            %         numWindows=floor(length(indDexc/nBVA));
            startPh=1;
            endPh=startPh+nBVA-1; 
            runE=[];
            while endPh<length(indDexc)
                %Read as many nonoverlapping windows of length nBVA photons
                %as possible.
                window_indDexc=indDexc(startPh:endPh);
                startPh=endPh+1;
                endPh=startPh+nBVA-1;
                
                Sdd_par_BVA=length(window_indDexc(window_indDexc==ind_Dpar));
                Sdd_perp_BVA=length(window_indDexc(window_indDexc==ind_Dperp));
                Sad_par_BVA=length(window_indDexc(window_indDexc==ind_Apar));
                Sad_perp_BVA=length(window_indDexc(window_indDexc==ind_Aperp));
                [E_window] = ProximityRatio((Sdd_par_BVA)+(Sdd_perp_BVA),(Sad_par_BVA)+(Sad_perp_BVA));
            
                runE=[runE E_window];             
            end
            
                if length(runE)<runLength
                    runE=[runE NaN(1,runLength-length(runE))]; %pad with Nan placeholder
                else
                    runE=runE(1:runLength); %if this is happening you need to increase runLength!
                end  
        end 
        
        if anisoBVA
            
            %         numWindows=floor(length(indDexc/nBVA));
            startPh=1;
            endPh=startPh+nBVA-1; 
            runR=[];
            while endPh<length(indDexc)
                %Read as many nonoverlapping windows of length nBVA photons
                %as possible.
                window_indDexc=indDexc(startPh:endPh);
                startPh=endPh+1;
                endPh=startPh+nBVA-1;
                
                Sdd_par_BVA=length(window_indDexc(window_indDexc==ind_Dpar));
                Sdd_perp_BVA=length(window_indDexc(window_indDexc==ind_Dperp));
                Sad_par_BVA=length(window_indDexc(window_indDexc==ind_Apar));
                Sad_perp_BVA=length(window_indDexc(window_indDexc==ind_Aperp));

                [R_window] = Aniso(Sdd_par_BVA,Sdd_perp_BVA,'D',[]);
                runR=[runR R_window];             
            end
            
                if length(runR)<runLength
                    runR=[runR NaN(1,runLength-length(runR))]; %pad with Nan placeholder
                else
                    runR=runR(1:runLength); %if this is happening you need to increase runLength!
                end  
        end 
        
        
        
        
    else
        Eraw=0;
        Sraw=0;
        E=0;
        S=0;
    end
    
else   %ie, non-ALEX
    
    %How many photons in each channel after Donor excitation
    Sdd_par=length(ind(ind==ind_Dpar));
    Sdd_perp=length(ind(ind==ind_Dperp));
    Sad_par=length(ind(ind==ind_Apar));
    Sad_perp=length(ind(ind==ind_Aperp));
    
    %How many photons in each channel after Acceptor excitation - ZERO for
    %non ALEX
        Sda_par=0;
        Sda_perp=0;
    Saa_par=0;
    Saa_perp=0;
    
    %Correct for background
    Bdd_par=BKG(1);
    Bdd_perp=BKG(2);
    Bad_par=BKG(3);
    Bad_perp=BKG(4);
    Baa_par=BKG(5);
    Baa_perp=BKG(6);
    
    %Mean arrival times within burst: See Kudryavtsev/Lamb/Seidel 2012
    %ChemPhysChem 2012, vol 13, 1060-1078 for an interesting discussion on
    %the merits of abs(T_{GG+GR} - T_{RR}) < Threshold in order to filter
    %out photobleaching without filtering dynamics!1072-1074 Figure 8
    %especially
    
    %Mean photon arrival time after donor excitation (all photons) NOT
    %DEFINED FOR NON-ALEX
    Txd=0;
    %Mean photon arrival time after acceptor excitation (all photons) NOT
    %DEFINED FOR NON-ALEX
    Txa=0;
    %Mean photon arrival time in donor channel after donor excitation
    Tdd=mean(timetag(ind==ind_Dpar | ind==ind_Dperp));
    %Mean photon arrival time in acceptor channel after donor excitation
    Tad=mean(timetag(ind==ind_Apar | ind==ind_Aperp));
    
    
    if lifetime
        %copy lifetime but for non-ALEX
        %User wants time-resolved data within ALEX
        
        Irf_D=Itotal(Irf_DPar,Irf_DPerp,'D'); %if data was acquired without polarizers this should still be fine - Irf_DPerp will be zeros(1,256) - size may disagree due to clipping after Tpp
%         Irf_A=Itotal(Irf_APar,Irf_APerp,'A'); %if data was acquired without polarizers this should still be fine - Irf_DPerp will be zeros(1,256) - size may disagree due to clipping after Tpp
        
        edges_ss=0:16:4095; %rebinned
        dtb=16*dt; %the dt for binned data
        I_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
        I_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
%         I_Apar=histc(sstimeindD==ind_Apar),edges_ss);
%         I_Aperp=histc(sstime(indDexc==ind_Aperp),edges_ss);
        
        %offset and Itotal
        n = length(I_Dpar);
        tv = 1:n;
        tv=tv';
        [I_Dpar]=offsetter(I_Dpar,c_Dpar,tv,n);
        [I_Dperp]=offsetter(I_Dperp,c_Dperp,tv,n);
        I_D=Itotal(I_Dpar,I_Dperp,'D');
        
        mTauA=0;
        mTauD=0;
        
%         [tauD, ~]=getTauMLE_lin_fast(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9); %Tpp was converted to ns, all inputs should be ns.
%         [tauD,~,~]=getTauMLE_lin_fast_2d(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9);
        
% %         if repExc
% %             [tauD,~,~]=getTauMLE_lin_fast_2d_repExc(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9);
% %         else
% %             [tauD,~,~]=getTauMLE_lin_fast_2d(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9);            
% %         end
        
        
         if MLE1d
            [tauD,~]=getTauMLE_lin_fast(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9); %Tpp was converted to ns, all inputs should be ns.
        else
            if repExc
                [tauD,~,~]=getTauMLE_lin_fast_2d_repExc(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9);
            else
                [tauD,~,~]=getTauMLE_lin_fast_2d(Irf_D,I_D,dtb,Tpp*1E9,0,Tpp*1E9);
            end
        end
        
        
        
    else
        tauD=0;
        %         errD=0;
    end
    
    if pol
        %calculate anisotropy
        %calculate steady state anisotropy here
        [rD] = Aniso(Sdd_par-Bdd_par*burst_duration,Sdd_perp - Bdd_perp*burst_duration,'D',[]);
        [rDBkg] = Aniso(Sdd_par,Sdd_perp,'D',[]);
        %calculate steady state anisotropy here
        rA = 0 ;
    else
        rD=0;
        rA=0;
    end
    
    if FRET
        [Eraw] = ProximityRatio((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration));
         [Ebkg] = ProximityRatio((Sdd_par)+(Sdd_perp),(Sad_par)+(Sad_perp));
        [Sraw] =0;
        %Not using ALEX with global corection factors - meaningless if gamma,lk,dir are not already known (dir is from absorption crossections):
        [E] = correct_E_gamma_leak_dir((Sdd_par-Bdd_par*burst_duration)+(Sdd_perp-Bdd_perp*burst_duration),(Sad_par-Bad_par*burst_duration)+(Sad_perp-Bad_perp*burst_duration),[],[],[],[],'ABS');
        [S] = 0;
    else
        Eraw=0;
        Sraw=0;
        E=0;
        S=0;
    end
    
    
    if BVA
        
        startPh=1;
        endPh=startPh+nBVA-1;
        runE=[];
        while endPh<length(ind)
            %Read as many nonoverlapping windows of length nBVA photons
            %as possible.
            window_ind=ind(startPh:endPh);
            startPh=endPh+1;
            endPh=startPh+nBVA-1;
            
            Sdd_par_BVA=length(window_ind(window_ind==ind_Dpar));
            Sdd_perp_BVA=length(window_ind(window_ind==ind_Dperp));
            Sad_par_BVA=length(window_ind(window_ind==ind_Apar));
            Sad_perp_BVA=length(window_ind(window_ind==ind_Aperp));
            [E_window] = ProximityRatio((Sdd_par_BVA)+(Sdd_perp_BVA),(Sad_par_BVA)+(Sad_perp_BVA));
            
            runE=[runE E_window];
        end
        
        if length(runE)<runLength
            runE=[runE NaN(1,runLength-length(runE))]; %pad with Nan placeholder
        else
            runE=runE(1:runLength); %if this is happening you need to increase runLength!
        end
    end
    
    if anisoBVA
        
        startPh=1;
        endPh=startPh+nBVA-1;
        runR=[];
        while endPh<length(ind)
            %Read as many nonoverlapping windows of length nBVA photons
            %as possible.
            window_ind=ind(startPh:endPh);
            startPh=endPh+1;
            endPh=startPh+nBVA-1;
            
            Sdd_par_BVA=length(window_ind(window_ind==ind_Dpar));
            Sdd_perp_BVA=length(window_ind(window_ind==ind_Dperp));
%             Sad_par_BVA=length(window_ind(window_ind==ind_Apar));
%             Sad_perp_BVA=length(window_ind(window_ind==ind_Aperp));
            [R_window] = Aniso(Sdd_par_BVA,Sdd_perp_BVA,'D',[]);
            runR=[runR R_window];
        end
        
        if length(runR)<runLength
            runR=[runR NaN(1,runLength-length(runR))]; %pad with Nan placeholder
        else
            runR=runR(1:runLength); %if this is happening you need to increase runLength!
            fprintf('Increase length of runLength if this warning appears often\r\n')
        end
    end
    
    
    
end

Sdexc= Sdd_par + Sdd_perp + Sad_par + Sad_perp;
Saexc=Saa_par + Saa_perp;
%% Save all burst data to textfile for post-processing
numPh=length(ind(ind<=5));

% if eval(subEnsemble3_condition) && T3mode
% Convert2Bin('C:\test\FretBurst.bin',ind,sstime,timetag) 
% end

if Eraw>-1.5 && Eraw <1.5 && rD>-0.5 && rD <1 %Filter out obviously bad bursts
    
    if ~exist('mTauD','var')
        mTauD=NaN;
    end
    if ~exist('mTauA','var')
        mTauA=NaN;
    end
    
    
    currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ... %4
        Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...   %10
        Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...    %16
        Txd Txa Tdd Tad ...                              %20
        tauD rD rA...            %23
        Eraw Sraw E S numPh Sda_par Sda_perp... %30
        mTauD mTauA];  %31 32             
    
    fprintf(fid_burst_txt,[repmat('%f \t',size(currRecord)) '\r\n'],currRecord);
    
    
    
    % if exist('BurstInfo.mat','file')
    %     load('BurstInfo.mat','AllRecords')
    %     AllRecords=[AllRecords;currRecord];
    %     size(AllRecords)
    %         delete('BurstInfo.mat')
    %     saved=0;
    %     while saved==0;
    %         try
    %             save('BurstInfo.mat','AllRecords')
    %             saved=1;
    %         catch
    %             fprintf('Save error trying again')
    %             pause(.25);
    %             save('BurstInfo.mat','AllRecords')
    %         end
    %     end
    % else
    %     AllRecords=currRecord;
    %     save('BurstInfo.mat','AllRecords')
    % end
    % clear AllRecords
    
    AllRecords=[AllRecords;currRecord];
    
    if BVA
    burstID=length(AllRecords(:,1));
    runE=[burstID Ebkg runE]; %so that we know which burst it came from if we want to track it.
    BVARecord=[BVARecord runE(:)];
    end
    
    if anisoBVA
    burstID=length(AllRecords(:,1));
    runR=[burstID rDBkg runR]; %so that we know which burst it came from if we want to track it.
    anisoBVARecord=[anisoBVARecord runR(:)];
    end
    
    
    %Option to save photons from this burst if it passes some test
    %For example: If lb<E<ub save index,sstime,timetag as T3 record with a
    %custom special marker denoting seperate bursts.
 
    
  
    
    if eval(subEnsemble1_condition) && T3mode && lifetime
        %A logical expression using the values in currRecord as a condition for
        %saving a subensemble. Can be constructed from AND, OR, XOR etc.
        %Eg. 0.3<Eraw && Eraw < 0.7 && (Saa_perp+Saa_par)>10 && abs(Txd-Txa)<0.7
        
        edges_ss=0:1:4095; %rebinned
        if ~ALEX
            tsubEns1_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
            tsubEns1_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
            tsubEns1_Apar=histc(sstime(ind==ind_Apar),edges_ss);
            tsubEns1_Aperp=histc(sstime(ind==ind_Aperp),edges_ss);
        else
            tsubEns1_Dpar=histc(sstimeDexc(indDexc==ind_Dpar),edges_ss);
            tsubEns1_Dperp=histc(sstimeDexc(indDexc==ind_Dperp),edges_ss);
            tsubEns1_Apar=histc(sstimeDexc(indDexc==ind_Apar),edges_ss);
            tsubEns1_Aperp=histc(sstimeDexc(indDexc==ind_Aperp),edges_ss);
        end
        
        %offset 
        if isempty(tsubEns1_Dpar)
            tsubEns1_Dpar=zeros(size(subEns1_Dpar));
            tsubEns1_Dperp=zeros(size(subEns1_Dperp));
            tsubEns1_Apar=zeros(size(subEns1_Apar));
            tsubEns1_Aperp=zeros(size(subEns1_Aperp));
        end
%         n = length(tsubEns1_Dpar);
%         tv = 1:n;
%         tv=tv';
%         [tsubEns1_Dpar]=offsetter(tsubEns1_Dpar,c_Dpar,tv,n);
%         [tsubEns1_Dperp]=offsetter(tsubEns1_Dperp,c_Dperp,tv,n);
%         [tsubEns1_Apar]=offsetter(tsubEns1_Apar,c_Dpar,tv,n);
%         [tsubEns1_Aperp]=offsetter(tsubEns1_Aperp,c_Dperp,tv,n);
%         [tsubEns1_Dpar]=circshift(tsubEns1_Dpar,[c_Dpar,1]);
%         [tsubEns1_Dperp]=circshift(tsubEns1_Dperp,[c_Dperp,1]);
%         [tsubEns1_Apar]=circshift(tsubEns1_Apar,[c_Dpar,1]);
%         [tsubEns1_Aperp]=circshift(tsubEns1_Aperp,[c_Dperp,1]);
        try
        subEns1_Dpar=subEns1_Dpar+tsubEns1_Dpar;
        subEns1_Dperp=subEns1_Dperp+tsubEns1_Dperp;
        subEns1_Apar=subEns1_Apar+tsubEns1_Apar;
        subEns1_Aperp=subEns1_Aperp+tsubEns1_Aperp;
        catch
           disp('Problem with SE1 condition. Ignoring burst to SE1') 
        end
        
    end
    
    if eval(subEnsemble3_condition) && T3mode && lifetime
        %A logical expression using the values in currRecord as a condition for
        %saving a subensemble. Can be constructed from AND, OR, XOR etc.
        %Eg. 0.3<Eraw && Eraw < 0.7 && (Saa_perp+Saa_par)>10 && abs(Txd-Txa)<0.7
        
        edges_ss=0:1:4095; %rebinned
        if ~ALEX
            tsubEns3_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
            tsubEns3_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
            tsubEns3_Apar=histc(sstime(ind==ind_Apar),edges_ss);
            tsubEns3_Aperp=histc(sstime(ind==ind_Aperp),edges_ss);
        else
            tsubEns3_Dpar=histc(sstimeDexc(indDexc==ind_Dpar),edges_ss);
            tsubEns3_Dperp=histc(sstimeDexc(indDexc==ind_Dperp),edges_ss);
            tsubEns3_Apar=histc(sstimeDexc(indDexc==ind_Apar),edges_ss);
            tsubEns3_Aperp=histc(sstimeDexc(indDexc==ind_Aperp),edges_ss);
        end
        
        %offset 
        if isempty(tsubEns3_Dpar)
            tsubEns3_Dpar=zeros(size(subEns3_Dpar));
            tsubEns3_Dperp=zeros(size(subEns3_Dperp));
            tsubEns3_Apar=zeros(size(subEns3_Apar));
            tsubEns3_Aperp=zeros(size(subEns3_Aperp));
        end
%         n = length(tsubEns3_Dpar);
%         tv = 1:n;
%         tv=tv';
%         [tsubEns3_Dpar]=offsetter(tsubEns3_Dpar,c_Dpar,tv,n);
%         [tsubEns3_Dperp]=offsetter(tsubEns3_Dperp,c_Dperp,tv,n);
%         [tsubEns3_Apar]=offsetter(tsubEns3_Apar,c_Dpar,tv,n);
%         [tsubEns3_Aperp]=offsetter(tsubEns3_Aperp,c_Dperp,tv,n);
%            [tsubEns3_Dpar]=circshift(tsubEns3_Dpar,[c_Dpar,1]);
%         [tsubEns3_Dperp]=circshift(tsubEns3_Dperp,[c_Dperp,1]);
%         [tsubEns3_Apar]=circshift(tsubEns3_Apar,[c_Dpar,1]);
%         [tsubEns3_Aperp]=circshift(tsubEns3_Aperp,[c_Dperp,1]);
        try
        subEns3_Dpar=subEns3_Dpar+tsubEns3_Dpar;
        subEns3_Dperp=subEns3_Dperp+tsubEns3_Dperp;
        subEns3_Apar=subEns3_Apar+tsubEns3_Apar;
        subEns3_Aperp=subEns3_Aperp+tsubEns3_Aperp;
        catch
           disp('Problem with SE3 sizes. Ignoring burst to SE3') 
        end
        
    end
    
    if eval(subEnsemble2_condition) && T3mode && lifetime
        %A logical expression using the values in currRecord as a condition for
        %saving a subensemble. Can be constructed from AND, OR, XOR etc.
        %Eg. 0.3<Eraw && Eraw < 0.7 && (Saa_perp+Saa_par)>10 && abs(Txd-Txa)<0.7
        
        edges_ss=0:1:4095; %rebinned
        if ~ALEX
            tsubEns2_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
            tsubEns2_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
            tsubEns2_Apar=histc(sstime(ind==ind_Apar),edges_ss);
            tsubEns2_Aperp=histc(sstime(ind==ind_Aperp),edges_ss);
        else
            tsubEns2_Dpar=histc(sstimeDexc(indDexc==ind_Dpar),edges_ss);
            tsubEns2_Dperp=histc(sstimeDexc(indDexc==ind_Dperp),edges_ss);
            tsubEns2_Apar=histc(sstimeDexc(indDexc==ind_Apar),edges_ss);
            tsubEns2_Aperp=histc(sstimeDexc(indDexc==ind_Aperp),edges_ss);
        end
        
        if isempty(tsubEns2_Dpar)
            tsubEns2_Dpar=zeros(size(subEns2_Dpar));
            tsubEns2_Dperp=zeros(size(subEns2_Dperp));
            tsubEns2_Apar=zeros(size(subEns2_Apar));
            tsubEns2_Aperp=zeros(size(subEns2_Aperp));
        end
        %offset and Itotal
%         n = length(tsubEns2_Dpar);
%         tv = 1:n;
%         tv=tv';
%         [tsubEns2_Dpar]=offsetter(tsubEns2_Dpar,c_Dpar,tv,n);
%         [tsubEns2_Dperp]=offsetter(tsubEns2_Dperp,c_Dperp,tv,n);
%         [tsubEns2_Apar]=offsetter(tsubEns2_Apar,c_Dpar,tv,n);
%         [tsubEns2_Aperp]=offsetter(tsubEns2_Aperp,c_Dperp,tv,n);
%            [tsubEns2_Dpar]=circshift(tsubEns2_Dpar,[c_Dpar,1]);
%         [tsubEns2_Dperp]=circshift(tsubEns2_Dperp,[c_Dperp,1]);
%         [tsubEns2_Apar]=circshift(tsubEns2_Apar,[c_Dpar,1]);
%         [tsubEns2_Aperp]=circshift(tsubEns2_Aperp,[c_Dperp,1]);
        try
        subEns2_Dpar=subEns2_Dpar+tsubEns2_Dpar;
        subEns2_Dperp=subEns2_Dperp+tsubEns2_Dperp;
        subEns2_Apar=subEns2_Apar+tsubEns2_Apar;
        subEns2_Aperp=subEns2_Aperp+tsubEns2_Aperp;
        catch
           disp('Problem with SE2 dimensions. Ignoring Burst to SE2')
        end
        
    end
    
    if eval(subEnsemble4_condition) && T3mode && lifetime
        %A logical expression using the values in currRecord as a condition for
        %saving a subensemble. Can be constructed from AND, OR, XOR etc.
        %Eg. 0.3<Eraw && Eraw < 0.7 && (Saa_perp+Saa_par)>10 && abs(Txd-Txa)<0.7
        
        edges_ss=0:1:4095; %rebinned
        if ~ALEX
            tsubEns4_Dpar=histc(sstime(ind==ind_Dpar),edges_ss);
            tsubEns4_Dperp=histc(sstime(ind==ind_Dperp),edges_ss);
            tsubEns4_Apar=histc(sstime(ind==ind_Apar),edges_ss);
            tsubEns4_Aperp=histc(sstime(ind==ind_Aperp),edges_ss);
        else
            tsubEns4_Dpar=histc(sstimeDexc(indDexc==ind_Dpar),edges_ss);
            tsubEns4_Dperp=histc(sstimeDexc(indDexc==ind_Dperp),edges_ss);
            tsubEns4_Apar=histc(sstimeDexc(indDexc==ind_Apar),edges_ss);
            tsubEns4_Aperp=histc(sstimeDexc(indDexc==ind_Aperp),edges_ss);
        end
        
        if isempty(tsubEns4_Dpar)
            tsubEns4_Dpar=zeros(size(subEns4_Dpar));
            tsubEns4_Dperp=zeros(size(subEns4_Dperp));
            tsubEns4_Apar=zeros(size(subEns4_Apar));
            tsubEns4_Aperp=zeros(size(subEns4_Aperp));
        end
        %offset and Itotal
%         n = length(tsubEns4_Dpar);
%         tv = 1:n;
%         tv=tv';
%         [tsubEns2_Dpar]=offsetter(tsubEns2_Dpar,c_Dpar,tv,n);
%         [tsubEns2_Dperp]=offsetter(tsubEns2_Dperp,c_Dperp,tv,n);
%         [tsubEns2_Apar]=offsetter(tsubEns2_Apar,c_Dpar,tv,n);
%         [tsubEns2_Aperp]=offsetter(tsubEns2_Aperp,c_Dperp,tv,n);
%            [tsubEns2_Dpar]=circshift(tsubEns2_Dpar,[c_Dpar,1]);
%         [tsubEns2_Dperp]=circshift(tsubEns2_Dperp,[c_Dperp,1]);
%         [tsubEns2_Apar]=circshift(tsubEns2_Apar,[c_Dpar,1]);
%         [tsubEns2_Aperp]=circshift(tsubEns2_Aperp,[c_Dperp,1]);
        try
        subEns4_Dpar=subEns4_Dpar+tsubEns4_Dpar;
        subEns4_Dperp=subEns4_Dperp+tsubEns4_Dperp;
        subEns4_Apar=subEns4_Apar+tsubEns4_Apar;
        subEns4_Aperp=subEns4_Aperp+tsubEns4_Aperp;
        catch
           disp('Problem with SE2 dimensions. Ignoring Burst to SE2')
        end
        
    end
    
end


end

