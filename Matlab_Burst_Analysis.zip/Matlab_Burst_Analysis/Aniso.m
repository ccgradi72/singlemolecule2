function [r] = Aniso(Ipar,Iperp,exc,Gtrial)
%UNTITLED4 Summary of this function goes here
%   Two purposes: When G is known, call Aniso(Ipar,Iperp,[]) and it will
%   use the global G factor. 

global Gdd k1 k2 Gaa

if isempty(Gtrial)
    switch exc
        case 'D'
            Gtrial=Gdd;
        case 'd'
            Gtrial=Gdd;
        case 'A'
            Gtrial=Gaa;
        case 'a'
            Gtrial=Gaa;
        otherwise
            sprintf('Unknown excitation input to Aniso, Default used [G=1]')
            Gtrial=1;
    end
end

Ipar=Ipar(:)';
Iperp=Iperp(:)';
r=(Ipar-Gtrial*Iperp)./((1-3*k2)*(Ipar)+Gtrial*(2-3*k1)*Iperp);


end

