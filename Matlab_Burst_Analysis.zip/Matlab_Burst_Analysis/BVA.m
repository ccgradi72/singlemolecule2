function [ ] = BVA( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%Notation follows closely to Torella et al Biophys J 2011 BVA paper
clc;
close all;

% format=
hl=0;
NewData=1;
nBVA=5;
CI=0.05;

MC=1; %do Monte Carlo Error analysis?
MC2=0; %Extra Monte Carlo GRaph
NumMCtrials=500;

if exist('BVAworkstate.mat','file') && ~NewData
    %big BVAfiles take a long time to read text, better to load if you have
    %already worked with this BVAfile already.
    load('BVAworkstate.mat')
    fprintf('Finished loading from .mat file\r\n')
else
    % Find Data
    [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BVAworkstate.mat','DATA','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)
end


xi=0;
xf=1;
R=25; %number of bins
dE=(xf-xi)/R;
% Ebin_Edges=linspace(xi,xf,R+1);
Ebin_Edges=0:dE:xf;
E=DATA(2,:); %E is stored in second row

BinThr=50; % only consider s_{E}^{*} values from bins with at least BinThr bursts

SE=NaN(1,length(Ebin_Edges)-1);
p_lb=NaN(1,length(Ebin_Edges)-1);
p_ub=NaN(1,length(Ebin_Edges)-1);
Bin_center=zeros(1,length(Ebin_Edges)-1);
sigmaE=zeros(1,length(Ebin_Edges)-1);
for k=1:length(Ebin_Edges)-1
    fprintf('Bin %f of %f \r\n',k,length(SE))
    %Find which bursts have Ei between Ebin_Edges(i) and Ebin_Edges(i+1)
    Bin_DATA=DATA(:,E>=Ebin_Edges(k) & E< Ebin_Edges(k+1)); %the subset of DATA of interest to this bin
    
    Bin_center(k)=0.5*(Ebin_Edges(k)+Ebin_Edges(k+1));
    sigmaE(k)=sqrt(Bin_center(k).*(1-Bin_center(k))/nBVA) %expected shot noise sigma
    
    %does the bin have at least BinThr bursts
    if size(DATA,2)>BinThr
        %do calc
        [SE(k), p_lb(k), p_ub(k)]=SE_in_Bin(Bin_DATA,Bin_center(k),sigmaE(k))
    end
end

size(SE)
size(p_lb)
size(p_ub)

NumNan=length(isnan(SE)) %number of rejected bins

[nE,cE] = hist(E,Bin_center);

if MC2
    nplots=3;
else
    nplots=2;
end

figure;
subplot(nplots,1,1)
bar(cE,nE,'BarWidth',0.75,'FaceColor', 'r');
%         xlabel('E*')
ylabel('Frequency')
set(gca,'XTickLabel',[])
xlim([xi xf])
set(gca,'Box','on')
h1=gca;
subplot(nplots,1,2)
hold all
[pb_std]=PerBurstSTD(DATA);

edges{1}=Bin_center; % bin for x axis
nBins=20;
edges{2}=0:0.4/nBins:0.4; %bin for y axis
HISTME=[E(:),pb_std(:)];
nhis = hist3(HISTME,'Edges',edges);
n1 = nhis';
[C,hCont]=contourf(edges{1},edges{2},log(n1+1),15);
colormap(flipud(gray));
set(hCont,'LineColor','none')
plot(Bin_center,sigmaE,'-go','MarkerFaceColor','g')
% scatter(E,pb_std)
if MC
    
   plot(Bin_center(p_ub<CI),SE(p_ub<CI),'^r','MarkerFaceColor','r')   
   plot(Bin_center(p_ub>CI),SE(p_ub>CI),'sr','MarkerFaceColor','r')
else
        
   plot(Bin_center,SE,'sr','MarkerFaceColor','r')
    
end
ylabel('STD of FRET')
set(gca,'YTick',[0.05 0.15 0.25 0.35])
set(gca,'YTickLabel',{'0.05';'0.15';'0.25';'0.35'})
xlim([xi xf])
if MC2
    set(gca,'XTickLabel',[])
end
hold off
set(gca,'Box','on')
h2=gca;


if MC2
    subplot(nplots,1,3)
    hold all
    plot(Bin_center,p_ub,'om','MarkerFaceColor','m')
    plot(Bin_center,-p_lb,'oc','MarkerFaceColor','c')
    plot(Bin_center,zeros(size(Bin_center)),'-k')
    plot(Bin_center,repmat(0.05,size(Bin_center)),'-m')
    plot(Bin_center,repmat(-0.05,size(Bin_center)),'-c')
    ylabel({'P(SE>\sigma_{E})';'P(SE<\sigma_{E})'})
    xlim([xi xf])
    set(gca,'Box','on')
    hold off
    h3=gca;
end
xlabel('E*')

if ~MC2
    bot=0.1;
    left=0.2;
    hs=0.005;
    width=0.6;
    height=0.425;
    set(h1,'Position',[ left bot+height+hs width  height])
    set(h2,'Position',[left bot width height])
else
    bot=0.1;
    left=0.2;
    hs=0.005;
    width=0.6;
    height=0.35;
    heightp=height/2;
    set(h1,'Position',[ left bot+height+2*hs+heightp width  height])
    set(h2,'Position',[left bot+heightp+hs width height])
    set(h3,'Position',[left bot width heightp])
end

% fontsizeax=11;
% ticksize=11;
savetype='-dpng';
% savetype='-dpdf';
resolution='-r600';

papersizex=9;
papersizey=6;
marginx=0.5;
marginy=0.5;
fontsizeax=12;

ticksize=12;

        set(h1,'FontSize', ticksize);
        set(h1,'FontWeight','Bold');
        set(h1,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'on'      , ...
            'YMinorTick'  , 'on'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', 1) ;
        set(h1, 'Box' , 'on' )
        set(get(h1,'xlabel'),'FontSize',fontsizeax, 'FontWeight', 'Bold'...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
         set(get(h1,'ylabel'),'FontSize',fontsizeax, 'FontWeight', 'Bold'...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
        set(h2,'FontSize', ticksize);
        set(h2,'FontWeight','Bold');
        set(h2,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'on'      , ...
            'YMinorTick'  , 'on'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', 1) ;
        set(h2, 'Box' , 'on' )
        set(get(h2,'xlabel'),'FontSize',fontsizeax, 'FontWeight', 'Bold'...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
         set(get(h2,'ylabel'),'FontSize',fontsizeax, 'FontWeight', 'Bold'...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
        
        if MC2
        set(h3,'FontSize', ticksize);
        set(h3,'FontWeight','Bold');
        set(h3,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'on'      , ...
            'YMinorTick'  , 'on'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', 1) ;
        set(h3, 'Box' , 'on' )
        set(get(h3,'xlabel'),'FontSize',fontsizeax, 'FontWeight', 'Bold'...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
         set(get(h3,'ylabel'),'FontSize',fontsizeax, 'FontWeight', 'Bold'...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
        end
        set(gcf,'PaperUnits','inches');
        set(gcf, 'PaperSize', [papersizex papersizey]);
        set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
            papersizey-2*(marginy)]);
        set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
    mytitle=sprintf('%s.png',FileName);
print(savetype,resolution,mytitle)
save('BVAResults.mat')
  
        
    function [SE,p_lb,p_ub]=SE_in_Bin(DATA,Bin_center,sigmaE)
        
        %the first two rows (burstID and Ei) of DATA are no longer of interest in this
        %nested function ----> chop them off
        %         size(DATA)
        DATA(1:2,:)=[];
        %         size(DATA)
        
        sumM=sum(sum(~isnan(DATA))); %how many windowsare there total, ie sum(M_{i}) in Torella et al
        %         size(sumMtest)
        mu=0;
        for i=1:size(DATA,2) % the i index sum of Eq 6 in Torella et al (Burst Loop)
            
            BOI=DATA(:,i); %burst of interest BOI
            mu=mu+ sum(BOI(~isnan(BOI))/sumM); %first term controlls outer sum (eq6) and second term is inner sum of (Eq6)
            
        end
        SE=0;
        for i=1:size(DATA,2) % the i index sum of Eq 6 in Torella et al (Burst Loop)
            
            BOI=DATA(:,i); %burst of interest BOI
            %             SoS(i)=; %SumOfSquares
            SE=SE+ sum(((BOI(~isnan(BOI))-mu).^2)/sumM); %first and second term are outer and inner sum respectively
            
        end
        
        SE=sqrt(SE);
        
        %          s=0:0.005:0.5;
        %          %this is the approximate analytical solution for the sampling
        %          %distribution of standard deviation P(sigma) expected for M
        %          %windows of nBVA photons, ie when shot noise sigmaE.
        %
        %          Psig1=2*(sumM/(2*sigmaE.^2)).^((sumM-1)/2);
        %          Psig2=exp(-(sumM*s.^2)./((2*sigmaE.^2)));
        %          Psig3=s.^(sumM-2)
        %          Psig4=gamma((sumM-1)/2);
        %          checkNorm=trapz(s,Psig)
        %          checkend=Psig(end)/max(Psig);
        
        %The p-value is defined as the probability,
        %under the assumption of hypothesis H, of obtaining a result equal
        %to or more extreme than what was actually observed.
        %
        %         ind=find(min(abs(s-SE)));
        %         s(ind)
        %         p=trapz(s(ind:end),Psig(ind:end))
        
        
        if MC
            MC_SE=zeros(1,NumMCtrials);
            for z=1:NumMCtrials
                %            fprintf('MC trial %f of %f',z,NumMCtrials)
                
                tmu=0;
                for i=1:size(DATA,2) % the i index sum of Eq 6 in Torella et al (Burst Loop)
                    BOI=DATA(:,i); %burst of interest BOI
                    FA{i} = binornd(nBVA,Bin_center,1,length(BOI(~isnan(BOI)))); %random number drawn from bionomial
                    %distribution with n trials, E
                    %probability of success.
                    
                    tmu=tmu+ sum((FA{i}/nBVA)/sumM);
                    
                end
                tSE=0;
                for i=1:size(DATA,2) % the i index sum of Eq 6 in Torella et al (Burst Loop)
                    
                    tSE=tSE+ sum((((FA{i}/nBVA)-tmu).^2)/sumM); %first and second term are outer and inner sum respectively
                    
                end
                
                MC_SE(z)=sqrt(tSE);
                
            end
            
            
            %The p-value is defined as the probability,
            %under the assumption of hypothesis H, of obtaining a result equal
            %to or more extreme than what was actually observed.
            %Here the hypothesis is that the variance is from shot noise.
            %If H is true, what is the probability I would get a value as
            %"extreme" as SE (either right hand tail or left tail)?
            p_ub=length(MC_SE(MC_SE>=SE))
            p_ub=p_ub/NumMCtrials
            p_lb=length(MC_SE(MC_SE<=SE))
            p_lb=p_lb/NumMCtrials
            
            sigmaE
            SE
            
            
            figure;
            %        edges=0:0.05:0.4
            [n,c] = hist(MC_SE,20);
            [~,ind]=max(n)
            MCmode=c(ind)
            meanMCstd=mean(MC_SE)
            bar(c,n,'BarWidth',0.75,'FaceColor', 'r');
            xlabel('MC_SE')
            ylabel('Frequency')
            title(sprintf('sigmaE=%f SE =%f',sigmaE,SE))
            drawnow
            
        else
            p_ub=NaN;
            p_lb=NaN;
        end

            
    end


    function [pb_std]=PerBurstSTD(DATA)

        for i=1:size(DATA,2) % the i index sum of Eq 6 in Torella et al (Burst Loop)
            
            BOI=DATA(3:end,i); %burst of interest BOI
            pb_std(i)=std((BOI(~isnan(BOI))),1); 

        end


    end
end

