
X=10;
Y=80;

z=0:0.01:1;

Pz=(z.^(X)).*((1-z).^Y);
Pz=Pz/trapz(z,Pz);

figure;
hold all
plot(z,Pz)

X=2*X;
Y=2*Y;

z=0:0.01:1;

Pz=(z.^(X)).*((1-z).^Y);
Pz=Pz/trapz(z,Pz);
plot(z,Pz)