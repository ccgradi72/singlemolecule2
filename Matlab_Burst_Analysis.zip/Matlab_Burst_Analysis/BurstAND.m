function [i_start,i_end] = BurstAND(i_start_D,i_end_D,i_start_A,i_end_A)
%UNTITLED3 Returns the i_start and i_end of the interesection of bursts
%from two different burst searches, here D and A, but could be whatever you
%want.

%   Detailed explanation goes here

i_start=[];
i_end=[];

for i=1:length(i_start_D)
    
    if ~any(i_start_A<i_end_D(i) && i_start_A>i_start_D(i))
        %there is an A burst start within D burst
        
        IND=find(i_start_A<i_end_D(i) && i_start_A>i_start_D(i));
        
        for j=1:length(IND)
            i_start=[i_start i_start_A(IND(j))];
            
            if i_end_A(IND(j))<i_end_D*(i)
                %This acceptor burst is entirely contained in a donor burst
                
                i_end=[i_end i_end_A(IND(j))];
                
                
            else
                %This acceptor burst starts inside a donor burst, but
                %finished outside
                
                i_end=[i_end i_end_D(i)];
                
            end
            
        end
        
    end
    
    if ~any(i_end_A>i_start_D(i) && i_end_A<i_end_D(i))
        %there there may be an A burst end within the D burst whose start was
        %before D-start
        
        IND=find(i_end_A>i_start_D(i) && i_end_A<i_end_D(i));
        %finds all burst A ends contained within D burst
        
        for j=1:length(IND)
            
            if i_start_A(IND(j))<i_start_D(i)
                %This A burst has its end inside a D burst but its start
                %before the start of the D burst. It would not have previously
                %been counted. The intersection burst should then start
                %with D end with A.
                i_start=[i_start i_start_D(i)];
                i_end=[i_end i_end_A(IND(j))];
            end
            
            %there will also be ends of A bursts inside D burst whose start
            %does not occur before i_start_D, however, they would be
            %counted by previous if statment since there starts are within
            %burst.
            
        end
        
    end
    
    % We are now left with the cases where there are no burst
    % A ends or burst A starts within the donor burst of interest.
    
    %We need to differentiate between a donor burst in which there was no
    %accompanying acceptor burst - and the case in which the donor burst
    %lies completely within the acceptor burst
    
    %the first A starts before the D start.
    [~,IND]=max(i_start_A<i_start_D(i));
    
    if i_end_A(IND)>i_end_D(i)
        %the A burst completely contains the D burst
        
        ind_start=[i_start i_start_D(i)];
        i_end=[i_end i_end_D(i)];
    end
    
end

end


