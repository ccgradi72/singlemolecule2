function [ ] = TransferEffHist( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

clc;
close all;

hl=0;
NewData=1;

xf=1.2;
xi=-0.2;
nxBins=50;
dx=(xf-xi)/nxBins;
edges{1}=[xi:dx:xf]; % bin for x axis

if exist('BurstWorkstate.mat','file') && ~NewData
    %big files take a long time to read text, better to load if you have
    %already worked with this file already.
    load('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading from .mat file\r\n')
else
    % Find Data
    [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)
end

%DATA is number of bursts by 27 columns with each column representing a
%parameter describing the burst (eg. duration, E, anisotropy, lifetime etc)

%recall bursts were saved as
%currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ...
%        Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...
%        Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...
%        Txd Txa Tdd Tad ...
%        tauD rD rA...
%        Eraw Sraw E S];

% size(DATA)

getLk=0; %retrieve a saved Leakage file

if getLk 
        load('LkMat','Lk')
        fprintf('The  leakage %0.3f was loaded ',Lk)    
        
end

S=DATA(:,27);
E=DATA(:,24);
Txd=DATA(:,17);
Txa=DATA(:,18);


% % filt=S<-6;
% % E(filt)=[];
% % % S(filt)=[];
% % Txd(filt)=[];
% % Txa(filt)=[];
% % filt=S>45;
% % E(filt)=[];
% % S(filt)=[];
% % Txd(filt)=[];
% % Txa(filt)=[];
% filt=E<-0.2 | E>1.2;
% E(filt)=[];
% S(filt)=[];
% Txd(filt)=[];
% Txa(filt)=[];
% % S(S<-6)=[];
% % hist(S,linspace(-6,max(S),100))
% 
% [hCont,hx ,hy,hMain] =Histogram2d(E,S,[-0.2 1.2],[-0.2 1.2],30,30,5,'$\rm E$','$\rm S$',[],[],'myALEX')
% % smoothhist2D([E(:) S(:)],5,[100 100])
% set(hCont,'LineColor','none')
% set(hMain,'XTick',[0 0.5 1])
% set(hMain,'XTickLabel',{'0'; '0.5'; '1'})
% set(hMain,'YTick',[0 0.5 1])
% set(hMain,'YTickLabel',{'0'; '0.5'; '1'})
% 
% set(gcf, 'PaperPositionMode', 'auto');
% 
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% % fontsizeax=12;
%         set(gcf, 'PaperSize', [papersizex papersizey]);
%         set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%             papersizey-2*(marginy)]);
%         set(gcf, 'PaperPositionMode','auto');
%         set(gcf, 'color', 'w');
% 
% print('-dpng','-r600','EandSCarpet2'); %save in same directory as input data
% 
% Efilt=E(S<0.7);
% xf=1.2;
% xi=-0.2;
% nxBins=50;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis
% [nE,cE] = hist(E,edges{1});
% [nEf,cEf] = hist(Efilt,edges{1});
% figure;
% hold all
% bar(cE,nE,1)
% h = findobj(gca,'Type','patch');
% set(h,'FaceColor','r','EdgeColor','w','facealpha',0.5)
% bar(cEf,nEf,1)
% size(h)
% h = findobj(gca,'Type','patch');
% set(h(1),'FaceColor','b','facealpha',0.5);
% size(h)
% ylabel('Frequency')
% xlabel('E')
% legend(h,'ALEX S<0.7','No ALEX ')
% axis tight
% xlim([xi xf])



AllRecords=DATA;

Fd=AllRecords(:,5)+AllRecords(:,6) - (AllRecords(:,11) + AllRecords(:,12)).*AllRecords(:,3);
Fa=AllRecords(:,7)+AllRecords(:,8) - (AllRecords(:,13)+AllRecords(:,14)).*AllRecords(:,3);
Faa=AllRecords(:,9)+AllRecords(:,10) - (AllRecords(:,15)+AllRecords(:,16)).*AllRecords(:,3);

filt=(Fd + Fa<5) | Faa<5;

Fd(filt)=[];
Fa(filt)=[];
Faa(filt)=[];

% Fd(Fd<0)=[];
% Fa(Fa<0)=[];
% Faa(Faa<0)=[];

xf=150;
xi=1;
nxBins=50;
dx=(xf-xi)/nxBins;
edges{1}=[xi:dx:xf]; % bin for x axis

figure;
hold all
[nFd,cFd] = hist(Fd,edges{1});
[nFa,cFa] = hist(Fa,edges{1});
[nFaa,cFaa] = hist(Faa,edges{1});
stairs(cFd,nFd)
stairs(cFa,nFa)
stairs(cFaa,nFaa)
axis tight
% xlim([cFd(1) cFd(end)])
 xlabel('Fx=Sx-Bx ')
ylabel('Frequency')
legend('Fd','Fa','Faa')

figure;
Sraw=(Fd+Fa)./(Fd+Fa+Faa);
hist(Sraw,50);

figure;
Eraw=(Fa)./(Fd+Fa);
hist(Eraw,50);
    %from the background corrected donor and accepter counts in each burst
    %we now seek the ratio Lk=Fa/Fd for donor only sample. 

    g=1.05;
    Q=1.1;
    gamma=1;
%     di=(A532/D532)*(Aeps/Deps);
    di=0.0;

[Efull] = correct_E_gamma_leak_dir(Fd,Fa,[],gamma,Lk,di,'ABS');

    
% Efull=DATA(:,24);
Efull=Efull(:);
% B=1000;
BootE=repmat(Efull,B,1);
size(BootE)

xf=1.2;
    xi=-0.2;
    nxBins=50;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
[nEraw,cEraw] = hist(Efull,edges{1});

% figure;
% hold all;
% bar(cEraw,nEraw,'BarWidth',0.75,'FaceColor', [160 160 160]/256);
%         xlabel('E')
%         ylabel('Frequency')
%         xlim([xi xf])
%         ylim([0 1.2*max(nEraw)])
        
Ec0=[0.1 0.2 0.5 0.8 0.9];
fixE=[0 0 0];
nPh=20;

for i=1:numMC
r=randi([1, length(BootE)],length(Efull),1);
Esample=BootE(r);
[nErawMAT(:,i),cEraw] = hist(Esample,edges{1});
end
stdE=std(nErawMAT,1,2);
% stdE=[]
[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=FitGaussMix(nEraw,cEraw,stdE,Ec0,fixE,nPh);

for i=1:numMC
    r=randi([1, length(BootE)],length(Efull),1);
Esample=BootE(r);
[snEraw,cEraw] = hist(Esample,edges{1});
[smodelParam(:,i),~,~,~,~,~,~]=FitGaussMix(snEraw,cEraw,stdE,Ec0,fixE,nPh);

end

dmodelParam=std(smodelParam,1,2)

        fEc=modelParam(1:length(Ec0));
        fw=modelParam(length(Ec0)+1:2*length(Ec0));
        fA=modelParam(2*length(Ec0)+1:end);
        
        dfEc=dmodelParam(1:length(Ec0));
        dfw=dmodelParam(length(Ec0)+1:2*length(Ec0));
        dfA=dmodelParam(2*length(Ec0)+1:end);
        
dof = length(residual)-3*length(Ec0);
redchi=resnorm/dof;
        fprintf('The reduced Chi^2 is %0.3f \r\n',redchi)
        
        for i=1:length(Ec0)
        fprintf('The fitted mean %d: %.3f +/- %.3f \r\n',i,fEc(i),dfEc(i))
        fprintf('The fitted width %d: %.3f +/- %.3f \r\n',i,fw(i),dfw(i))
        fprintf('The fitted area %d: %.3f +/- %.3f \r\n',i,fA(i),dfA(i))
        end

        
FitGaussMixResult(nEraw,cEraw,length(Ec0),modelParam,residual)


end

