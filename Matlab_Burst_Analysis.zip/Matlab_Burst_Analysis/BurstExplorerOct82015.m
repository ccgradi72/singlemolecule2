function [ ] = BurstExplorerOct82015( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


global name
name='1mW'

clc;
close all;

hl=0;
NewData=1;

% xf=1.2;
% xi=-0.2;
% nxBins=50;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis

if exist('BurstWorkstate.mat','file') && ~NewData
    %big files take a long time to read text, better to load if you have
    %already worked with this file already.
    load('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading from .mat file\r\n')
else
    % Find Data
    [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)
end

%DATA is number of bursts by 28 columns with each column representing a
%parameter describing the burst (eg. duration, E, anisotropy, lifetime etc)

%recall bursts were saved as
%currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ... 4
%        Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ... 10
%        Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ... 16
%        Txd Txa Tdd Tad ... 20
%        tauD rD rA... 23
%        Eraw Sraw E S numPh Sda_par Sda_perp]; 30

% %  currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ... %4
% %         Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...   %10
% %         Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...    %16
% %         Txd Txa Tdd Tad ...                              %20
% %         tauD rD rA...            %23
% %         Eraw Sraw E S numPh Sda_par Sda_perp];               %30

% size(DATA) 

getLk=0; %retrieve a saved Leakage file

if getLk 
        load('LkMat','Lk')
        fprintf('The  leakage %0.3f was loaded ',Lk)    
        
end
% 
S=DATA(:,27);
E=DATA(:,24);
Txd=DATA(:,17);
Txa=DATA(:,18);
Tdd=DATA(:,19);
Tad=DATA(:,20);
% AllRecords=DATA;
Fd=DATA(:,5)+DATA(:,6) ;
Fa=DATA(:,7)+DATA(:,8);
% Faa=AllRecords(:,9)+AllRecords(:,10);

% figure;
% scatter(Fd,Fa)


xf=1.05;
xi=-0.05;
nxBins=20;
dx=(xf-xi)/nxBins;
edges{1}=[xi:dx:xf]; % bin for x axis
[nEraw,cEraw] = hist(E,edges{1});

NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4)))


% 
% hist(Fd+Fa,50)
% figure;
% hist(Faa,50)
% mean(Faa)
% mean(Fd+Fa)
% % filt=S<-6;
% % E(filt)=[];
% % % S(filt)=[];
% % Txd(filt)=[];
% % Txa(filt)=[];
% % filt=S>45;
% % E(filt)=[];
% % S(filt)=[];
% % Txd(filt)=[];
% % Txa(filt)=[];
% filt=E<-0.2 | E>1.2;
% E(filt)=[];
% S(filt)=[];
% Txd(filt)=[];
% Txa(filt)=[];
% % S(S<-6)=[];
% % hist(S,linspace(-6,max(S),100))

% % smoothhist2D([E(:) S(:)],5,[100 100])
% set(hCont,'LineColor','none')
% set(hMain,'XTick',[0 0.5 1])
% set(hMain,'XTickLabel',{'0'; '0.5'; '1'})
% set(hMain,'YTick',[0 0.5 1])
% set(hMain,'YTickLabel',{'0'; '0.5'; '1'})
% 
% set(gcf, 'PaperPositionMode', 'auto');
% 
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% % fontsizeax=12;
%         set(gcf, 'PaperSize', [papersizex papersizey]);
%         set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%             papersizey-2*(marginy)]);
%         set(gcf, 'PaperPositionMode','auto');
%         set(gcf, 'color', 'w');
% 
% print('-dpng','-r600','EandSCarpet2'); %save in same directory as input data
% 
% Efilt=E(S<0.7);
% xf=1.2;
% xi=-0.2;
% nxBins=50;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis
% [nE,cE] = hist(E,edges{1});
% [nEf,cEf] = hist(Efilt,edges{1});
% figure;
% hold all
% bar(cE,nE,1)
% h = findobj(gca,'Type','patch');
% set(h,'FaceColor','r','EdgeColor','w','facealpha',0.5)
% bar(cEf,nEf,1)
% size(h)
% h = findobj(gca,'Type','patch');
% set(h(1),'FaceColor','b','facealpha',0.5);
% size(h)
% ylabel('Frequency')
% xlabel('E')
% legend(h,'ALEX S<0.7','No ALEX ')
% axis tight
% xlim([xi xf])
AllRecords=DATA;

size(DATA)
size(AllRecords)



% Naa=AllRecords(:,9)+AllRecords(:,10) +AllRecords(:,5)+AllRecords(:,6)+ AllRecords(:,7)+AllRecords(:,8);
% Baa=Naa./AllRecords(:,3)
% 
% xf=max(Baa);
% xi=min(Baa);
% nxBins=50;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis
% 
% figure;
% hist(Baa,edges{1});
% axis tight
% xlim([xi xf])


Fd=AllRecords(:,5)+AllRecords(:,6) - (AllRecords(:,11) + AllRecords(:,12)).*AllRecords(:,3);
Fa=AllRecords(:,7)+AllRecords(:,8) - (AllRecords(:,13)+AllRecords(:,14)).*AllRecords(:,3);
bstart=AllRecords(:,1);
tslb=AllRecords(:,4);
Sd=AllRecords(:,5)+AllRecords(:,6) ;
Sa=AllRecords(:,7)+AllRecords(:,8);
tauD=AllRecords(:,21);
rD=AllRecords(:,22);
Faa=AllRecords(:,9)+AllRecords(:,10);
Nph=AllRecords(:,28);
Sda_par=AllRecords(:,29);
Sda_perp=AllRecords(:,30);
Sda=Sda_par+Sda_perp;
tb=AllRecords(:,3);


figure;
hist(tslb)
% % scatter(bstart,tslb,)
% set(gca,'YScale','log')
% set(gca,'XScale','log')
% data={Faa(1:100), Fd(1:100), Fa(1:100)};
% plotSpread(data, ...
%     'xNames', {'Faa', 'Fd', 'Fa'}, ...
%     'distributionMarkers', {'o', '+', '.'});

% filt=Fd+Fa<100
save(FileName(1:end-4),'Fd','Fa','Faa','tb')

% figure;
% hist(tslb*1000,25)
% 
% xf=60;
% xi=0;
% nxBins=6;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis

% ans=min(Fd+Fa+Faa +Sda )
% ans2=min(Nph)
% ans3=mean(Nph-Fd-Fa-Faa-Sda)
% 
% figure;
% scatter(Fd+Fa+Faa+Sda,Nph)
% xlabel('Fd+Fa+Faa')
% ylabel('Nph')
% 
% figure;
% scatter(tb*1000,Nph-Fd-Fa-Faa-Sda)
% xlabel('tb (ms)')
% ylabel('diff')

% figure;
% [hCont,hx ,hy,hMain] =Histogram2d(Fd+Fa,Faa,[0 40],[0 40],15,15,10,'$\rm Fd+Fa$','$\rm Faa$',[],[],[0 10 20 30 40],[0 10 20 30 40],{'0','10','20','30','40'},{'0','10','20','30','40'})
% set(hCont,'LineColor','none')



figure;
hist(Fd+Fa+Faa,[0:5:200])
title('Fd+Fa+Faa')
xlim([0 200])
% set(gca,'XTick',[0:10:100])

figure;
hist((1E-3)*(Fd+Fa+Faa)./tb,[0:5:150])
title('Intenisty')
xlim([0 150])
% set(gca,'XTick',[0:10:100])

minI=(1E-3)*30/500E-6
% figure;
% [hCont,hx ,hy,hMain] =Histogram2d(log(Fd+Fa),log(Faa),[0 max(log(Fd+Fa))],[0 max(log(Faa))],20,20,10,'$\rm Fd+Fa$','$\rm Faa$',[],[],'Burst Counts')

figure;
[hCont,hx ,hy,hMain] =Histogram2d(Fd+Fa,Faa,[0 30],[0 30],15,15,10,'$\rm Fd+Fa$','$\rm Faa$',[],[],[],[],{},{})
set(hCont,'LineColor','none')
title('Fd+Fa vs Faa')
figure;
[hCont,hx ,hy,hMain] =Histogram2d(Fa,Faa,[0 30],[0 30],15,15,10,'$\rm Fa$','$\rm Faa$',[],[],[],[],{},{})
set(hCont,'LineColor','none')
title('Fa vs Faa')

figure;
[hCont,hx ,hy,hMain] =Histogram2d(Fa,Fd,[0 60],[0 60],15,15,10,'$\rm Fa$','$\rm Fd$',[],[],[],[],{},{})
set(hCont,'LineColor','none')
title('Fa vs Fd')

figure;
[hCont,hx ,hy,hMain] =Histogram2d(Fd,Faa,[0 30],[0 30],15,15,10,'$\rm Fd$','$\rm Faa$',[],[],[],[],{},{})
set(hCont,'LineColor','none')
title('Fd vs Faa')

% figure;
% hist(Fd+Fa,25)
% title('Fd+Fa')
% Fd=AllRecords(:,5)+AllRecords(:,6);
% Fa=AllRecords(:,7)+AllRecords(:,8);



% figure;
% hist(Faa,25);
% title('Faa')



tb=AllRecords(:,3);

% filt=(Fd +Fa <15 | tauD<0.1 |Faa<10);
%  filt=(Fd +Fa <5| tauD<0.1 |Faa<5);
%filt=(Fd +Fa <15 |Faa<10);
% filt=(Fd +Fa <15 |Faa<0);
% Fd(filt)=[];
% Fa(filt)=[];
% Faa(filt)=[];
% tb(filt)=[];
% tauD(filt)=[];
% rD(filt)=[];
figure;
hist(rD,15)

% figure;
E=AllRecords(:,24)
S=AllRecords(:,25)
% E=(Fa)./(Fd+Fa);
% S=(Fd+Fa)./(Fd+Fa+Faa);
% hist(S,20);
% title('S')
% 
% 
% figure
% [hCont,hx ,hy,hMain] =Histogram2d(E,Txd-Txa,[],[],30,30,5,'$\rm E$','$\rm Txd-Txa$',[],[],'myALEX')

% figure;
% [hCont,hx ,hy,hMain] =Histogram2d(E(E>0.4),rD(E>0.4),[-0.05 1.05],[-0.5 0.5],15,25,10,'$\rm E$','$\rm r$',[],[],[0 0.25 0.5 0.75 1],[-0.5 -0.25 0 0.25 0.5],{'0','0.25','0.5','0.75','1'},{'-0.5','0-0.25','0','0.25','0.5'});

Ebin=-0.05:0.05:1.05;
figure;
[hCont,hx ,hy,hMain] =Histogram2d(E,Txd-Txa,[-0.05 1.05],[-0.000624 0.000624 ],25,25,15,'$\rm E$','$\rm Txd-Txa$',[],[],[0 0.25 0.5 0.75 1],[],{'0','0.25','0.5','0.75','1'},{});
plot(hCont,Ebin,zeros(size(Ebin)),'r')

figure;
[hCont,hx ,hy,hMain] =Histogram2d(E,Tdd-Tad,[-0.05 1.05],[-0.000624 0.000624 ],25,25,15,'$\rm E$','$\rm Tdd-Txad$',[],[],[0 0.25 0.5 0.75 1],[],{'0','0.25','0.5','0.75','1'},{});
plot(hCont,Ebin,zeros(size(Ebin)),'r')



figure;
[Eraw] = correct_E_gamma_leak_dir(Fd,Fa,[],1,0,0.04,'ABS');
[hCont,hx ,hy,hMain] =Histogram2d(Eraw,S,[-0.05 1.05],[-0.05 1.05],15,15,10,'$\rm E$','$\rm S$',[],[],[0 0.25 0.5 0.75 1],[0 0.25 0.5 0.75 1],{'0','0.25','0.5','0.75','1'},{'0','0.25','0.5','0.75','1'});
% smoothhist2D([E(:) S(:)],5,[100 100])
set(hCont,'LineColor','none')
set(hMain,'XTick',[0 0.5 1])
set(hMain,'XTickLabel',{'0'; '0.5'; '1'})
set(hMain,'YTick',[0 0.5 1])
set(hMain,'YTickLabel',{'0'; '0.5'; '1'})

set(gcf, 'PaperPositionMode', 'auto');

set(gcf,'PaperUnits','inches');
papersizex=6;
papersizey=5;
marginx=0.5;
marginy=0.5;
% fontsizeax=12;
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
           papersizey-2*(marginy)]);
  set(gcf, 'PaperPositionMode','auto');
set(gcf, 'color', 'w');

print('-dpng','-r600','EandSP18FaFdFilt'); %save in same directory as input data

figure;
hist(E,20)
% figure;
% hist(E(S<0.6),20)

figure;
hist(tauD,25)


% xf=300;
% xi=40;
% filt=(Fd + Fa<xi | Fd +Fa >xf);



% Fd(filt)=[];
% Fa(filt)=[];
% Faa(filt)=[];
% tb(filt)=[];
% 
% figure;
% hist(tb,50)
% Fd(Fd<0)=[];
% Fa(Fa<0)=[];
% Faa(Faa<0)=[];

% figure;
% 
% nxBins=20;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis
% hist(Fd+Fa, edges{1})
% xlim([xi xf])

% xf=150;
% xi=1;
% nxBins=50;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis
% 
% figure;
% hold all
% [nFd,cFd] = hist(Fd,edges{1});
% [nFa,cFa] = hist(Fa,edges{1});
% [nFaa,cFaa] = hist(Faa,edges{1});
% stairs(cFd,nFd)
% stairs(cFa,nFa)
% stairs(cFaa,nFaa)
% axis tight
% % xlim([cFd(1) cFd(end)])
%  xlabel('Fx=Sx-Bx ')
% ylabel('Frequency')
% legend('Fd','Fa','Faa')




% figure;
% gamma=1.044;
% Lk=0;
% di=0;
% [Eraw] = correct_E_gamma_leak_dir(Fd,Fa,[],gamma,Lk,di,'ABS');
% % Eraw=(Fa)./(Fd+Fa);
% filt=Eraw<-0.1 | Eraw>1.1;
% size(Eraw)
% Eraw(filt)=[];
% size(Eraw)
% tb(filt)=[];
% Fd(filt)=[];
% Fa(filt)=[];
% size(tb)
% hist(Eraw,50);
%     %from the background corrected donor and accepter counts in each burst
%     %we now seek the ratio Lk=Fa/Fd for donor only sample. 
% 
%     figure;
% [hCont,hx ,hy,hMain] =Histogram2d(Eraw,tb*1E3,[-0.1 1.1],[0.45 1.4],50,50,15,'$\rm E$','$\rm tb$',[],[],'EvTb')
%     
%     g=1.05;
%     Q=1.1;
%     gamma=1;
% %     di=(A532/D532)*(Aeps/Deps);
%     di=0.0;
%     
%     figure;
%     scatter(Eraw,tb*1E3)
%     axis tight
%     
%     
%      figure;
% [hCont,hx ,hy,hMain] =Histogram2d(Eraw,Fd+Fa,[-0.1 1.1],[xi 125],50,50,15,'$\rm E$','$\rm size$',[],[],'EvSize')
%     
%     g=1.05;
%     Q=1.1;
%     gamma=1;
% %     di=(A532/D532)*(Aeps/Deps);
%     di=0.0;
%     
%     figure;
%     scatter(Eraw,Fd+Fa)
%     xlabel('E')
%     ylabel('Fluorescence Counts in Burst')
%     axis tight
%     
% 
% % [Efull] = correct_E_gamma_leak_dir(Fd,Fa,[],gamma,Lk,di,'ABS');
% % 
% %     
% % % Efull=DATA(:,24);
% Efull=E;
% Efull=Efull(:);
% B=1000;
% BootE=repmat(Efull,B,1);
% size(BootE)
% 


% Eraw=(Sa)./(Sd+Sa);
% [nEraw,cEraw] = hist(Eraw,edges{1});
% NiceEHist(cEraw,nEraw,'500uWDNACy5Al488-2mMCys-nobkgcor','500uWDNACy5Al488-2mMCys-nbkgcor')

% figure;
% hold all;
% bar(cEraw,nEraw,'BarWidth',0.75,'FaceColor', [160 160 160]/256);
%         xlabel('E')
%         ylabel('Frequency')
%         xlim([xi xf])
%         ylim([0 1.2*max(nEraw)])
%         
% Ec0=[0.4];
% fixE=[0];
% nPh=20;
% numMC=5
% 
% for i=1:numMC
% r=randi([1, length(BootE)],length(Efull),1);
% Esample=BootE(r);
% [nErawMAT(:,i),cEraw] = hist(Esample,edges{1});
% end
% stdE=std(nErawMAT,1,2);
% % stdE=[]
% [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=FitGaussMix(nEraw,cEraw,stdE,Ec0,fixE,nPh);
% 
% for i=1:numMC
%     r=randi([1, length(BootE)],length(Efull),1);
% Esample=BootE(r);
% [snEraw,cEraw] = hist(Esample,edges{1});
% [smodelParam(:,i),~,~,~,~,~,~]=FitGaussMix(snEraw,cEraw,stdE,Ec0,fixE,nPh);
% 
% end
% 
% dmodelParam=std(smodelParam,1,2)
% 
%         fEc=modelParam(1:length(Ec0));
%         fw=modelParam(length(Ec0)+1:2*length(Ec0));
%         fA=modelParam(2*length(Ec0)+1:end);
%         
%         dfEc=dmodelParam(1:length(Ec0));
%         dfw=dmodelParam(length(Ec0)+1:2*length(Ec0));
%         dfA=dmodelParam(2*length(Ec0)+1:end);
%         
% dof = length(residual)-3*length(Ec0);
% redchi=resnorm/dof;
%         fprintf('The reduced Chi^2 is %0.3f \r\n',redchi)
%         
%         for i=1:length(Ec0)
%         fprintf('The fitted mean %d: %.3f +/- %.3f \r\n',i,fEc(i),dfEc(i))
%         fprintf('The fitted width %d: %.3f +/- %.3f \r\n',i,fw(i),dfw(i))
%         fprintf('The fitted area %d: %.3f +/- %.3f \r\n',i,fA(i),dfA(i))
%         end
% 
%         
% FitGaussMixResult(nEraw,cEraw,length(Ec0),modelParam,residual)


end

