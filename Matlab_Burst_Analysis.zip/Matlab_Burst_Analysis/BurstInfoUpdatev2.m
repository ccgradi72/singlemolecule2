function [] = BurstInfoUpdatev2()
%UNTITLED Reads information from AllRecords and Displays Burst Info
%   Detailed explanation goes here

global ALEX FRET pol lifetime global_gamma global_lk global_dir Gdd Gaa k1 k2 customEval fid_burst_txt

AllRecords=textscan(fid_burst_txt,repmat('%f',1,27));

    fprintf('--------------------------------------------------------\r\n')
    fprintf('--------------------------------------------------------\r\n')
    fprintf('------------Burst Info Update---------------------------\r\n')
    fprintf('--------------------------------------------------------\r\n')
    fprintf('--------------------------------------------------------\r\n')
    fprintf('Number of bursts detected and analyzed: %f \r\n',length(AllRecords{1}))
    fprintf('Mean time between bursts (s): %f +/- %f \r\n', mean(AllRecords{4}),std(AllRecords{4}))
    fprintf('Mean burst duration (ms): %f +/- %f \r\n', mean(AllRecords{3})*1000, std(AllRecords{3})*1000)
    fprintf('Mean Ph D-channel D-exc: %f +/- %f \r\n',mean(AllRecords{5}+AllRecords{6}),std(AllRecords{5}+AllRecords{6}))
    fprintf('Mean Ph A-channel D-exc: %f +/- %f \r\n',mean(AllRecords{7}+AllRecords{8}),std(AllRecords{7}+AllRecords{8}))
    if ALEX; fprintf('Mean Ph A-channel A-exc: %f +/- %f \r\n',mean(AllRecords{9}+AllRecords{10}),std(AllRecords{9}+AllRecords{10})); end
    if FRET;  fprintf('Mean Eraw: %f +/- %f \r\n', mean(AllRecords{24}),std(AllRecords{24})); end
    if ALEX;  fprintf('Mean Sraw: %f  +/- %f\r\n', mean(AllRecords{25}),std(AllRecords{25})); end
    if lifetime;  fprintf('Mean TauD: %f +/- %f \r\n', mean(AllRecords{21}), std(AllRecords{21})); end
    if pol
        fprintf('Mean rD: %f +/- %f \r\n', mean(AllRecords{22}),std(AllRecords{22}))
        if ALEX
            fprintf('Mean rA: %f +/- %f \r\n', mean(AllRecords{23}),std(AllRecords{23}))
        end
    end
    fprintf('--------------------------------------------------------\r\n')
    fprintf('--------------------------------------------------------\r\n')
    fprintf('------------Correction Factors--------------------------\r\n')
    fprintf('--------------------------------------------------------\r\n')
    fprintf('--------------------------------------------------------\r\n')
    if FRET
        fprintf('Current FRET Correction Factors: gamma= %f, lk=%f, dir =%f \r\n',global_gamma,global_lk,global_dir)
    end
    if pol
        fprintf('Current Anisotropy Correction Factors: Gdd= %f, Gaa=%f, k1 =%f, k2=%f',Gdd,Gaa,k1,k2)
    end
    if ~isempty(customEval)
        fprintf('--------------------------------------------------------\r\n')
        fprintf('--------------------------------------------------------\r\n')
        fprintf('------------Custom Functions----------------------------\r\n')
        fprintf('--------------------------------------------------------\r\n')
        fprintf('--------------------------------------------------------\r\n')
        for i=1:size(customEval,1)
        eval(customEval{i})
        end
        
    end



end

