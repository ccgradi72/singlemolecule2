function [ output_args ] = CombineNB( input_args )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
clc;
close all;
clear all;

eta0=70;
Isat0=30;
modelParam0=[eta0 Isat0]
ub=[Inf Inf];
lb=[0 0];

%Solver properties
maxiter=5000;
maxfunevals=5000;
tolfun=1e-8;
tolx=1e-8;
lsqOpt=[maxiter maxfunevals tolfun tolx];
        
        %Set options for solver
%lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');


ms=8;
fs=10;

I=[0 25 50 100 200]; %kW/cm^2
EPS0=[0 27.07 50.95 59.8 60.07];
EPS1=[0 47.16 74.36 122.38 105.33];
EPS25=[0 35 57.186 104.24 142.09];
EPS5=[0 44.13 67.491 109.007 63.66];

Iv2=[0 25 50 75 100 150 200 250 300 350];
EPSv2=[0 75.49 107.04 119.11 128.06 136.64 141.48 141.81 141.97 140.61];
% Ibkg=[25 50 100 200 300];
Bkgv2=[0.1 0.2518 0.55 0.855 1.16 1.755 2.35 2.795 3.24 3.685];

% Bkgv2=interp1(Ibkg,Bkgv2,Iv2,'linear','extrap')
% 

BKG0=[0.1 0.64 1.05 1.82 3.281];
BKG1=[0.1 0.28 1.075 2.15 5.12];

IData=I;
EPSData=EPS0;
[param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
Ifit=linspace(0, max(IData),100);
[mymodel]=MakeModel(param,Ifit);

figure;
hold all
h=plot(I, EPS0,'o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
IData=I;
EPSData=EPS0;
[param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
fprintf('0 mM Max Brightness %f \r\n Isat %f',param(1)/2,param(2))
Ifit=linspace(0, max(IData),100);
[mymodel]=MakeModel(param,Ifit);
h2=plot(Ifit,mymodel,'-');
set(h2,'Color', get(h, 'MarkerFaceColor'));

h=plot(I, EPS1,'o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
IData=I(1:end-1);
EPSData=EPS1(1:end-1);
[param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
fprintf('1 mM Max Brightness %f \r\n Isat %f',param(1)/2,param(2))
Ifit=linspace(0, max(IData),100);
[mymodel]=MakeModel(param,Ifit);
h2=plot(Ifit,mymodel,'-');
set(h2,'Color', get(h, 'MarkerFaceColor'));

h=plot(I, EPS25,'o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
IData=I;
EPSData=EPS25;
[param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
fprintf('2.5 mM Max Brightness %f \r\n Isat %f',param(1)/2,param(2))
Ifit=linspace(0, max(IData),100);
[mymodel]=MakeModel(param,Ifit);
h2=plot(Ifit,mymodel,'-');
set(h2,'Color', get(h, 'MarkerFaceColor'));

h=plot(I, EPS5,'o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
IData=I(1:end-1);
EPSData=EPS5(1:end-1);
[param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
fprintf('5 mM Max Brightness %f \r\n Isat %f',param(1)/2,param(2))
Ifit=linspace(0, max(IData),100);
[mymodel]=MakeModel(param,Ifit);
h2=plot(Ifit,mymodel,'-');
set(h2,'Color', get(h, 'MarkerFaceColor'));

h=plot(Iv2,EPSv2,'o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
IData=Iv2;
EPSData=EPSv2;
[param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
fprintf('2 mm Max Brightness %f \r\n Isat %f',param(1)/2,param(2))
Ifit=linspace(0, max(IData),100);
[mymodel]=MakeModel(param,Ifit);
h2=plot(Ifit,mymodel,'-');
set(h2,'Color', get(h, 'MarkerFaceColor'));

hl=legend('0 mM Cyst.','0 mM Cyst. fit','1 mM Cyst.','1 mM Cyst. fit','2.5 mM Cyst.','2.5 mM Cyst. fit','5 mM Cyst.','5 mM Cyst. fit','2 mM Cyst.','2 mM Cyst. fit');
set(hl,'FontSize',fs)
xlabel('Approx intensity at sample (kW/cm^2)(= I_{measured}=I*dutycyle)')
ylabel('Molecular Brightness kCPS/mol')
box on


figure;
hold all
h=plot(I,EPS0./BKG0,'-o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
h=plot(I,EPS1./BKG1,'-o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
h=plot(I,EPS25./BKG1,'-o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
h=plot(I,EPS5./BKG1,'-o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
h=plot(Iv2,EPSv2./Bkgv2,'-o')
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
hl=legend('0 mM Cyst.','1 mM Cyst.','2.5 mM Cyst.','5 mM Cyst.','2 mM Cyst.');
xlabel('Approx intensity at sample (kW/cm^2) (= I_{measured}=I*dutycyle)')
ylabel('SNR')
set(hl,'FontSize',fs)
% set(gca,'YScale','log')
box on
% ylim([0 200])

figure;
hold all
h=plot(I,BKG0,'-o');
set(h, 'MarkerFaceColor', get(h, 'Color'));
h=plot(I,BKG1,'-o');
set(h, 'MarkerFaceColor', get(h, 'Color'));
h=plot(Iv2,Bkgv2,'-o');
set(h, 'MarkerFaceColor', get(h, 'Color'));


%To do
%Plot I vs N, keeping in mind different cysteamine concentration are
%different Sic1 dilutions

%Try differnt bin size (maybe 50 us and 10 us) to see if brightness changes)

function [err]=objfcn(param)
        
        eta=param(1);
        Isat=param(2);
        
        model=eta*(IData/Isat)./(1+IData/Isat);
        
        err=model-EPSData;
        
    end

    function [model]=MakeModel(param,I)
        
        eta=param(1);
        Isat=param(2);
        
        model=eta*(I/Isat)./(1+I/Isat);
        
        
    end

end

