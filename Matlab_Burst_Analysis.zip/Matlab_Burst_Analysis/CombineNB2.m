function [ output_args ] = CombineNB( input_args )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
clc;
close all;
clear all;

ms=8;
fs=12;

I=[0 45 90 180 355 880 1790 3600]; %uW
I=I*0.06;
EPS0=[0 22.2 37.29 64.378 98.77 144.71 170.98 185.00];
BKG=[0.059 0.128 0.197 0.3226 0.6183 1.94 3.7561 7.3512];
% BKG2=interp1(I,BKG,[0 I],'linear','extrap')

I2A=[0 41 78 160 318 791 1600 3200];
I2A=I2A*0.06;
EPS2A=[0 21.3 36.5 63.6 101.2 159.2 206.23 247.7]
BKG2A=[0.5049 0.548 0.6494 0.851 1.185 2.34 4.04 7.48] 

X=[ones(length(BKG),1) I'];
b=X\(BKG');
BKG2=X*b;

% figure;
% hold all
% plot(I2A,BKG2)
% plot(I2A,BKG2A,'o')

figure;
hold all
h=plot(I, EPS0,'-o')
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
h=plot(I2A, EPS2A,'-o')
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
% % h=plot(I, EPS25,'-o')
% % set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
% % h=plot(I, EPS5,'-o')
% % set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
% % h=plot(Iv2,EPSv2,'-o')
% % set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
hl=legend('0 mM Cysteamine','2 mM Cysteamine + ALEX')
set(hl,'FontSize',fs)
xlabel('Approx intensity at sample (kW/cm^2)(= I_{measured}=I*dutycyle)')
ylabel('Molecular Brightness kCPS/mol')
box on


figure;
hold all
h=plot(I,EPS0./BKG,'-o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
h=plot(I2A,EPS2A./BKG2A,'-o');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
% h=plot(I,EPS25./BKG1,'-o');
% set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
% h=plot(I,EPS5./BKG1,'-o');
% set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
% h=plot(Iv2,EPSv2./Bkgv2,'-o')
% set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
hl=legend('0 mM Cysteamine','2 mM Cysteamine + ALEX')
xlabel('Approx intensity at sample (kW/cm^2) (= I_{measured}=I*dutycyle)')
ylabel('SNR')
set(hl,'FontSize',fs)
% set(gca,'YScale','log')
box on
% ylim([0 200])

figure;
hold all
h=plot(I,BKG,'-o')
set(h, 'MarkerFaceColor', get(h, 'Color'));
% h=plot(I,BKG1,'-o')
% set(h, 'MarkerFaceColor', get(h, 'Color'));
% h=plot(Iv2,Bkgv2,'-o')
% set(h, 'MarkerFaceColor', get(h, 'Color'));


%To do
%Plot I vs N, keeping in mind different cysteamine concentration are
%different Sic1 dilutions

%Try differnt bin size (maybe 50 us and 10 us) to see if brightness changes)

eta0=180;
Isat0=30;
modelParam0=[eta0 Isat0]
ub=[Inf Inf];
lb=[0 0];

%Solver properties
maxiter=5000;
maxfunevals=5000;
tolfun=1e-8;
tolx=1e-8;
lsqOpt=[maxiter maxfunevals tolfun tolx];
        
        %Set options for solver
%lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');

%the "heart" of the solver

if ~isempty(ub)||~isempty(lb)
    %if there are any upper or lower bounds, use them
    [param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
else
    %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
    [param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,[],[],options);
end

fprintf('Max Brightness 0 mM Cysteamine %f \r\n Isat %f',param(1)/2,param(2))
I2=linspace(0, max(I),100);
[mymodel]=MakeModel(param,I2);

figure;
hold all
h=plot(I, EPS0,'o')
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
h2=plot(I2,mymodel,'-')
set(h2,'Color', get(h, 'MarkerFaceColor'));
h=plot(I2A, EPS2A,'o')
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
I=I2A;
EPS0=EPS2A;
[param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,[],[],options);
fprintf('Max Brightness 2 mM + ALEX %f \r\n Isat %f',param(1)/2,param(2))
I2=linspace(0, max(I),100);
[mymodel]=MakeModel(param,I2);
h2=plot(I2,mymodel,'-')
set(h2,'Color', get(h, 'MarkerFaceColor'));
ylabel('Molecular Brightness kCPS/mol')
hl=legend('0 mM Cysteamine','0 mM Cysteamine fit', '2 mM Cysteamine +ALEX','2 mM Cysteamine +ALEX fit')
set(hl,'FontSize',fs)
xlabel('Approx intensity at sample (kW/cm^2) (= I_{measured}=I*dutycyle)')
box on

% X=[ones(length(I2),1) I2'];
% BKGfit=X*b;
% figure;
% hold all
% plot(I2,BKGfit)
% plot(I,BKG,'o')
% 
% SNRfit=mymodel./BKGfit';
% figure;
% hold all
% h=plot(I,EPS0./BKG,'o');
% set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
% plot(I2,SNRfit,'-k');
% ylabel('SNR')
% box on




    function [err]=objfcn(param)
        
        eta=param(1);
        Isat=param(2);
        
        model=eta*(I/Isat)./(1+I/Isat);
        
        err=model-EPS0;
        
    end

    function [model]=MakeModel(param,I)
        
        eta=param(1);
        Isat=param(2);
        
        model=eta*(I/Isat)./(1+I/Isat);
        
        
    end



end

