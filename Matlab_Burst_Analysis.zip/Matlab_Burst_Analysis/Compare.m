
clear all;
close all;
clc;


load('250uWDNACy5Al488_10mMCyst')
Fd1=Fd;
Fa1=Fa;
Faa1=Faa;
tb1=tb;
load('500 uW DNA Al488 Cy5 10mM Cys')
Fd2=Fd;
Fa2=Fa;
Faa2=Faa;
tb2=tb;
load('1000 uW DNA Al488  Cy5 10mM Cys')
Fd3=Fd;
Fa3=Fa;
Faa3=Faa;
tb3=tb;
% % load('June30_Sic11c90c_Al488Al647_PhPr')
% Fd3=0;
% Fa3=0;
% Faa3=0;
% tb3=0;


%% Burst durations

% tb1A=tb1(Faa1>30);
% tb2A=tb2(Faa2>30);
% tb3A=tb3(Faa3>30);
% 
% tb1D=tb1(Fd1>30);
% tb2D=tb2(Fd2>30);
% tb3D=tb3(Fd3>30);

%% Total 
figure;
[n,c]=hist(tb1/1E-3,[0.5:.2:3]);
plot(c,n/sum(n),'-ob')
hold on;
[n,c]=hist(tb2/1E-3,[0.5:.2:3]);
plot(c,n/sum(n),'-sr')
[n,c]=hist(tb3/1E-3,[0.5:.2:3]);
plot(c,n/sum(n),'-*g')
set(gca,'YScale','log')
legend('250 uW','500 uW','1000 uW')
title('Burst duration')
axis tight
xlim([0.5 3])
xlabel('Burst duration ms')
ylabel('Frequency')
set(gcf,'PaperUnits','inches');
papersizex=6;
papersizey=5;
marginx=0.5;
marginy=0.5;
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
           papersizey-2*(marginy)]);
  set(gcf, 'PaperPositionMode','auto');
set(gcf, 'color', 'w');
print('-dpng','-r150','BurstDuration'); %save in same directory as input data

% %% Aonly 
% figure;
% [n,c]=hist(tb1A/1E-3,[0.5:.2:3]);
% plot(c,n/sum(n),'-ob')
% hold on;
% [n,c]=hist(tb2A/1E-3,[0.5:.2:3]);
% plot(c,n/sum(n),'-sr')
% % [n,c]=hist(tb3A/1E-3,[0.5:.2:3]);
% % plot(c,n/sum(n),'-*g')
% set(gca,'YScale','log')
% legend('PBS 0.5 mW','PBS 1 mW ','Photoprotected 1 mW')
% title('Burst duration Acceptor only bursts')
% axis tight
% xlim([0.5 3])
% xlabel('Burst duration ms')
% ylabel('Frequency')
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','BurstDurationAonly'); %save in same directory as input data
% 
% %% Donly 
% figure;
% [n,c]=hist(tb1D/1E-3,[0.5:.2:3]);
% plot(c,n/sum(n),'-ob')
% hold on;
% [n,c]=hist(tb2D/1E-3,[0.5:.2:3]);
% plot(c,n/sum(n),'-sr')
% % [n,c]=hist(tb3D/1E-3,[0.5:.2:3]);
% % plot(c,n/sum(n),'-*g')
% set(gca,'YScale','log')
% legend('PBS 0.5 mW','PBS 1 mW ','Photoprotected 1 mW')
% title('Burst duration Donor only bursts')
% axis tight
% xlim([0.5 3])
% xlabel('Burst duration ms')
% ylabel('Frequency')
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','BurstDurationDonly'); %save in same directory as input data



%% Total 
figure;
[n,c]=hist(Fd1+Fa1+Faa1,[0:5:200]);
plot(c,n/sum(n),'-ob')
hold on;
[n,c]=hist(Fd2+Fa2+Faa2,[0:5:200]);
plot(c,n/sum(n),'-sr')
[n,c]=hist(Fd3+Fa3+Faa3,[0:5:200]);
plot(c,n/sum(n),'-*g')
set(gca,'YScale','log')
legend('250 uW','500 uW','1000 uW')
title('Total number photons in burst')
axis tight
xlim([15 180])
xlabel('Total Number of Photons in Burst')
ylabel('Frequency')
set(gcf,'PaperUnits','inches');
papersizex=6;
papersizey=5;
marginx=0.5;
marginy=0.5;
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
           papersizey-2*(marginy)]);
  set(gcf, 'PaperPositionMode','auto');
set(gcf, 'color', 'w');
print('-dpng','-r150','BurstSize'); %save in same directory as input data


figure
[n,c]=hist((1E-3)*(Fd1+Fa1+Faa1)./tb1,[0:5:200]);
% bh=bar(c,n/sum(n),'b');
plot(c,n/sum(n),'-ob')
hold on;
[n,c]=hist((1E-3)*(Fd2+Fa2+Faa2)./tb2,[0:5:200]);
% bh2=bar(c,n/sum(n),'r');
plot(c,n/sum(n),'-sr')
% alpha(get(bh,'children'),.25);
[n,c]=hist((1E-3)*(Fd3+Fa3+Faa3)./tb3,[0:5:200]);
plot(c,n/sum(n),'-*g')
% bh3=bar(c,n/sum(n),'g');
% alpha(get(bh2,'children'),.25);
% alpha(get(bh3,'children'),.25);
% colormap(hot(4));
set(gca,'YScale','log')
legend('250 uW','500 uW','1000 uW')
title('Total intensity')
axis tight
xlabel('Intensity of Burst (KCPS)')
ylabel('Frequency')
set(gcf,'PaperUnits','inches');
papersizex=6;
papersizey=5;
marginx=0.5;
marginy=0.5;
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
           papersizey-2*(marginy)]);
  set(gcf, 'PaperPositionMode','auto');
set(gcf, 'color', 'w');
print('-dpng','-r150','BurstIntensity'); %save in same directory as input data
% xlim([15 180])


% % figure;
% % hist(Faa2)
% Nt1=Fd1+Fa1+Faa1;
% Nt2=Fd2+Fa2+Faa2;
% % Nt3=Fd3+Fa3 +Faa3;
% 
% Nth=[30 60 90 120];
% for i=1:length(Nth)
% A1(i)=length(Nt1(Nt1>Nth(i)))/length(Nt1)
% A2(i)=length(Nt2(Nt2>Nth(i)))/length(Nt2)
% % A3(i)=length(Nt3(Nt3>Nth(i)))/length(Nt3)
% end
% 
% figure;
% hold all;
% plot(Nth,A1,'-ob')
% plot(Nth,A2,'-sr')
% % plot(Nth,A3,'-*g')
% legend('PBS 0.5 mW','PBS 1 mW ','Photoprotected 1 mW')
% ylabel('Fraction of bursts with higher than Nth photons')
% title('Total Burst fractions')
% xlabel('Nth')
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','BurstFraction'); %save in same directory as input data
% 
% 
% %% Donor only
% figure;
% [n,c]=hist(Fd1,[0:5:200]);
% plot(c,n/sum(n),'-ob')
% hold on;
% [n,c]=hist(Fd2,[0:5:200]);
% plot(c,n/sum(n),'-sr')
% % [n,c]=hist(Fd3,[0:5:200]);
% % plot(c,n/sum(n),'-*g')
% set(gca,'YScale','log')
% legend('PBS 0.5 mW','PBS 1 mW ','Photoprotected 1 mW')
% title('Donor photons in burst')
% axis tight
% xlim([15 180])
% xlabel('Number of Photons in Burst')
% ylabel('Frequency')
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','BurstSizeDonor'); %save in same directory as input data
% 
% 
% figure
% [n,c]=hist((1E-3)*(Fd1)./tb1,[0:5:200]);
% % bh=bar(c,n/sum(n),'b');
% plot(c,n/sum(n),'-ob')
% hold on;
% [n,c]=hist((1E-3)*(Fd2)./tb2,[0:5:200]);
% % bh2=bar(c,n/sum(n),'r');
% plot(c,n/sum(n),'-sr')
% % alpha(get(bh,'children'),.25);
% [n,c]=hist((1E-3)*(Fd3)./tb3,[0:5:200]);
% plot(c,n/sum(n),'-*g')
% % bh3=bar(c,n/sum(n),'g');
% % alpha(get(bh2,'children'),.25);
% % alpha(get(bh3,'children'),.25);
% % colormap(hot(4));
% set(gca,'YScale','log')
% legend('PBS 0.5 mW','PBS 1 mW ','Photoprotected 1 mW')
% title('Donor intensity')
% axis tight
% xlabel('Intensity of Burst (KCPS)')
% ylabel('Frequency')
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','DonorBurstIntensity'); %save in same directory as input data
% % xlim([15 180])
% 
% 
% % figure;
% % hist(Faa2)
% Nt1=Fd1;
% Nt2=Fd2;
% Nt3=Fd3;
% 
% Nth=[30 60 90 120];
% for i=1:length(Nth)
% A1(i)=length(Nt1(Nt1>Nth(i)))/length(Nt1)
% A2(i)=length(Nt2(Nt2>Nth(i)))/length(Nt2)
% A3(i)=length(Nt3(Nt3>Nth(i)))/length(Nt3)
% end
% 
% figure;
% hold all;
% plot(Nth,A1,'-ob')
% plot(Nth,A2,'-sr')
% plot(Nth,A3,'-*g')
% legend('PBS 0.5 mW','PBS 1 mW ','Photoprotected 1 mW')
% ylabel('Fraction of bursts with higher than Nth photons')
% title('Donor Burst fractions')
% xlabel('Nth')
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','DonorBurstFraction'); %save in same directory as input data
% 
% 
% 
% %% Acceptor
% figure;
% [n,c]=hist(Faa1,[0:5:200]);
% plot(c,n/sum(n),'-ob')
% hold on;
% [n,c]=hist(Faa2,[0:5:200]);
% plot(c,n/sum(n),'-sr')
% [n,c]=hist(Faa3,[0:5:200]);
% plot(c,n/sum(n),'-*g')
% set(gca,'YScale','log')
% legend('PBS 0.5 mW','PBS 1 mW ','Photoprotected 1 mW')
% title('Acceptor number photons in burst')
% axis tight
% xlim([15 180])
% xlabel('Number of Photons in Burst')
% ylabel('Frequency')
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','AcceptorBurstSize'); %save in same directory as input data
% 
% 
% figure
% [n,c]=hist((1E-3)*(Faa1)./tb1,[0:5:200]);
% % bh=bar(c,n/sum(n),'b');
% plot(c,n/sum(n),'-ob')
% hold on;
% [n,c]=hist((1E-3)*(Faa2)./tb2,[0:5:200]);
% % bh2=bar(c,n/sum(n),'r');
% plot(c,n/sum(n),'-sr')
% % alpha(get(bh,'children'),.25);
% [n,c]=hist((1E-3)*(Faa3)./tb3,[0:5:200]);
% plot(c,n/sum(n),'-*g')
% % bh3=bar(c,n/sum(n),'g');
% % alpha(get(bh2,'children'),.25);
% % alpha(get(bh3,'children'),.25);
% % colormap(hot(4));
% set(gca,'YScale','log')
% legend('PBS 0.5 mW','PBS 1 mW ','Photoprotected 1 mW')
% title('Acceptor burst intensity')
% axis tight
% xlabel('Intensity of Burst (KCPS)')
% ylabel('Frequency')
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','AcceptorBurstIntensity'); %save in same directory as input data
% % xlim([15 180])
% 
% 
% % figure;
% % hist(Faa2)
% Nt1=Faa1;
% Nt2=Faa2;
% Nt3=Faa3;
% 
% Nth=[30 60 90 120];
% for i=1:length(Nth)
% A1(i)=length(Nt1(Nt1>Nth(i)))/length(Nt1)
% A2(i)=length(Nt2(Nt2>Nth(i)))/length(Nt2)
% A3(i)=length(Nt3(Nt3>Nth(i)))/length(Nt3)
% end
% 
% figure;
% hold all;
% plot(Nth,A1,'-ob')
% plot(Nth,A2,'-sr')
% plot(Nth,A3,'-*g')
% legend('PBS 0.5 mW','PBS 1 mW ','Photoprotected 1 mW')
% ylabel('Fraction of bursts with higher than Nth photons')
% title('Acceptor Burst fractions')
% xlabel('Nth')
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','AcceptorBurstFraction'); %save in same directory as input data
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% %%
% 
% E2=Fa2./(Fa2+Fd2);
% S2=(Fd2+Fa2)./(Fd2+Fa2 +Faa2);
% filt=S2<0.75;
% % filt=(Fd2+Fa2 >30) & (Faa2>20);
% E2filt=E2(filt);
% S2filt=S2(filt);
% 
% E1=Fa1./(Fa1+Fd1);
% S1=(Fd1+Fa1)./(Fd1+Fa1 +Faa1);
% filt=S1<0.75;
% % filt=(Fd1+Fa1 >30) & (Faa1>20);
% E1filt=E1(filt);
% S1filt=S1(filt);
% 
% E3=Fa3./(Fa3+Fd3);
% S3=(Fd3+Fa3)./(Fd3+Fa3 +Faa3);
% filt=S3<0.75;
% % filt=(Fd3+Fa3 >30) & (Faa3>20);
% E3filt=E3(filt);
% S3filt=S3(filt);
% 
% figure;
% [hCont,hx ,hy,hMain] =Histogram2d(E1,S1,[-0.05 1.05],[-0.05 1.05],15,15,10,'$\rm E$','$\rm S$',[],[],[0 0.25 0.5 0.75 1],[0 0.25 0.5 0.75 1],{'0','0.25','0.5','0.75','1'},{'0','0.25','0.5','0.75','1'});
% set(hCont,'LineColor','none')
% set(gcf, 'PaperPositionMode', 'auto');
% set(gcf,'PaperUnits','inches');
% title(hx,'PBS')
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','E1S1'); %save in same directory as input data
% 
% figure;
% [hCont,hx ,hy,hMain] =Histogram2d(E2,S2,[-0.05 1.05],[-0.05 1.05],15,15,10,'$\rm E$','$\rm S$',[],[],[0 0.25 0.5 0.75 1],[0 0.25 0.5 0.75 1],{'0','0.25','0.5','0.75','1'},{'0','0.25','0.5','0.75','1'});
% set(hCont,'LineColor','none')
% set(gcf, 'PaperPositionMode', 'auto');
% set(gcf,'PaperUnits','inches');
% title(hx,'PhotoProtection')
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','E2S2'); %save in same directory as input data
% 
% figure;
% [hCont,hx ,hy,hMain] =Histogram2d(E3,S3,[-0.05 1.05],[-0.05 1.05],15,15,10,'$\rm E$','$\rm S$',[],[],[0 0.25 0.5 0.75 1],[0 0.25 0.5 0.75 1],{'0','0.25','0.5','0.75','1'},{'0','0.25','0.5','0.75','1'});
% set(hCont,'LineColor','none')
% set(gcf, 'PaperPositionMode', 'auto');
% set(gcf,'PaperUnits','inches');
% title(hx,'PhotoProtection Higher Intensity')
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','E3S3'); %save in same directory as input data
% 
% %%
% figure;
% [hCont,hx ,hy,hMain] =Histogram2d(E1filt,S1filt,[-0.05 1.05],[-0.05 1.05],15,15,10,'$\rm E$','$\rm S$',[],[],[0 0.25 0.5 0.75 1],[0 0.25 0.5 0.75 1],{'0','0.25','0.5','0.75','1'},{'0','0.25','0.5','0.75','1'});
% set(hCont,'LineColor','none')
% set(gcf, 'PaperPositionMode', 'auto');
% set(gcf,'PaperUnits','inches');
% title(hx,'PBS Filtered')
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','E1S1filt'); %save in same directory as input data
% 
% figure;
% [hCont,hx ,hy,hMain] =Histogram2d(E2filt,S2filt,[-0.05 1.05],[-0.05 1.05],15,15,10,'$\rm E$','$\rm S$',[],[],[0 0.25 0.5 0.75 1],[0 0.25 0.5 0.75 1],{'0','0.25','0.5','0.75','1'},{'0','0.25','0.5','0.75','1'});
% set(hCont,'LineColor','none')
% set(gcf, 'PaperPositionMode', 'auto');
% set(gcf,'PaperUnits','inches');
% title(hx,'PhotoProtection Filtered')
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','E2S2filt'); %save in same directory as input data
% 
% figure;
% [hCont,hx ,hy,hMain] =Histogram2d(E3filt,S3filt,[-0.05 1.05],[-0.05 1.05],15,15,10,'$\rm E$','$\rm S$',[],[],[0 0.25 0.5 0.75 1],[0 0.25 0.5 0.75 1],{'0','0.25','0.5','0.75','1'},{'0','0.25','0.5','0.75','1'});
% set(hCont,'LineColor','none')
% set(gcf, 'PaperPositionMode', 'auto');
% set(gcf,'PaperUnits','inches');
% title(hx,'PhotoProtection Higher Intensity Filtered')
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','E3S3filt'); %save in same directory as input data
% 
% %%
% figure;
% scatter(Fd1+Fa1,Faa1)
% title('PBS')
% xlabel('Fd +Fa')
% ylabel('Faa')
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','FdFaFaa1'); %save in same directory as input data
% 
% figure;
% scatter(Fd2+Fa2,Faa2)
% title('Photoprotection')
% xlabel('Fd +Fa')
% ylabel('Faa')
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','FdFaFaa2'); %save in same directory as input data
% figure;
% scatter(Fd3+Fa3,Faa3)
% title('Photoprotection High Intensity')
% xlabel('Fd +Fa')
% ylabel('Faa')
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','FdFaFaa3'); %save in same directory as input data
% 
% % figure;
% % [hCont,hx ,hy,hMain] =Histogram2d(Fd1+Fa1,Faa1,[0 60],[0 60],15,15,10,'$\rm Fd+Fa$','$\rm Faa$',[],[],[0 10 20 30 40 50 60],[0 10 20 30 40 50 60],{'0','10','20','30','40','50','60'},{'0','10','20','30','40','50','60'})
% % set(hCont,'LineColor','none')
% % set(gcf, 'PaperPositionMode', 'auto');
% % set(gcf,'PaperUnits','inches');
% % title(hx,'PBS')
% % papersizex=6;
% % papersizey=5;
% % marginx=0.5;
% % marginy=0.5;
% % set(gcf, 'PaperSize', [papersizex papersizey]);
% % set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
% %            papersizey-2*(marginy)]);
% %   set(gcf, 'PaperPositionMode','auto');
% % set(gcf, 'color', 'w');
% % print('-dpng','-r150','FdFaFaa1'); %save in same directory as input data
% % 
% % figure;
% % [hCont,hx ,hy,hMain] =Histogram2d(Fd2+Fa2,Faa2,[0 60],[0 60],15,15,10,'$\rm Fd+Fa$','$\rm Faa$',[],[],[0 10 20 30 40 50 60],[0 10 20 30 40 50 60],{'0','10','20','30','40','50','60'},{'0','10','20','30','40','50','60'})
% % set(hCont,'LineColor','none')
% % set(gcf, 'PaperPositionMode', 'auto');
% % set(gcf,'PaperUnits','inches');
% % title(hx,'Photoprotection')
% % papersizex=6;
% % papersizey=5;
% % marginx=0.5;
% % marginy=0.5;
% % set(gcf, 'PaperSize', [papersizex papersizey]);
% % set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
% %            papersizey-2*(marginy)]);
% %   set(gcf, 'PaperPositionMode','auto');
% % set(gcf, 'color', 'w');
% % print('-dpng','-r150','FdFaFaa2'); %save in same directory as input data
% % 
% % figure;
% % [hCont,hx ,hy,hMain] =Histogram2d(Fd3+Fa3,Faa3,[0 60],[0 60],15,15,10,'$\rm Fd+Fa$','$\rm Faa$',[],[],[0 10 20 30 40 50 60],[0 10 20 30 40 50 60],{'0','10','20','30','40','50','60'},{'0','10','20','30','40','50','60'})
% % set(hCont,'LineColor','none')
% % set(gcf, 'PaperPositionMode', 'auto');
% % set(gcf,'PaperUnits','inches');
% % title(hx,'Photoprotection High Intensity')
% % papersizex=6;
% % papersizey=5;
% % marginx=0.5;
% % marginy=0.5;
% % set(gcf, 'PaperSize', [papersizex papersizey]);
% % set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
% %            papersizey-2*(marginy)]);
% %   set(gcf, 'PaperPositionMode','auto');
% % set(gcf, 'color', 'w');
% % print('-dpng','-r150','FdFaFaa3'); %save in same directory as input data
% 
% 
% %%
% filt=S2<0.75 & S2>0.25;
% % filt=(Fd2+Fa2 >30) & (Faa2>20);
% E2filt=E2(filt);
% S2filt=S2(filt);
% 
% filt=S1<0.75& S1>0.25;
% % filt=(Fd2+Fa2 >30) & (Faa2>20);
% E1filt=E1(filt);
% S1filt=S1(filt);
% 
% filt=S3<0.75& S3>0.25;
% % filt=(Fd2+Fa2 >30) & (Faa2>20);
% E3filt=E3(filt);
% S3filt=S3(filt);
% 
% 
% 
% nebin=25
% figure;
% [n,c]=hist(E1,nebin);
% bh=bar(c,n/sum(n),'b');
% hold on;
% [n,c]=hist(E1filt,nebin);
% bar(c,n/sum(n),'r');
% alpha(get(bh,'children'),.25);
% % colormap(hot(4));
% legend('Unfiltered','Filtered S <0.75 & S>0.25 ')
% title('PBS')
% xlim([0 1])
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','E1filt'); %save in same directory as input data
% 
% figure;
% [n,c]=hist(E2,nebin);
% bh=bar(c,n/sum(n),'b');
% hold on;
% [n,c]=hist(E2filt,nebin);
% bar(c,n/sum(n),'r');
% alpha(get(bh,'children'),.25);
% % colormap(hot(4));
% legend('Unfiltered','Filtered S <0.75 & S>0.25 ')
% title('PhotoProtection')
% xlim([0 1])
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','E2filt'); %save in same directory as input data
% 
% figure;
% [n,c]=hist(E3,nebin);
% bh=bar(c,n/sum(n),'b');
% hold on;
% [n,c]=hist(E3filt,nebin);
% bar(c,n/sum(n),'r');
% alpha(get(bh,'children'),.25);
% % colormap(hot(4));
% legend('Unfiltered','Filtered S <0.75 & S>0.25 ')
% title('PhotoProtection Higher Intensity')
% xlim([0 1])
% set(gcf,'PaperUnits','inches');
% papersizex=6;
% papersizey=5;
% marginx=0.5;
% marginy=0.5;
% set(gcf, 'PaperSize', [papersizex papersizey]);
% set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%            papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
% set(gcf, 'color', 'w');
% print('-dpng','-r150','E3filt'); %save in same directory as input data
