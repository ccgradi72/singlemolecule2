function [ ] = CompareBrightness( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

clc;
close all;

hl=0;

    % Find Data
    [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)

%DATA is number of bursts by 27 columns with each column representing a
%parameter describing the burst (eg. duration, E, anisotropy, lifetime etc)

%recall bursts were saved as
%currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ...
%        Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...
%        Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...
%        Txd Txa Tdd Tad ...
%        tauD rD rA...
%        Eraw Sraw E S];

% size(DATA)

AllRecords=DATA;

Sd=AllRecords(:,5)+AllRecords(:,6);
Bd=(AllRecords(:,11) + AllRecords(:,12)).*AllRecords(:,3);
Fd=Sd-Bd;
filt=Fd<0;
Fd(filt)=[];
Bd(filt)=[];
meanFd(1)=mean(Fd(Fd>15));
size(Bd)
size(Fd)
SNR1=mean(Fd(Fd>15))/mean(Bd(Fd>15))
SNR2=mean(Fd(Fd>15)./(Bd(Fd>15)))
SNR3=mean(Fd./Bd)
SNR4=mean(Fd)/mean(Bd)

xf=60;
xi=1;
nxBins=50;
dx=(xf-xi)/nxBins;
edges{1}=[xi:dx:xf]; % bin for x axis
% edges{1}=logspace(log10(xi),log10(xf),nxBins)
% test=logspace(log10(xi),log10(xf),nxBins)
[nFd,cFd] = hist(Fd,edges{1});
[nBd,cBd] = hist(Bd,edges{1});

% nFd=nFd/sum(nFd);

figure;
hold all;
% bar(cFd,nFd,'BarWidth',1,'FaceColor', [160 160 160]/256);
stairs(cFd,nFd)
stairs(cBd,nBd)
        xlabel('Fd')
        ylabel('Frequency')
        xlim([xi xf])
        ylim([0 1.2*max(nFd)])
        lgndtxt{1}=FileName;
        
% Find Data
    [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)        
        
AllRecords=DATA;

Sd=AllRecords(:,5)+AllRecords(:,6)
Bd=(AllRecords(:,11) + AllRecords(:,12)).*AllRecords(:,3);
Fd=Sd-Bd;
meanFd(2)=mean(Fd(Fd>15));

Fd(Fd<0)=[];

% xf=max(Fd);
% xi=min(Fd);
% nxBins=50;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis
[nFd,cFd] = hist(Fd,edges{1});

nFd=nFd/sum(nFd);

% figure;
% hold all;
% bar(cFd,nFd,'BarWidth',1,'FaceColor', 'r');
stairs(cFd,nFd)
        xlabel('Fd')
        ylabel('Frequency')
        xlim([xi xf])
        ylim([0 1.2*max(nFd)])
        
         lgndtxt{2}=FileName;
         
         
         
% Find Data
    [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)        
        
AllRecords=DATA;

Sd=AllRecords(:,5)+AllRecords(:,6)
Bd=(AllRecords(:,11) + AllRecords(:,12)).*AllRecords(:,3);
Fd=Sd-Bd;
meanFd(3)=mean(Fd(Fd>15));

Fd(Fd<0)=[];

% xf=max(Fd);
% xi=min(Fd);
% nxBins=50;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis
[nFd,cFd] = hist(Fd,edges{1});

nFd=nFd/sum(nFd);

% figure;
% hold all;
% bar(cFd,nFd,'BarWidth',1,'FaceColor', 'g');
stairs(cFd,nFd)
        xlabel('Fd')
        ylabel('Frequency')
        xlim([xi xf])
        ylim([0 1.2*max(nFd)])
        
         lgndtxt{3}=FileName;
         
         
% Find Data
    [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)        
        
AllRecords=DATA;

Sd=AllRecords(:,5)+AllRecords(:,6)
Bd=(AllRecords(:,11) + AllRecords(:,12)).*AllRecords(:,3);
Fd=Sd-Bd;
meanFd(4)=mean(Fd(Fd>15));

Fd(Fd<0)=[];

% xf=max(Fd);
% xi=min(Fd);
% nxBins=50;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis
[nFd,cFd] = hist(Fd,edges{1});

nFd=nFd/sum(nFd);

% figure;
% hold all;
% bar(cFd,nFd,'BarWidth',1,'FaceColor', 'g');
stairs(cFd,nFd)
        xlabel('Fd')
        ylabel('Frequency')
        xlim([xi xf])
        ylim([0 1.2*max(nFd)])
        
         lgndtxt{4}=FileName;         
         
         legend(lgndtxt)
drawnow

meanFd
end

