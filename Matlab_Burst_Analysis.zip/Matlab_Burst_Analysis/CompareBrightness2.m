function [ ] = CompareBrightness( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

CT=cbrewer('qual', 'Dark2', 8);

clc;
close all;

xf=100;
xi=1;
nxBins=20;
dx=(xf-xi)/nxBins;
edges{1}=[xi:dx:xf]; % bin for x axis
xf=100;
xi=1;
nxBins=100;
dx=(xf-xi)/nxBins;
edges{2}=[xi:dx:xf]; % bin for x axis
% edges{1}=logspace(log10(xi),log10(xf),nxBins)
% test=logspace(log10(xi),log10(xf),nxBins)

names={'40 MHz 100 \\muW';'40 MHz 200 \\muW';'40 MHz 400 \\muW';'80 MHz 100 \\muW';'80 MHz 200 \\muW';'80 MHz 400 \\muW';'80 MHz 800 \\muW';'80 MHz 1600 \\muW' }

hl=0;

folder_name='C:\Users\Owner\Dropbox\greg\ALEX SIMULATE\Brightness';
d=dir(fullfile(folder_name,'*.txt'));
% d.name
hf1=figure;
hf2=figure;
star=3;
for i=star+1:numel(d)
    delimiterIn = '\t';
    DATA = importdata(strcat(folder_name,'\',d(i).name),delimiterIn,hl);
%DATA is number of bursts by 27 columns with each column representing a
%parameter describing the burst (eg. duration, E, anisotropy, lifetime etc)

%recall bursts were saved as
%currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ...
%        Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...
%        Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...
%        Txd Txa Tdd Tad ...
%        tauD rD rA...
%        Eraw Sraw E S];

% size(DATA)

AllRecords=DATA;

Sd=AllRecords(:,5)+AllRecords(:,6);
Bd=(AllRecords(:,11) + AllRecords(:,12)).*AllRecords(:,3);
mean(AllRecords(:,11))
mean(AllRecords(:,12))
Fd=Sd-Bd;
filt=Fd<1;
Fd(filt)=[];
Bd(filt)=[];

filt=Fd>0.7*max(Fd);
% filt=Fd>1;
mFd(i-star)=mean(Fd(filt));
mBd(i-star)=mean(Bd(filt));
sFd(i-star)=std(Fd(filt));
sBd(i-star)=std(Bd(filt));
% mSNR(i-star)=mean(Fd(filt)./Bd(filt));
mSNR(i-star)=mean(Fd(filt))/mean(Bd(filt));

[nFd,cFd] = hist(Fd,edges{2});
% [nBd,cBd] = hist(Bd,edges{1});

nFd=nFd/sum(nFd);

figure(hf1);
hold all
% plot(cFd,cumtrapz(nFd),'o-r')
plot(cFd,1-cumsum(nFd),'-','LineWidth',2,'color',CT(i,:))
set(gca,'XScale','Log')
temp=d(i).name;
lgndtxt{i-star}=temp(1:end-4);
% % 
[nFd,cFd] = hist(Fd,edges{1});
nFd=nFd/sum(nFd);
figure(hf2);
hold all;
% % bar(cFd,nFd,'BarWidth',1);
% stairs(cFd,nFd)
hp(i-star)=plot(cFd,nFd,'-o','MarkerFaceColor',CT(i,:),'color',CT(i,:),'LineWidth',2)
set(gca,'YScale','Log')
% % stairs(cBd,nBd)
% %         xlabel('Fd')
% %         ylabel('Frequency')
% %         xlim([xi xf])
% %         ylim([0 1.2*max(nFd)])

power=d(i).name;
power=power(7:end-6)

P(i-star)=str2num(power);


end
figure(hf1)
axis tight
legend(lgndtxt)
        xlim([xi xf])
        ylim([0 1.05])
        
figure(hf2)
axis tight
% legend([hp(1) hp(3) hp(4) hp(5) hp(2)],{lgndtxt{1};lgndtxt{3};lgndtxt{4};lgndtxt{5};lgndtxt{2}})
legend(lgndtxt)
 xlim([xi xf])
 xlabel('F=S-B (Fluorescence Photons)')
 ylabel('Normalized Events')
 
 papersizex=9;
papersizey=6;
marginx=0;
marginy=0;
fontsizeax=20;
fontsizet=12;
ticksize=20;
% offset=[0.1 0.3 0];
offset=[-0.0 0.56 0];
% offset3=[-0.3 1.5 0]
fw='normal';
 
resolution='-r600';

  set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',fw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', 1) ;
        set(gca, 'Box' , 'on' )
%         set(gca,'YTick',[0 0.5 1 1.5 2 2.5 3 3.5])
%         set(gca,'YTickLabel',{'0';'';'1';'';'2';'';'3';''})
        set(get(gca,'xlabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
         set(get(gca,'ylabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
%         set(get(h(i),'title'),'FontSize',fontsizet, 'FontWeight', fw...
%             ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
 
l=0.1
b=0.1
w=0.85
he=0.85

set(gca,'Position',[l b w he])

 set(gcf,'PaperUnits','inches');
        set(gcf, 'PaperSize', [papersizex papersizey]);
        set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
            papersizey-2*(marginy)]);
        set(gcf, 'PaperPositionMode','manual');
        set(gcf, 'color', 'w');
    mytitle='BurstFCountsHist80MhzNofiltlll';
%  print('-painters','-dpdf',resolution,mytitle)
print('-dpdf',resolution,mytitle)
 
 


 papersizex=6;
papersizey=6;

fontsizeax=15;
fontsizet=12;
ticksize=15;
 
 
 [P,I]=sort(P)
 mFd=mFd(I);
 mBd=mBd(I);
 mSNR=mSNR(I);
 
 ms=8;
 figure;
 subplot(2,1,1)
 hold all
 errorbar(P,mFd,sFd,'-o','MarkerFaceColor','b','color','k','LineWidth',1.5,'markersize',ms)
 errorbar(P,mBd,sBd,'-o','MarkerFaceColor','r','color','k','LineWidth',1.5,'markersize',ms)
 legend('F','B','Location','SouthEast')
 set(gca,'YScale','Log')
 xlim([0 1700])
%  xlim([0 500])
 ylim([0.1 500])
 ylabel('N_{f}, N_{b}')
 set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',fw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', 1) ;
        set(gca, 'Box' , 'on' )
        set(gca,'YTick',[0.5 1 10 50 100])
        set(gca,'YTickLabel',{'0.5'; '1' ;'10' ;'50'; '100'})
        set(gca,'XTickLabel',[])
        set(get(gca,'xlabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
         set(get(gca,'ylabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
%         set(get(h(i),'title'),'FontSize',fontsizet, 'FontWeight', fw...
%             ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);

htop=gca;
 
 
 sSNR=mSNR.*sqrt((sFd./mFd).^2 +(sBd./mBd).^2);
 
 subplot(2,1,2)
 errorbar(P,mSNR,sSNR,'-o','MarkerFaceColor','k','color','k','LineWidth',1.5,'Markersize',ms)
%  set(gca,'YScale','Log')
 xlim([0 1700])
%  xlim([0 500])
 xlabel('Power at Objective')
 ylabel('F/B')
%  ylim([0 70])
%  ylim([0 125])
 ylim([0 20])
 
 set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',fw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', 1) ;
        set(gca, 'Box' , 'on' )
%         set(gca,'YTick',[0 25 50])
%         set(gca,'YTickLabel',{'0';'25';'50'})
%         set(gca,'YTick',[0 50 100 125])
%         set(gca,'YTickLabel',{'0';'50';'100';''})
         set(gca,'YTick',[0 5 10])
        set(gca,'YTickLabel',{'0';'5';'10'})
        set(get(gca,'xlabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
         set(get(gca,'ylabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
%         set(get(h(i),'title'),'FontSize',fontsizet, 'FontWeight', fw...
%             ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);

hbot=gca;
 
l=0.15
b=0.1
w=0.8
he=0.435

set(htop,'Position',[l b+he w he])
set(hbot,'Position',[l b w he])

 set(gcf,'PaperUnits','inches');
        set(gcf, 'PaperSize', [papersizex papersizey]);
        set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
            papersizey-2*(marginy)]);
        set(gcf, 'PaperPositionMode','manual');
        set(gcf, 'color', 'w');
    mytitle='PowerSeries80MhzNofiltll';
%  print('-painters','-dpdf',resolution,mytitle)
print('-dpdf',resolution,mytitle)
 
 
 
%         ylim([0 1.05])        
% legend(d.name)
% 
% figure;
% hold all
% plot([100 200 400],mFd(1:3))
% plot([100 200 400],mBd(1:3))
% 
% figure;
% hold all
% plot([100 200 400 800 1600],mFd(4:end))
% plot([100 200 400 800 1600],mBd(4:end))
% 
% figure;
% hold all
% plot([100 200 400],mSNR(1:3))
% plot([100 200 400 800 1600],mSNR(4:end))

end

