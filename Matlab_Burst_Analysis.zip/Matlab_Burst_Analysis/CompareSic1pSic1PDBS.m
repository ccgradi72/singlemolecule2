function []=ososokp()

clear all
close all
clc
b=0.38;



R0=50;
ms=8;
fs=25;
fsa=15;
fsl=10;
lw=2;
noint=0; %dont include completely internal labels

NTr=[0 0 0 0 0 0 21 38 64 83 21 64]; %labelling position closest Nterm
CTr=[7 21 38 64 83 90 90 90 90 90 64 90]; %labelling position closest Cterm

cn=6;
Nrange=60; %fit scaling law up to
N=CTr-NTr;


load('9AAARee.mat','Ree')
sic1Ree=Ree;
load('1AAARee.mat','Ree')
psic1Ree=Ree;

if noint
   sic1Ree(11:12,:)=[];
   psic1Ree(11:12,:)=[];
   N(11:12)=[];
end

sEDirect=1./(1+(sic1Ree./R0).^6);
sAvEDirect=mean(sEDirect,2);
psEDirect=1./(1+(psic1Ree./R0).^6);
psAvEDirect=mean(psEDirect,2);

sRee2=sic1Ree.^2;
smRee2=mean(sRee2,2);
smRee=sqrt(smRee2);
psRee2=psic1Ree.^2;
psmRee2=mean(psRee2,2);
psmRee=sqrt(psmRee2);
smerr2=std(sRee2,0,2)/sqrt(size(sRee2,2));
psmerr2=std(psRee2,0,2)/sqrt(size(psRee2,2));
smerr=(0.5*smRee.*smerr2./smRee2).^2 %prop of uncertainty
psmerr=(0.5*psmRee.*psmerr2./psmRee2).^2

nbin=15
[sN,sX]=hist(sic1Ree(cn,:),nbin);
[psN,psX]=hist(psic1Ree(cn,:),nbin);

bw=0.2
[sf,sxi,bw] = ksdensity(sic1Ree(cn,:),'support',[0 200],'width',bw);
[psf,psxi,bw] = ksdensity(psic1Ree(cn,:),'support',[0 200],'width',bw);

figure;
hold on
plot(sX,sN/sum(sN))
plot(psX,psN/sum(psN))
legend('Sic1','pSic1')

figure;
hold on
plot(sxi,sf)
plot(psxi,psf)
legend('Sic1','pSic1')

nu0=0.55;
Ro0=0.4;
Param0=[Ro0 nu0]
lb=[0.399 0]
ub=[0.401 inf]

maxiter=5000;
maxfunevals=5000;
tolfun=1e-8;
tolx=1e-8;
lsqOpt=[maxiter maxfunevals tolfun tolx];
        
        %Set options for solver
%lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');

Rdata=smRee(N<Nrange);
Ndata=N(N<Nrange);
Ndata=Ndata';
[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,Param0,lb,ub,options);
slpfit=modelParam(1)
snufit=modelParam(2)

Nfit=0:1:max(N);
sRfit=10*sqrt(2*slpfit*b)*Nfit.^snufit;

Rdata=psmRee(N<Nrange);
Ndata=N(N<Nrange);
Ndata=Ndata';
[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,Param0,lb,ub,options);
pslpfit=modelParam(1)
psnufit=modelParam(2)

Nfit=0:1:max(N);
psRfit=10*sqrt(2*pslpfit*b)*Nfit.^psnufit;

smerr=repmat(1.5, size(smRee));
psmerr=smerr;
logerrs=sqrt(smerr./smRee);
logerrp=sqrt(psmerr./psmRee);

figure;
hold on
% h=plot(log(N),log(smRee),'ob');
% set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
h=errorbar(log(N),log(smRee),logerrs,'ob')
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
plot(log(Nfit),log(sRfit),'-b')
% h=plot(log(N),log(psmRee),'^m');
h=errorbar(log(N),log(psmRee),logerrp,'^m');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
% errorbar(log(N(N<60)),log(psmRee(N<60)),logerrp(N<60),'^r')
plot(log(Nfit),log(psRfit),'-m')

xlim([1.5 log(Nrange)])
% yl=ylim(gca);
% vec=yl(1):0.1:yl(2);
% plot(repmat(log(N(cn)),size(vec)),vec,'--b')
legend('Sic1','Sic1 fit','pSic1','pSic1 fit')
xlabel('log(N)')
ylabel('log(RMSD)')

figure;
hold on
h=errorbar(N,smRee,smerr,'ob');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms,'MarkerEdgeColor','k','LineWidth',lw);
% errorbar(N(N<60),smRee(N<60),smerr(N<60),'og')
plot(Nfit,sRfit,'-b')
h=errorbar(N,psmRee,psmerr,'^m');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms,'MarkerEdgeColor','k','LineWidth',lw);
% errorbar(N(N<60),psmRee(N<60),psmerr(N<60),'^r')
plot(Nfit,psRfit,'-m')
% yl=ylim(gca);
% vec=yl(1):0.1:yl(2);
% plot(repmat(N(cn),size(vec)),vec,'--b')
% xlim([0 Nrange])
hl=legend('Sic1','fit Sic1','pSic1','fit pSic1','location','southeast')
set(hl,'Fontsize',fsl)
hx=xlabel('N=|i-j|')
hy=ylabel('RMSD')
% set(gca,'Xscale','log')
% set(gca,'YScale','log')
set( gca                       , ...
    'FontName'   , 'Helvetica' );

set(gca, ...
    'Box'         , 'on'     , ...
    'TickDir'     , 'in'     , ...
    'TickLength'  , [.02 .02] , ...
    'XMinorTick'  , 'off'      , ...
    'YMinorTick'  , 'off'      , ...
    'YGrid'       , 'off'      , ...
    'XColor'      , [.1 .1 .1], ...
    'YColor'      , [.1 .1 .1], ...
    'LineWidth'   , 1         );


set( gca                       , ...
    'FontSize'   , fsa          ,...
    'FontName'   , 'Helvetica' );

set([hx,hy], ...
    'FontName'   , 'Helvetica');
set([hx,hy]  , ...
    'FontSize'   , fs          );

set(gcf, 'PaperPositionMode', 'manual');

set(gcf,'PaperUnits','inches');
papersizex=6;
papersizey=5;
marginx=0.5;
marginy=0.5;
% fontsizeax=12;
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
           papersizey-2*(marginy)]);
%   set(gcf, 'PaperPositionMode','auto');
set(gcf, 'color', 'w');

print('-dpng','-r600','ScalingLaw'); %save in same directory as input data


figure;
hold on
h=plot(1:length(smRee),smRee,'ob');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
h=plot(1:length(smRee),psmRee,'^m');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
legend('Sic1','pSic1')
set(gca,'XTick',1:length(smRee))
set(gca,'XTickLabel',{'1-7';'1-21';'1-38';'1-64';'1-83';'1-90';'21-90';'38-90';'64-90';'83-90';'21-64';'64-90'})
ax=gca;
ax.XTickLabelRotation=90;
xlabel('Construct')
ylabel('RMSD')

figure;
hold on
h=plot(1:length(smRee),(psmRee-smRee)./smRee,'ob');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
set(gca,'XTick',1:length(smRee))
set(gca,'XTickLabel',{'1-7';'1-21';'1-38';'1-64';'1-83';'1-90';'21-90';'38-90';'64-90';'83-90';'21-64';'64-90'})
ax=gca;
ax.XTickLabelRotation=90;
xlabel('Construct')
ylabel('Percent Change')

figure;
hold on
h=plot(1:length(smRee),sAvEDirect,'ob');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
h=plot(1:length(smRee),sAvEDirect,'^m');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
legend('Sic1','pSic1')
set(gca,'XTick',1:length(smRee))
set(gca,'XTickLabel',{'1-7';'1-21';'1-38';'1-64';'1-83';'1-90';'21-90';'38-90';'64-90';'83-90';'21-64';'64-90'})
ax=gca;
ax.XTickLabelRotation=90;
xlabel('Construct')
ylabel('<E>')

figure;
hold on
h=errorbar(1:length(smRee),(psAvEDirect-sAvEDirect),repmat(sqrt(2)*0.02,size(smRee)),'ob');
set(h, 'MarkerFaceColor', get(h, 'Color'),'MarkerSize',ms);
plot(1:length(smRee),zeros(size(smRee)),'--k')
set(gca,'XTick',1:length(smRee))
set(gca,'XTickLabel',{'1-7';'1-21';'1-38';'1-64';'1-83';'1-90';'21-90';'38-90';'64-90';'83-90';'21-64';'64-90'})
ax=gca;
ax.XTickLabelRotation=90;
xlabel('Construct')
ylabel('Change <E>')
tit=sprintf('Ro=%.2f',R0)
title(tit)

    function err=objfcn(param)
       
        lp=param(1);
        nu=param(2);
        
        R=10*sqrt(2*lp*b)*Ndata.^nu;
        
        err=R-Rdata;
        
    end

end
