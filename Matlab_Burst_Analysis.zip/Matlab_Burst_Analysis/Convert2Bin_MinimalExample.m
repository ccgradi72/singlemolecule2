function [ output_args ] = Convert2Bin_MinimalExample( input_args )
%UNTITLED4 Summary of this function goes here
%   Convert index, sstime, and timetag into 32 bit numbers and perform bit
%   shifting and bitor to coerce them into one 32 bit number in the
%   required picoharp format (See testing comments to understand what each
%   operation does, and the reading operation to confirm it works).
clc;
close all
% clear all;

index=[0 1 2 11 15]; %4bit
sstime=[0 21 230 1230 3546]; %12bits
timetag=[0 100 3000 50000 65500];  %16bits

index=uint32(index);
sstime=uint32(sstime);
timetag=uint32(timetag);

% test_index=de2bi(index,4)
% test_sstime=de2bi(sstime,12);
% test_timetag=de2bi(timetag,16);

% T3Record=dec2bin(0,32)
% test_index=dec2bin(bitshift(index,+28),32)
% test_timetag=dec2bin(timetag,32)
% test_sstime=dec2bin(bitshift(sstime,+16),32)

index=bitshift(index,+28);
sstime=bitshift(sstime,+16);

T3Record=bitor(sstime,timetag,'uint32');
% test_T3Record=dec2bin(T3Record,32)
T3Record=bitor(index,T3Record,'uint32');
% test_T3Record=dec2bin(T3Record,32)

fid=fopen('mytest.bin','w');
fwrite(fid,T3Record,'ubit32');
fclose(fid);

%% Test by opening the file that was saved.
data=dir('mytest.bin');
filesize=(data.bytes)/4; %4bytes is one uint32 record.
fid=fopen('mytest.bin','r');
nsync=zeros(1,filesize);
chan=zeros(1,filesize);
sst=zeros(1,filesize);

for i=1:filesize
T3RecordRead = fread(fid, 1, 'ubit32');     % all 32 bits:
  
%   +-------------------------------+  +-------------------------------+ 
%   |x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|  |x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|
%   +-------------------------------+  +-------------------------------+  
  
nsync(i) = bitand(T3RecordRead,65535);       % the lowest 16 bits:
  
%   +-------------------------------+  +-------------------------------+ 
%   | | | | | | | | | | | | | | | | |  |x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|x|
%   +-------------------------------+  +-------------------------------+  
  
chan(i) = bitand(bitshift(T3RecordRead,-28),15);   % the upper 4 bits:

%   +-------------------------------+  +-------------------------------+ 
%   |x|x|x|x| | | | | | | | | | | | |  | | | | | | | | | | | | | | | | |
%   +-------------------------------+  +-------------------------------+

sst(i) = bitand(bitshift(T3RecordRead,-16),4095);   % the middle 12 bits:

%   +-------------------------------+  +-------------------------------+ 
%   | | | | |x|x|x|x|x|x|x|x|x|x|x|x|  | | | | | | | | | | | | | | | | |
%   +-------------------------------+  +-------------------------------+

end


nsync
chan
sst
    

end

