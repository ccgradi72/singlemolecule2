function [index,sstime,timetag] = Convert2Picoharp(ind,sstime,timetag,Tpp)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

%% Overflows and timetag
%The timetag is encoded by 16bits (0 to 65536)
%Every time the counter reaches 65536 an overflow marker is inserted.
%The timetag in ns is (timetag16bit + (num overflows so far)*65536)*Tclock
%ie (num clock cycles)*Tclock, where Tclock is laser pulse period in T3
%mode.

%The first step then is to divide timetag by Tpulse period and round to
%find the number of clock cycles that have occured by that time.

timetag=floor(timetag/Tpp);
numOverflow=floor(timetag./(2^16)); %maybe this should be( 2^16 - 1)
timetag=timetag-numOverflow*(2^16); %equivalent to modulo division
putMarker=diff(numOverflow);
putMarker=find(putMarker==1);

figure;
plot(numOverflow)
title('Num Overflow')

figure;
plot(timetag)
title('timetag')

figure;
plot(putMarker)
title('diff numOverflow')

%An overflow marker is defined as timetag and sstime ==0, index=15
[timetag]=InsertIn(timetag,0,putMarker);
[sstime]=InsertIn(sstime,0,putMarker);
[index]=InsertIn(ind,15,putMarker);


end

