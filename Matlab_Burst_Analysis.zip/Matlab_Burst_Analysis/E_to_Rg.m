function [RgResult,errRg,Rg2,MinDELTA,AVGr,AVGr2,rEav,ERRrEav,varConfHetero,szabUpperLim,r,PrMAT,devvMAT] = E_to_Rg(Egoal,Eerror,Ro,PrModel,varargin)
%UNTITLED2 varargin = {dr, dRG2, erTol}
%   Detailed explanation goes here
global coeff Lcor
Nt=50; %a burst must contain 50 photons or more
% 
% coeff='100rhc4'; 
% Egoal=0.9;
% Eerror=0.002;
% Ro=6.01;
% PrModel='GaussianChain';

% testRg=[2.26 3.16 4.23];
% testRg=testRg.^2;
% 
% for i=1:length(testRg)
%    [~,w,rc]=PrSim([1 2 3 4],testRg(i));
%    disp(sqrt(testRg(i)))
%    disp(w)
%    disp(rc)
% end


if nargin>4
    dr=varargin{1};
    dRg2=varargin{2};
    erTol=varargin{3};
else
    %Should optimize these parameters by looking at
            %minDELTA
            %time per concentration
            %mean Rg error
            %max Rg error
    erTol=0.0005; %has most effect on mean and max Rg error, in combination with dRg2.
    dr=0.1;
    dRg2=0.005; %has the most effect on time, and min delta
    PrModel='GaussianChain'
end


RgResult=zeros(size(Egoal));
MinDELTA=zeros(size(Egoal));
errRg=zeros(size(Egoal));
AVGr=zeros(size(Egoal));
AVGr2=zeros(size(Egoal));
rEav=zeros(size(Egoal));
varConfHetero=zeros(size(Egoal));
szabUpperLim=zeros(size(Egoal));


r=0:dr:4.5*max(Ro);

if Lcor
  r=(-0.002*r.^2) +(1.4*r) -22; %transforms P(r) to P(reff) 
  r=r(r>0);
end
length(r);
Rg2=(0.75)^2:dRg2:(5)^2;
length(Rg2);
EavINT=zeros(size(Rg2));

% hold all
% for k=1:length(Rg2)
%     
%  [PrRg,w,rc]=PrSim(r,Rg2(k));
%  checkNorm=trapz(r,PrRg)
%  Er=1./(1+(r/Ro).^(6));
%  EavARG=Er.*PrRg;
%  wid(k)=w;
%  rcc(k)=rc;
% EavINT(k)=trapz(r,EavARG);
% plot(r,PrRg)
% end
% hold off
% figure;
% plot(sqrt(Rg2),EavINT)
% figure;
% plot(sqrt(Rg2),wid)
% figure;
% plot(sqrt(Rg2),rcc)

% figure;
% plot(r,Er);
% xlabel('r')
% ylabel('Er')

% figure;
% hold all



%% Inner loops optimizes <Rg2> to match <E> with E goal of outerloop.
% figure;
% hold all
PrMAT=zeros(length(Egoal),length(r));
DELTAMAT=zeros(length(Egoal),length(Rg2));
devvMAT=zeros(length(Egoal),length(Rg2));
ERRrEav=zeros(1,length(Egoal));
for j=1:length(Egoal)
    %     clc
    timerVal=tic;
    disp('---------')
    disp('j loop progress')
    disp(j)
    disp('of')
    disp(length(Egoal))
    disp('---------')
    
    
    Er=1./(1+(r/Ro(j)).^(6));
    
%     hold on
    for i=1:length(Rg2)
        
        switch PrModel
            case 'GaussianChain'
                [PrRg]=PrGaussianChain(r,Rg2(i));
                case 'SAWChain'
                [PrRg]=PrSAWChain(r,Rg2(i));
            case 'SimulatedConditional'
                [PrRg]=PrSim(r,Rg2(i));
            otherwise
                errordlg('No PrModel found')
        end
        
%         plot(r,PrRg)
        
        EavARG=Er.*PrRg;
        EavINT(i)=trapz(r,EavARG);
        
    end
    
    
    
    DELTA=abs(EavINT-Egoal(j));
    
    switch PrModel
        case 'GaussianChain'
            devv=0;
        case 'SimulatedConditional'
            devv=EavINT-Egoal(j);
            case 'SAWChain'
            devv=EavINT-Egoal(j);
        otherwise
            errordlg('No PrModel found')
    end
    
    
    
    DELTAMAT(j,:)=DELTA;
    devvMAT(j,:)=devv;
    
%     if j==1
%         DELTAMAT=DELTA;
%         devvMAT=devv;
%     else
%         DELTAMAT=[DELTAMAT; DELTA];
%         devvMAT=[devvMAT; devv];
%     end
    
    [MinDELTA(j),IND]=min(DELTA);
    Rg2Result=Rg2(IND);
    RgResult(j)=sqrt(Rg2Result)
   
    
    %What is <r>, <r^2> implied by this P(r|Rg)
    switch PrModel
            case 'GaussianChain'
                [PrRg]=PrGaussianChain(r,Rg2(IND));
            case 'SAWChain'
                [PrRg]=PrSAWChain(r,Rg2(IND));
            case 'SimulatedConditional'
                [PrRg,w,rc]=PrSim(r,Rg2(IND));
            otherwise
                errordlg('No PrModel found')
    end
%      w
%     rc
    
    PrMAT(j,:)=PrRg;
    
%     if j==1
%         PrMAT=PrRg;
%     else
%         PrMAT=[PrMAT; PrRg];
%     end
    
%    legendt{j}=sprintf('E=%f, j=%f',Egoal(j),j);
    
    AVGr(j)=trapz(r,r.*PrRg);
    
    plot(r,PrRg)
    
    AVGr2(j)=trapz(r,(r.^2).*PrRg);
    
%     varConfHetero(j)=trapz(r,((Er-EavINT(IND)).^2).*PrRg); %variance due to conformational heterogeneity (Gopich Szabo J phys chem B 2007 eq13ish)
    varConfHetero(j)=trapz(r,((Er-Egoal(j)).^2).*PrRg); %variance due to conformational heterogeneity (Gopich Szabo J phys chem B 2007 eq13ish)
    szabUpperLim(j)=varConfHetero(j) + Egoal(j)*(1-Egoal(j))/Nt;

    rEav(j)=Ro(j)*((1/Egoal(j))-1)^(1/6);
%     Ro(j)
    ERRrEav(j)=rEav(j)*sqrt((((1/6)*Eerror(j)./Egoal(j)).^2)+(0)^.2); %this needs to be changed to reflect real uncertainty formula
   
    %There will be at least two places where DELTA is "around" the
    %experimental uncertainty of <E>. Here "around" means within some
    %tolerance eTol, since numerically its unlikely to find a place where
    %DELTA==Eerror exactly.
    
    showDELTA=DELTA(Eerror(j)- erTol <= DELTA & DELTA <= Eerror(j) +erTol);
    Rg2AtErr=Rg2(Eerror(j)- erTol <= DELTA & DELTA <= Eerror(j) +erTol);
    Rg2AtErr=Rg2AtErr(~isnan(showDELTA));
    showDELTA(~isnan(showDELTA))
    
%     
%     
%     if isempty(Rg2AtErr)
% %         w
% %         rc
%         figure
%        semilogy(Rg2,DELTAMAT(end-3:end,:));
%        legend('13','14','15','16')
%        figure
%        plot(r,PrMAT(end-3:end,:))
%        legend('13','14','15','16')
%        Egoal(13:end)
%        figure;
%        [PrRgTest,w,rc]=PrSim(r,2.25^2);
%        Etest=trapz(r,Er.*PrRgTest)
%        plot(r,PrRgTest)
%        title(sprintf('E=%f Rg=2.25',Etest))
%         
%     end
    
    
    RgAtErr=sqrt(Rg2AtErr);
    
  
%     if isempty(Rg2AtErr)
%         errorstring=sprintf('The minimum delta %f conflicts with erTol %f \r\n causing Rg Error estimation to fail \r\n Setting errRg to inf',min(DELTA),erTol)
%         errordlg(errorstring)
%         errRg(j)=Inf;
%     else
        %So now we have a vector Rg2 who have a DELTA which is pretty close
        %to the experimental uncertainty of <E>. Which one of these is furthest
        %away from RgResult? Its distance will be the uncertainty in Rg2.
        
        temp=Rg2AtErr-Rg2Result;
        
        [maxDev,indOfMaxDev]=max(abs(temp(abs(temp)<Rg2AtErr/2)));
        
        
        
        %the next line gives the the Rg2 whose DELTA is within experimental
        %uncertainty of <E> and resulting in the max deviation from RgResult
        maxdevRg2=Rg2AtErr(indOfMaxDev) ;
        maxdevRg=sqrt(maxdevRg2);
        
        try
        errRg(j)=abs(RgResult(j)-maxdevRg) ;
        catch
            errRg=Inf;
        end
       
%     end
    
  
     
    
    
    telapsedPerConc=toc(timerVal)
end

RgResult
ErrRgPercent=(errRg./RgResult)*100; %useful for debugging
meanErrRgPercent=mean((errRg./RgResult)*100);
maxErrRgPercent=max((errRg./RgResult)*100);
meanDELTA=mean(MinDELTA);

% figure;
% scatter(1:1:length(MinDELTA),MinDELTA);
% title('|Egoal-Ecalc(Rg)|')
% % set(gca,'XScale','log')
% 
% figure;
% [hRg]=semilogy(sqrt(Rg2),DELTAMAT,'linewidth',1);
% axis tight


    function [PrRgOUT]=PrGaussianChain(r,Rg2)
%         R2=6*Rg2;
        PrRg1=4*pi*r.^(2);
        PrRg2=(1/(4*pi*Rg2))^(1.5);
        PrRg3=exp(-(r.^2)/(4*Rg2));
        PrRgOUT=PrRg1.*PrRg2.*PrRg3;
        if Lcor
           PrRgOUT=PrRgOUT.*(-0.004*r +1.4);
           PrRgOUT=PrRgOUT/trapz(r,PrRgOUT);
        end
%         checkNorm=trapz(r,PrRgOUT)
    end

function [PrRgOUT]=PrSAWChain(r,Rg2)
        R2=6.26*Rg2;
        a1=0.299;
        a2=1.269;
        R=sqrt(R2);
        PrRg1=4*pi*r.^(2);
        PrRg2=(a1/(R)^3);
        PrRg3=(r/(R)).^0.269;
        PrRg4=exp(-a2*(r/R).^2.427);
        PrRgOUT=PrRg1.*PrRg2.*PrRg3.*PrRg4;
         if Lcor
           PrRgOUT=PrRgOUT.*(-0.004*r +1.4);
           PrRgOUT=PrRgOUT/trapz(r,PrRgOUT);
        end
    end


    function [PrRgOUT,w,rc]=PrSim(r,Rg2)
        
        
        C=2.02;  %Need to change this
        switch coeff
            case '90'
                %the original n=90 SAW
                Z1=-183.13063;
                B1=25.48613;
                B2=-1.08508;
                B3=0.01984;
                B4=-1.34651E-4;
                
                Z2=3.84207;
                ro=-37.14671;
                
            case '100'
                %the n100 SAW simulations
                Z1=-131.88027;
                B1=15.96999;
                B2=-0.48643;
                B3=0.00434;
                B4=1.0139E-5;
                
                Z2=3.77306;
                ro=-40.08632;
                
            case '100rhc4'
                 %the n100 SAW simulations with r_hc=3.14 angstrom
                Z1=-120.07183;
                B1=15.85754;
                B2=-0.52925;
                B3=0.00531;
                B4=1.02129E-5;
                
                Z2=3.73203;
                ro=-36.02189;
                
            case '100rhc3.14'
                %the n100 SAW simulations with r_hc=3.14 angstrom
                Z1=-107.95168;
                B1=15.29116;
                B2=-0.54329;
                B3=0.00584;
                B4=1.14823E-5;
                
                Z2=3.65224;
                ro=-32.01995;
                
            case 'GaussSim'
                %the n100 Gauss simulation
                Z1=1.68789;
                B1=-0.06726;
                B2=0.37797;
                B3=-0.02918;
                B4=6.38106E-4;
                
                Z2=3.10758;
                ro=-11.85742;
                
             case 'SH3'
                
                Z1=-127.72338;
                B1=22.87784;
                B2=-1.23328;
                B3=0.02843;
                B4=-2.41769E-4;
                
                Z2=3.73356;
                ro=-27.22449;   
                
                
        end
        Rg=sqrt(Rg2); %this will need to be converted to Angstrom (since Jianhui's results are in angstrom)
        
        Rg=Rg*10;
        r=r.*10;
        
        
        w=Z1+B1*Rg + B2*Rg^2 + B3*Rg^3 + B4*Rg^4;
        rc=ro+Z2*Rg;
        
        PrCond1=C/(w*sqrt(pi/2));
        PrCond2=exp(-2*(1/w^2)*(r-rc).^2);
        
        PrRgOUT=PrCond1*PrCond2;
        PrRgOUT=PrRgOUT/trapz(r/10,PrRgOUT); %normalize to unit area
        
    end

end




