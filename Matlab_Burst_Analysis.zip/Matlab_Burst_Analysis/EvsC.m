
close all

C=[0 0.1 0.2 0.3 0.4 6]
% Ro=[5.316 5.316 5.268 5.265 5.259 4.949]
EDATA=[0.3062 0.3582 0.3539 0.3167 0.2898 0.183]

figure;
errorbar(C,EDATA,repmat(0.02,size(EDATA)),'o')