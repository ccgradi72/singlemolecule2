function []=FakeTIRFHist()

close all;
clear all;
clc;

N1=2000;
N2=900;

E1=0.833;
E2=0.333;
L=30;

w1=(1/sqrt(L))*(E1*sqrt(1-E1) + (1-E1)*sqrt(E1)) %poiss?
w2=(1/sqrt(L))*(E2*sqrt(1-E2) + (1-E2)*sqrt(E2)) %poiss?

En1=normrnd(E1,w1,1,N1);
En2=normrnd(E2,w2,1,N2);

E=[En1 En2];


xf=1.1;
xi=-0.1;
optM=20;
dx=(xf-xi)/(optM-1);
edges{1}=[xi:dx:xf]; % bin for x axis
[nEraw,cEraw] = hist(E,edges{1});
% NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4)))
hfig=NiceEHist(cEraw,nEraw,'','',0);

co=[E1 E2];
numG=length(co);
wo=[w1 w2];
Ao=[N1 N2];
modelParam0=[co wo Ao];
lb=zeros(length(modelParam0));
ub=[ones(size(co)) Inf(size(wo)) Inf(size(Ao))] ;


modelParam0=[co wo Ao] ;
options=optimset('MaxIter',5000,...
           'TolX',1e-10,'Display','final');
[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnE,modelParam0,lb,ub,options);
% [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnElogn,modelParam0,lb,ub,options);

myx=linspace(min(cEraw),max(cEraw),100);
[myfun]=MakeGauss(modelParam);
% myfun=makelogn(modelParam);
figure(hfig);
hold on
plot(myx,myfun,'-k','LineWidth',2)
fitE=modelParam(1:length(co))
fitEwo=modelParam(length(co)+1:2*length(co))
fitEAo=modelParam(2*length(co)+1:end)

numG=1;
f1=MakeGauss([fitE(1) fitEwo(1) fitEAo(1)]);
f2=MakeGauss([fitE(2) fitEwo(2) fitEAo(2)]);
plot(myx,f1,'-k','LineWidth',1)
plot(myx,f2,'-k','LineWidth',1)

fs=25;
fsa=15;
hYLabel2=ylabel('Events');
hXLabel2=xlabel('E');
set( gca                       , ...
    'FontName'   , 'Helvetica' );
set([hYLabel2,hXLabel2], ...
    'FontName'   , 'Helvitica');
set([hYLabel2,hXLabel2]  , ...
    'FontSize'   , fs          );

set( gca                       , ...
    'FontSize'   , fsa          ,...
    'FontName'   , 'Helvetica' );



L= 0.15; %left
B= 0.15; %bottom
W= 0.8; %2d histogram width (shared with marginal x width)
H=0.8; %2d histogram heigh (shared with marginal y height)
% mH=0.15; %marginal histogram height

% gap=0.04;
% gap=0.0;

set(gca,'Position',[L B W H]); %

set(gcf, 'PaperPositionMode', 'manual');

set(gcf,'PaperUnits','inches');
papersizex=6;
papersizey=5;
marginx=0.5;
marginy=0.5;
% fontsizeax=12;
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
           papersizey-2*(marginy)]);
set(gcf, 'color', 'w');

print('-dpng','-r600','TirfHistoFake'); %save in same directory as input data


function [myfun]=objfcnE(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(1,length(cEraw));
        for j=1:length(c)
           
            y=y+(A(j)/(w(j)*sqrt(pi/2)))*exp(-2*((cEraw-c(j)).^2)/(w(j)^2));
            
            
        end
        
       
        myfun=(nEraw-y);
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
end

function [myfun]=MakeGauss(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(size(myx));
        for j=1:length(c)
           
            y=y+(A(j)/(w(j)*sqrt(pi/2)))*exp(-2*((myx-c(j)).^2)/(w(j)^2));
            
            
        end
        
       
        myfun=y;
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
    end
end