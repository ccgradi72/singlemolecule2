function [synccount] =FileAnalysis(PathFileName,synccount)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

global numRecords T3mode

global T_interburst nspace minBkgPh

global talkative_burst

%% Find the lvm file to get timing information
PathFileNameLVM=PathFileName;
PathFileNameLVM(end-3:end)='.lvm';

% Read the file into matrix
fid = fopen(PathFileNameLVM);
DATA=textscan(fid,'%f','HeaderLines',23);
dt=DATA{1}(4)/1000; %in ns
dt=dt*1E-9; %now in seconds
f0=DATA{1}(5);
Tpp=1/f0; %in seconds
fclose(fid);

%% Read the file of interest in chunks of numRecords

data=dir(PathFileName);
filesize=(data.bytes)/4; %4bytes is one uint32 record.
if numRecords>filesize
    errordlg('NumRecords is too big')
    return
end

numLoops=floor(filesize/numRecords);
%did we miss any records from uneven division?
missRecords=mod(filesize,numRecords);
fid=fopen(PathFileName,'r');

for i=1:numLoops %File Reading Loop
    
    if talkative_burst
        sprintf('Analysing sm File T3Records Chunk %f of %f',i,numLoops)
    end
    
    if T3mode
        [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,numRecords);
    else
        [ind,sstime,timetag,synccount] = ReadT2FilesDouble(fid,Tpp,dt,synccount,numRecords);
        %sstime will be all zeros in this case: Saves me having to write
        %more code to handle the different cases.
    end
    [i_start_out,i_end_out] = SlidingMLT(timetag,ind);
    
    for j=2:length(i_start_out)-1 %Burst reading loop
        
        if talkative_burst
            sprintf('Analysing Burst %f of %f',j,length(i_start_out))
        end
        
        test1=timetag(i_start_out(j))
        test2=timetag(i_end_out(j-1))
        test3=timetag(i_start_out(j+1))
        test4=timetag(i_end_out(j))
        
        if (timetag(i_start_out(j))-timetag(i_end_out(j-1)) > T_interburst) && (timetag(i_start_out(j+1))-timetag(i_end_out(j)) > T_interburst)
            %this burst should occur >T_interburst seconds after the
            %previous (j-1) burst AND the next burst (j+1) should occur >
            %T_interburst seconds later.
            
            
            if (timetag(i_start_out(j))-timetag(i_end_out(j-1))) > timetag(i_start_out(j+1))-timetag(i_end_out(j))
                % there is more background before burst
                
                if i_start_out(j) - i_end_out(j-1) > minBkgPh + 2*nspace;
                    %there should be at least minBkgPh + 2*nspace photons in between two bursts!
                    
                    %take photons from before burst
                    indBKG=ind(i_end_out(j-1)+nspace:i_start_out(j)-nspace);
                    sstimeBKG=sstime(i_end_out(j-1)+nspace:i_start_out(j)-nspace);
                    timetagBKG=timetag(i_end_out(j-1)+nspace:i_start_out(j)-nspace);

                    test_numbkg=length(indBKG)
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %%%%% BURSTS THAT HAVE PAST ALL THE TESTS ARE %%%%%%%%
                    %%%%%%%%%%% PROCESSED HERE %%%%%%%%%%%%%%
                    AnalyzeBurst(ind(i_start_out(j):i_end_out(j)),sstime(i_start_out(j):i_end_out(j)),timetag(i_start_out(j):i_end_out(j)),indBKG,sstimeBKG,timetagBKG,Tpp,dt,timetag(i_start_out(j))-timetag(i_end_out(j-1)));
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                end
                
            else
                %more background after burst
                
                if i_start_out(j+1) - i_end_out(j) > minBkgPh + 2*nspace;
                    %there should be at least minBkgPh + 2*nspace photons in between two bursts!
                    
                    %take photons from after burst
                    indBKG=ind(i_end_out(j)+nspace:i_start_out(j+1)-nspace);
                    sstimeBKG=sstime(i_end_out(j)+nspace:i_start_out(j+1)-nspace);
                    timetagBKG=timetag(i_end_out(j)+nspace:i_start_out(j+1)-nspace);

                    test_numbkg=length(indBKG)
                    
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %%%%% BURSTS THAT HAVE PAST ALL THE TESTS ARE %%%%%%%%
                    %%%%%%%%%%% PROCESSED HERE %%%%%%%%%%%%%%
                    AnalyzeBurst(ind(i_start_out(j):i_end_out(j)),sstime(i_start_out(j):i_end_out(j)),timetag(i_start_out(j):i_end_out(j)),indBKG,sstimeBKG,timetagBKG,Tpp,dt,timetag(i_start_out(j))-timetag(i_end_out(j-1)));
                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    
                end
                
                
            end
            
            
            
        end
        
        
    
    
    end %Burst reading loop
    
    clear ind  sstime timetag i_start_out i_end_out
    
end %File Reading Loop


if missRecords~=0 %Missed records loop
       
    if T3mode
        [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,missRecords);
    else
        [ind,sstime,timetag,synccount] = ReadT2FilesDouble(fid,Tpp,dt,synccount,missRecords);
        %sstime will be all zeros in this case: Saves me having to write
        %more code to handle the different cases.
    end
    [i_start_out,i_end_out] = SlidingMLT(timetag,ind);
    
    for j=2:length(i_start_out)-1 %Burst reading loop
        
        if talkative_burst
            sprintf('Analysing Burst %f of %f',j,length(i_start_out))
        end
        
        if (timetag(i_start_out(j))-timetag(i_end_out(j-1)) > T_interburst) && ((timetag(i_start_out(j+1))-timetag(i_end_out(j))) > T_interburst)
            %this burst should occur >T_interburst seconds after the
            %previous (j-1) burst AND the next burst (j+1) should occur >
            %T_interburst seconds later.
            
            
            %select photons for bkg computation in region near burst            
            if i_start_out(j+1) - i_end_out(j) > minBkgPh + 2*nspace;
                %there should be at least minBkgPh + 2*nspace photons in between two bursts!
                
                indBKG=ind(i_end_out(j)+nspace:i_start_out(j+1)-nspace);
                sstimeBKG=sstime(i_end_out(j)+nspace:i_start_out(j+1)-nspace);
                timetagBKG=timetag(i_end_out(j)+nspace:i_start_out(j+1)-nspace);
                            
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                %%%%% BURSTS THAT HAVE PAST ALL THE TESTS ARE %%%%%%%%
                %%%%%%%%%%% PROCESSED HERE %%%%%%%%%%%%%%
                AnalyzeBurst(ind(i_start_out(j):i_end_out(j)),sstime(i_start_out(j):i_end_out(j)),timetag(i_start_out(j):i_end_out(j)),indBKG,sstimeBKG,timetagBKG,Tpp,dt,timetag(i_start_out(j))-timetag(i_end_out(j-1)));
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
              
            end
        end
    end %Burst reading loop
    
    clear ind  sstime timetag i_start_out i_end_out
    
    
   
    
end %Missed records loop
fclose(fid);

end

