function [synccount] =FileAnalysisCNTRate2(PathFileName,synccount)
%UNTITLED2 Summary of this function goes here
%   Called by GetIRFMain's directory loop.
% Reads current T3 file of the loop, in chunks of numRecords.


%% Global Variables for Picoharp and Router
global ind_Dpar ind_Dperp ind_Apar ind_Aperp ind_Dexc ind_Aexc numRecords
%% Global Variables for Work flow
global ALEX talkative T3mode
%% Global Variables for Lifetime
global dt dtTraj

global mCNT vCNT numChunks vDeltaT mDeltaT avgtime PCHbinWidth PCHEndBin PCHdd PCHad PCHaa

%% Find the lvm file to get timing information
PathFileNameLVM=PathFileName;
PathFileNameLVM(end-3:end)='.lvm';
PathFileNametxt=PathFileName;
PathFileNametxt(end-3:end)='.txt';


% Read the file into matrix
fid = fopen(PathFileNameLVM);
DATA=textscan(fid,'%f','HeaderLines',23);
dt=DATA{1}(4)/1000; %in ns
dt=dt*1E-9; %now in seconds
f0=DATA{1}(5);
Tpp=1/f0; %in seconds
fclose(fid);

fileID = fopen(PathFileNametxt,'w+');
fprintf(fileID,'%f \r\n',avgtime);

%% Read the file of interest and process in chunks of numRecords

data=dir(PathFileName);
filesize=(data.bytes)/4; %4bytes is one uint32 record.
if numRecords>filesize
    errordlg('NumRecords is too big')
    return
end

numLoops=floor(filesize/numRecords);
%did we miss any records from uneven division?
missRecords=mod(filesize,numRecords)
fid=fopen(PathFileName,'r');

if isempty(numChunks)
    N=numLoops;
else
    N=numChunks;
end

PCHbins=0:PCHbinWidth:PCHEndBin;

% storendd=[];
% storenad=[];
% storenaa=[];

for i=1:N 
  
    filesize2=(data.bytes)/4; %4bytes is one uint32 record.
    if numRecords>filesize2
        errordlg('NumRecords is too big')
        continue
    end

     if T3mode
        [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,numRecords);
    else
        [ind,sstime,timetag,synccount] = ReadT2FilesDouble(fid,Tpp,dt,synccount,numRecords);
        %sstime will be all zeros in this case: Saves me having to write
        %more code to handle the different cases.
    end
        
    tt=timetag(timetag ~= 0);
    tbins=tt(1):avgtime:tt(end);
    
    if i==1
    unique(ind)
    end
    
    if ~any(unique(ind)==ind_Dexc) %check if user accidently put ALEX on when they didn't actually do alex
        ALEX=0;
        sprintf('ALEX OFF')
    end
    
    if ALEX
        
        [indDexc,sstimeDexc,timetagDexc,indAexc,sstimeAexc,timetagAexc] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]);
        
        timetagDexc=timetagDexc(timetagDexc ~= 0);
        indDexc=indDexc((timetagDexc ~= 0));
        sstimeDexc=sstimeDexc((timetagDexc~=0));
        
        timetagAexc=timetagAexc(timetagAexc ~= 0);
        indAexc=indAexc((timetagAexc ~= 0));
        sstimeAexc=sstimeAexc((timetagAexc~=0));
        
        if length(tbins)>1
        [ndd,~]=hist(timetagDexc(indDexc==ind_Dpar|indDexc==ind_Dperp),tbins);
        [nad,~]=hist(timetagDexc(indDexc==ind_Apar|indDexc==ind_Aperp),tbins);
        [naa,~]=hist(timetagAexc(indAexc==ind_Apar|indAexc==ind_Aperp),tbins);

%         [Ndd,eedd]=NBAnalysis(ndd);
%         [Nad,eead]=NBAnalysis(nad);
%         [Naa,eeaa]=NBAnalysis(naa);
%         fprintf(fileID,'%f \t %f \t %f \t %f \t %f \t %f \t %f \r\n',0.5*timetag(1)+0.5*timetag(end),Ndd,eedd/(1000*avgtime),Nad,eead/(1000*avgtime),Naa,eeaa/(1000*avgtime));
        
           mdd=mean(ndd);
           vdd=var(ndd);
           mad=mean(nad);
           vad=var(nad);
           maa=mean(naa);
           vaa=var(naa);

        fprintf(fileID,'%f \t %f \t %f \t %f \t %f \t %f \t %f \r\n',0.5*timetag(1)+0.5*timetag(end),mdd,vdd,mad,vad,maa,vaa);
        
        
        [pdd,~]=hist(ndd,PCHbins);
        [pad,~]=hist(nad,PCHbins);
        [paa,~]=hist(naa,PCHbins);
        
        PCHdd=PCHdd+pdd;
        PCHad=PCHad+pad;
        PCHaa=PCHaa+paa;
        end
        

    else
             
        timetag=timetag(timetag ~= 0);
        ind=ind((timetag ~= 0));
        sstime=sstime((timetag~=0));
        
        if length(tbins)>1
        [ndd,~]=hist(timetag(ind==ind_Dpar|ind==ind_Dperp),tbins);
        [nad,~]=hist(timetag(ind==ind_Apar|ind==ind_Aperp),tbins);
        naa=zeros(size(ndd));

%         [Ndd,eedd]=NBAnalysis(ndd);
%         [Nad,eead]=NBAnalysis(nad);
%         [Naa,eeaa]=NBAnalysis(naa);
%         fprintf(fileID,'%f \t %f \t %f \t %f \t %f \t %f \t %f \r\n',0.5*timetag(1)+0.5*timetag(end),Ndd,eedd/(1000*avgtime),Nad,eead/(1000*avgtime),Naa,eeaa/(1000*avgtime));
        
           mdd=mean(ndd);
           vdd=var(ndd);
           mad=mean(nad);
           vad=var(nad);
           maa=mean(naa);
           vaa=var(naa);

        fprintf(fileID,'%f \t %f \t %f \t %f \t %f \t %f \t %f \r\n',0.5*timetag(1)+0.5*timetag(end),mdd,vdd,mad,vad,maa,vaa);
        
        [pdd,~]=hist(ndd,PCHbins);
        [pad,~]=hist(nad,PCHbins);
        [paa,~]=hist(naa,PCHbins);
        
        PCHdd=PCHdd+pdd;
        PCHad=PCHad+pad;
        PCHaa=PCHaa+paa;
        end
    
    end
    
   
end %File Reading Loop

fclose(fileID);

fclose(fid);


    function [N,ee]=NBAnalysis(n)
        
        m=mean(n);
        v=var(n);
        
        N=(m.^2)./(v-m);
        ee=(v-m)./m;
    end

end

