function [synccount] =FileAnalysis_v2(PathFileName,synccount)
%UNTITLED2 Summary of this function goes here

%%UPDATE Jan 12 2017 Don't use photons between bursts to calc bkg. It turns
%%out to be a stupid way to do things. Just use a background file.

%   In version one of FileAnalysis, I used the photons in between bursts in
%   order to calculate the background. For low background there are few
%   photons and in this case, the interphoton times are a poor estimate of
%   the background rate. This version aims to improve the analysis by doing
%   an inverse burst search within the same chunk of data - I think this is
%   OK since the background should not change in the time of a chunk.
%Assuming a chunk is mostly bkg with ~1.5 kcps in donor and acceptor = 3
%kcps total ---> interphoton time ~6.7E-4 seconds. With a chunk
%"numRecords" =10000 this is ~ 6.7 seconds worth of data. If the bkg
%changes every 6.7 seconds, that's an entirely differnent kind of beast!


% One issue I have, is that in ALEX, I sort photons once in order to find
% the background in each channel due to donor excitation, and in each
% channel due to acceptor excitation (since different laser
% intensities/absorption emission properties of impurities could lead to
% different amounts of background) -- but then I sort again within the
% burst. Doing the same computation twice seems wasteful - but I will
% defend myself (for now) by arguing that with 10-200 photons in a burst,
% the addditional time for sorting is negligible, while the additional time
% to program is not.

% DCBS still needs to be programmed.

global numRecords T3mode TrajFRET TrajPol

global T_interburst ind_Dexc ind_Aexc ALEX DCBS
global ind_Dpar ind_Dperp ind_Apar ind_Aperp
global talkative_burst dtTraj plotstate FirstRun BKGFile BKG Tpp dt

%% Find the lvm file to get timing information
PathFileNameLVM=PathFileName;
PathFileNameLVM(end-3:end)='.lvm';

% Read the file into matrix
fid = fopen(PathFileNameLVM);
DATA=textscan(fid,'%f','HeaderLines',23);
dt=DATA{1}(4)/1000; %in ns
dt=dt*1E-9; %now in seconds
f0=DATA{1}(5);
Tpp=1/f0; %in seconds
fclose(fid);

%% Read the file of interest in chunks of numRecords

data=dir(PathFileName);
filesize=(data.bytes)/4; %4bytes is one uint32 record.
if numRecords>filesize
    errordlg('NumRecords is too big')
    return
end

numLoops=floor(filesize/numRecords);
%did we miss any records from uneven division?
missRecords=mod(filesize,numRecords);
fid=fopen(PathFileName,'r');

for i=1:numLoops %File Reading Loop
    
    if talkative_burst && rem(i,20)==0
        fprintf('Analysing sm File T3Records Chunk %f of %f \r\n',i,numLoops)
    end
    
 %% Get DATA
    if T3mode
%         [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,numRecords);
        [ind,sstime,timetag,synccount] = ReadT3FilesDouble_chunky(fid,Tpp,dt,synccount,numRecords);
    else
        [ind,sstime,timetag,synccount] = ReadT2FilesDouble(fid,Tpp,dt,synccount,numRecords);
        %sstime will be all zeros in this case: Saves me having to write
        %more code to handle the different cases.
    end
    
    if FirstRun
    UniqueInd=unique(ind)
    maxtimetag=max(timetag(ind~=15));
    mintimetag=min(timetag(ind~=15));
    timeperchunk=maxtimetag-mintimetag
    FirstRun=0;
    end

    
 %% SORT Photons if ALEX, FIND BURSTS AND BKG   
    if ALEX
%         fprintf('Sorting Photons by ALEX . . .')
      
        
%         figure;
%         hold on
%         stem(1E6*(MarkerTimesM1(1:2)-MarkerTimesM1(1)),ones(1,2),'g')
%         stem(1E6*(MarkerTimesM2(1:2)-MarkerTimesM1(1)),ones(1,2),'r')
%         axis tight
%         hold off
        
%         fprintf('Sorting Photons by ALEX [done]')
        if DCBS
              [indDexc,~,timetagDexc,indAexc,~,timetagAexc,MarkerTimesM1,MarkerTimesM2] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]); 
            [i_start_D,i_end_D] = SlidingMLT(timetagDexc,indDexc);
             [i_start_A,i_end_A] = SlidingMLT(timetagAexc,indAexc);
             
             [i_start_out,i_end_out] = BurstAND(i_start_D,i_end_D,i_start_A,i_end_A);
             %test for overlap and Define new burst by the AND rule
             %Need to think of a good algorithm here.
             errordlg('DCBS Function not tested');
             
        else %APBS
            [i_start_out,i_end_out] = SlidingMLT(timetag,ind);
%             if 0
%             [Bdd_par,Bdd_perp,Bad_par,Bad_perp,ib_start_out,ib_end_out] = SlidingMLT_Bkg(timetagDexc,indDexc);
%             [~,~,Baa_par,Baa_perp,ib_start_out,ib_end_out] = SlidingMLT_Bkg(timetagAexc,indAexc);
%             else
%                [Bdd_par,Bdd_perp,Bad_par,Bad_perp,Baa_par,Baa_perp] = RobustBKGEst(timetag,ind,i_start_out,i_end_out); 
%                 [~,~,Baa_par,Baa_perp] = RobustBKGEst(timetagAexc,indAexc,i_start_out,i_end_out); 
%             end
        end
        
    else   %not ALEX, only do APBS
      
        [i_start_out,i_end_out] = SlidingMLT(timetag,ind);
%         [Bdd_par,Bdd_perp,Bad_par,Bad_perp,ib_start_out,ib_end_out] = SlidingMLT_Bkg(timetag,ind);
%         [Bdd_par,Bdd_perp,Bad_par,Bad_perp,Baa_par,Baa_perp] = RobustBKGEst(timetag,ind,i_start_out,i_end_out);
%         Baa_par=0;
%         Baa_perp=0;
        
    end
    
    
    
%     BKG=[Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp];
%     BKG(isnan(BKG))=0;
    
    
    %% Display trajectory with bursts identified
    
    if plotstate==1 && i>floor(numLoops/2)
        if TrajFRET
            figure('visible','off');
            if ~ALEX
            %     dtTraj=500E-6;
            edges=min(timetag(ind~=15)):dtTraj:max(timetag(ind~=15));
            length(edges)
            TrajG=histc(timetag(ind==ind_Dpar | ind==ind_Dperp),edges);
            TrajR=histc(timetag(ind==ind_Apar | ind==ind_Aperp),edges);
            length(TrajG)
            length(TrajR)
%             TrajBG=zeros(size(edges));
%             TrajBR=zeros(size(edges));
%             for j=1:length(ib_start_out)
%                 ttBkg=timetag(ib_start_out(j):ib_end_out(j));
%                 indBkg=ind(ib_start_out(j):ib_end_out(j));
%                 TrajBG= TrajBG + histc(ttBkg(indBkg==ind_Dpar | indBkg==ind_Dperp),edges);
%                 TrajBR=TrajBR + histc(ttBkg(indBkg==ind_Apar | indBkg==ind_Aperp),edges);
%             end
            hold all
            plot(edges,TrajG,'g',edges,-1*TrajR,'r')
%             plot(edges,TrajBG,'k',edges,-1*TrajBR,'k')
            %     legend('GG','RR','GR','RG')
            MC1=max(TrajG);
            MC2=max(TrajR);
            MC=max(MC1,MC2);
            bursttimes=0.5*timetag(i_start_out) + 0.5*timetag(i_end_out);
            burstheads=repmat(1.1*MC,size(i_start_out));
            plot(bursttimes,burstheads,'ob');
%             plot(MarkerTimesM1,zeros(size(MarkerTimesM1)),'xb')
%             plot(MarkerTimesM2,zeros(size(MarkerTimesM2)),'xm')
            
            myylabel=sprintf('Photon Counts, %.3f \\mus bins',dtTraj*1E6);
            ylabel(myylabel)
            xlabel('time(s)')
            title(sprintf('%d bursts in %.3f ms',length(i_start_out),(edges(end)-edges(1))*1000))
            axis tight
            xlim( [edges(1) edges(end)])
            %     runss=[timetag(ib_start_out);timetag(ib_end_out)];
            %     plot(runss,repmat(0.9*MC,size(runss)),'-d');
            %     title('Trajectory')
            hold off
            
            %             save('BurstTraj','edges','TrajG','TrajR','TrajBG','TrajBR','bursttimes','burstheads','myylabel')
            save('BurstTraj','edges','TrajG','TrajR','bursttimes','burstheads','myylabel')
            set(gcf, 'PaperPositionMode', 'auto');
            
            set(gcf,'PaperUnits','inches');
            papersizex=6;
            papersizey=5;
            marginx=0.5;
            marginy=0.5;
            % fontsizeax=12;
            set(gcf, 'PaperSize', [papersizex papersizey]);
            set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
                papersizey-2*(marginy)]);
            set(gcf, 'PaperPositionMode','auto');
            set(gcf, 'color', 'w');
            
            print('-dpng','-r150','BurstTrajUpdate'); %save in same directory as input data
            elseif ALEX && DCBS

                 edges=min(timetag(ind~=15)):dtTraj:max(timetag(ind~=15));
%             length(edges)
            TrajGG=histc(timetagDexc(indDexc==ind_Dpar | indDexc==ind_Dperp),edges);
            TrajRG=histc(timetagDexc(indDexc==ind_Apar | indDexc==ind_Aperp),edges);
            TrajRR=histc(timetagAexc(indAexc==ind_Apar | indAexc==ind_Aperp),edges);
            TrajGR=histc(timetagAexc(indAexc==ind_Dpar | indAexc==ind_Dperp),edges);
            
            subplot(2,1,1)
            hold all
            plot(edges,TrajGG,'g',edges,-1*TrajRG,'r')
%             plot(edges,-(Bad_par+Bad_perp)*dtTraj*ones(size(edges)),'k')
%             plot(edges,(Bdd_par+Bdd_perp)*dtTraj*ones(size(edges)),'k')
            MC1=max(TrajGG);
            MC2=max(TrajRG);
            MC=max(MC1,MC2);
            bursttimes=0.5*timetag(i_start_out) + 0.5*timetag(i_end_out);
            burstheads=repmat(1.1*MC,size(i_start_out));
            plot(bursttimes,burstheads,'ob');  
            myylabel=sprintf('Photon Counts, %.3f \\mus bins',dtTraj*1E6);
            ylabel(myylabel)
            xlabel('time(s)')
            title(sprintf('Green Excitation, %d bursts in %.3f ms',length(i_start_out),(edges(end)-edges(1))*1000))
            axis tight
            xlim( [edges(1) edges(end)])
            hold off
            subplot(2,1,2)
            hold all
            plot(edges,TrajGR,'g',edges,-1*TrajRR,'r')
%             plot(edges,-(Baa_par+Baa_perp)*dtTraj*ones(size(edges)),'k')
            MC1=max(TrajGR);
            MC2=max(TrajRR);
            MC=max(MC1,MC2);
            bursttimes=0.5*timetag(i_start_out) + 0.5*timetag(i_end_out);
            burstheads=repmat(1.1*MC,size(i_start_out));
            plot(bursttimes,burstheads,'ob');  
            myylabel=sprintf('Photon Counts, %.3f \\mus bins',dtTraj*1E6);
            ylabel(myylabel)
            xlabel('time(s)')
            title(sprintf('Red Excitation, %d bursts in %.3f ms',length(i_start_out),(edges(end)-edges(1))*1000))
            axis tight
            xlim( [edges(1) edges(end)])
            hold off
            bstart=timetag(i_start_out);
            bend=timetag(i_end_out);
            save('BurstTraj','edges','TrajGG','TrajGR','TrajRG','TrajRR','bursttimes','bstart','bend','burstheads','myylabel')
            set(gcf, 'PaperPositionMode', 'auto');
            
            set(gcf,'PaperUnits','inches');
            papersizex=6;
            papersizey=5;
            marginx=0.5;
            marginy=0.5;
            % fontsizeax=12;
            set(gcf, 'PaperSize', [papersizex papersizey]);
            set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
                papersizey-2*(marginy)]);
            set(gcf, 'PaperPositionMode','auto');
            set(gcf, 'color', 'w');
            
            print('-dpng','-r150','BurstTrajUpdate'); %save in same directory as input data
            
            end
%             drawnow
            plotstate=0;
            
        elseif TrajPol
            figure('visible','off');
            %     dtTraj=500E-6;
            edges=min(timetag(ind~=15)):dtTraj:max(timetag(ind~=15));
            length(edges)
            TrajG=histc(timetag(ind==ind_Dpar ),edges);
            TrajR=histc(timetag(ind==ind_Dperp),edges);
            length(TrajG)
            length(TrajR)
%             TrajBG=zeros(size(edges));
%             TrajBR=zeros(size(edges));
            
            TrajBurstG=zeros(size(edges));
            TrajBurstR=zeros(size(edges));
%             for j=1:length(ib_start_out)
%                 ttBkg=timetag(ib_start_out(j):ib_end_out(j));
%                 indBkg=ind(ib_start_out(j):ib_end_out(j));
% %                 TrajBG= TrajBG + histc(ttBkg(indBkg==ind_Dpar),edges);
% %                 TrajBR=TrajBR + histc(ttBkg(indBkg==ind_Dperp),edges);
%             end
            for j=1:length(i_start_out)
                ttB=timetag(i_start_out(j):i_end_out(j));
                indB=ind(i_start_out(j):i_end_out(j));
                TrajBurstG= TrajBurstG + histc(ttB(indB==ind_Dpar),edges);
                TrajBurstR=TrajBurstR + histc(ttB(indB==ind_Dperp),edges);
            end
            hold all
            plot(edges,TrajG,'g',edges,-1*TrajR,'r')
%             plot(edges,TrajBG,'k',edges,-1*TrajBR,'k')
            plot(edges,TrajBurstG,'g',edges,-1*TrajBurstR,'r')
            %     legend('GG','RR','GR','RG')
            MC1=max(TrajG);
            MC2=max(TrajR);
            MC=max(MC1,MC2);
            bursttimes=0.5*timetag(i_start_out) + 0.5*timetag(i_end_out);
            burstheads=repmat(1.1*MC,size(i_start_out));
            plot(bursttimes,burstheads,'ob');
            myylabel=sprintf('Photon Counts, %.3f \\mus bins',dtTraj*1E6);
            ylabel(myylabel)
            xlabel('time(s)')
            title(sprintf('%d bursts in %.3f ms',length(i_start_out),(edges(end)-edges(1))*1000))
            axis tight
            xlim( [edges(1) edges(end)])
            %     runss=[timetag(ib_start_out);timetag(ib_end_out)];
            %     plot(runss,repmat(0.9*MC,size(runss)),'-d');
            %     title('Trajectory')
            hold off
            save('BurstTraj','edges','TrajG','TrajR','TrajBG','TrajBR','bursttimes','burstheads','myylabel')
%             drawnow
            plotstate=0;
        end
    end
    
    close all
    
    %% Analyze each burst
    
    for j=2:length(i_start_out) %Burst reading loop

            AnalyzeBurst_v2(ind(i_start_out(j):i_end_out(j)),sstime(i_start_out(j):i_end_out(j)),timetag(i_start_out(j):i_end_out(j)),BKG,Tpp,dt,timetag(i_start_out(j))-timetag(i_end_out(j-1)));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    end %Burst reading loop
    
    clear ind  sstime timetag i_start_out i_end_out ib_start_out ib_end_out
    
end %File Reading Loop


if missRecords~=0 %Missed records loop
       
    %% Get DATA
    if T3mode
%         [ind,sstime,timetag,synccount] = ReadT3FilesDouble(fid,Tpp,dt,synccount,missRecords);
        [ind,sstime,timetag,synccount] = ReadT3FilesDouble_chunky(fid,Tpp,dt,synccount,numRecords);
    else
        [ind,sstime,timetag,synccount] = ReadT2FilesDouble(fid,Tpp,dt,synccount,missRecords);
        %sstime will be all zeros in this case: Saves me having to write
        %more code to handle the different cases.
    end
    
 %% SORT Photons if ALEX, FIND BURSTS AND BKG   
    if ALEX
        UniqueInd=unique(ind);
        if ~isempty(UniqueInd(UniqueInd==ind_Dexc)) % added line Jan 19
       
       
        
        
        
       
        
        if DCBS
            [indDexc,sstimeDexc,timetagDexc,indAexc,~,timetagAexc,MarkerTimesM1,MarkerTimesM2] = SortPhotonByALEXReal(ind,sstime,timetag,[ind_Dexc ind_Aexc]);
             [i_start_out_Dexc,i_end_out_Dexc] = SlidingMLT(timetagDexc,indDexc);
             [i_start_out_Aexc,i_end_out_Aexc] = SlidingMLT(timetagAexc,indAexc);
             
             %test for overlap and Define new burst by the AND rule
             %Need to think of a good algorithm here.
             errordlg('Function not written yet: Future Release');
        else %APBS
            [i_start_out,i_end_out] = SlidingMLT(timetag,ind);
%             [Bdd_par,Bdd_perp,Bad_par,Bad_perp,ib_start_out,ib_end_out] = SlidingMLT_Bkg(timetagDexc,indDexc);
%             [~,~,Baa_par,Baa_perp,ib_start_out,ib_end_out] = SlidingMLT_Bkg(timetagAexc,indAexc);
        end
        else
        
        i_start_out=[];
        i_end_out=[];
            
        end
        
    else   %not ALEX, only do APBS
      
        [i_start_out,i_end_out] = SlidingMLT(timetag,ind);
%         [Bdd_par,Bdd_perp,Bad_par,Bad_perp,ib_start_out,ib_end_out] = SlidingMLT_Bkg(timetag,ind);
%         Baa_par=0;
%         Baa_perp=0;
        
    end
%     BKG=[Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp];
    
    %% Analyze each burst
    
    if ~isempty(i_start_out)
    for j=2:length(i_start_out) %Burst reading loop
        
        
            AnalyzeBurst_v2(ind(i_start_out(j):i_end_out(j)),sstime(i_start_out(j):i_end_out(j)),timetag(i_start_out(j):i_end_out(j)),BKG,Tpp,dt,timetag(i_start_out(j))-timetag(i_end_out(j-1)));
   
    end %Burst reading loop
    end
    
    clear ind  sstime timetag i_start_out i_end_out ib_start_out ib_end_out
    
end %Missed records loop
fclose(fid);

end

