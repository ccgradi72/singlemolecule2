E=[0.5870 0.1685];
S=[0.4671 0.5314];
%gamma=1.72;

% E=[0.5939 0.1651];
% S=[0.5033 0.57];
% %gamma=1.83

% E=[0.5935 0.1695];
% S=[0.4985 0.5436];
% %gamma=1.86

% E=[0.6027 0.1741];
% S=[0.4536 0.4636];
% %gamma=1.80



x=1./S;
y=E;

A=[x; ones(1,length(x))];

p=y/A;

figure;
plot(x,y,'o')
hold all
plot(x,p*A)
xlabel('1/S')
ylabel('E')

OMEGA=p(2); %the intercept 
SIGMA=p(1); %the slope

gamma=(OMEGA-1)/(OMEGA + SIGMA -1)

te=sprintf('gamma=%f',gamma)
title(te)