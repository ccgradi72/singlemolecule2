function [ ] = FitEHist_wBoot_Jan20_2017( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

clc;
close all;
global name
name='Y14ASic1Aug10';

numMC=200; %number of bootstrap samples, should be >=100
B=2000;  %Bootstrap repetion should be >=1000
xf=1.1;
xi=-0.1;

tauD0=3.741
% nxBins=20;

load('ReColored','Na_MC','Nd_MC','tau_mc')
% load('ToRecolor','Fd','Fa','bdur')
% % Na_MC=Fa;
% Nd_MC=Fd;

% E=Na_MC./(Na_MC+Nd_MC);

% minN=min(Na_MC+Nd_MC)
% load('ESvec','E','S')
load('ESvec','E','S','tauD')
% E=tauD/tauD0
% load('EmatSic1_PBS1.mat')

% E=S;
% E=E(S<0.7);
% E(E<0.5)=[];
% E(E>0.6)=[];

E=E(E>xi & E<xf);

% E=E(1:2400);


Efull=E(:);
BootE=repmat(Efull,B,1);
size(BootE)


% optM = optBINS(E',100)
optM= 50;

dx=(xf-xi)/(optM-1);
edges{1}=[xi:dx:xf]; % bin for x axis
[nEraw,cEraw] = hist(E,edges{1});
length(cEraw)

mE=mean(E)
      
% Ec0=[0.45 0.8 0.9];
% fixE=[0 0 0 ];
% lb=[0 0.6 0.8];
% ub=[1 1 1];

Ec0=[0.45 ];
fixE=[0 ];
lb=[0 ];
ub=[1];


nPh=30;

for i=1:numMC
r=randi([1, length(BootE)],length(Efull),1);
Esample=BootE(r);
[nErawMAT(:,i),cEraw] = hist(Esample,edges{1});
end
stdE=std(nErawMAT,1,2);
% stdE=1;

[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=FitGaussMix(nEraw,cEraw,stdE,Ec0,fixE,lb,ub,nPh);

for i=1:numMC
    r=randi([1, length(BootE)],length(Efull),1);
Esample=BootE(r);
[snEraw,cEraw] = hist(Esample,edges{1});
[smodelParam(:,i),~,~,~,~,~,~]=FitGaussMix(snEraw,cEraw,stdE,Ec0,fixE,lb,ub,nPh);

end

dmodelParam=std(smodelParam,1,2)

        fEc=modelParam(1:length(Ec0));
        fw=modelParam(length(Ec0)+1:2*length(Ec0));
        fA=modelParam(2*length(Ec0)+1:end);
        
        dfEc=dmodelParam(1:length(Ec0));
        dfw=dmodelParam(length(Ec0)+1:2*length(Ec0));
        dfA=dmodelParam(2*length(Ec0)+1:end);
        
dof = length(residual)-3*length(Ec0);
redchi=resnorm/dof;
      
                  
FitGaussMixResult(nEraw,cEraw,length(Ec0),modelParam,residual)

[AIC]=AInfoCrit_c(redchi,length(cEraw),length(modelParam))
fprintf('The number of bursts was %f\n\n',length(E))
  fprintf('The reduced Chi^2 is %0.3f \r\n',redchi)
        
        for i=1:length(Ec0)
        fprintf('The fitted mean %d: %.3f +/- %.3f \r\n',i,fEc(i),dfEc(i))
        fprintf('The fitted width %d: %.3f +/- %.3f \r\n',i,fw(i),dfw(i))
%         fprintf('The min shot noise width %d: %.3f +/- %.3f \r\n',i,sqrt(fEc(i)*(1-fEc(i))/min(,dfw(i))
        fprintf('The fitted area %d: %.3f +/- %.3f \r\n',i,fA(i),dfA(i))
        end
end

