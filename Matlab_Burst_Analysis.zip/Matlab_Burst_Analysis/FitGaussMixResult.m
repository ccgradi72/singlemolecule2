function []=FitGaussMixResult(nEraw,cEraw,numG,modelParam,residual)
global name
% % clc;
% % % clear all;
% % close all
% % 
% % % for l=1:100
% % E=[repmat(0.2,1,18000/3) repmat(0.5,1,18000/3) repmat(0.8,1,18000/3)];
% % 
% % % E=[ 1 1 1 1 1 0.5 0.5 0.5 0 0 0 0 0 0.5 0.5 0.5 0.5 1 1 1 1 1 1 0.5 0.5 0.5 0.5]
% % n=50;
% % Fa=binornd(n,E);
% % Et=Fa/n;
% % figure;
% % hold all
% % xf=1;
% %     xi=0;
% %     nxBins=50;
% %     dx=(xf-xi)/nxBins;
% %     edges{1}=[xi:dx:xf]; % bin for x axis
% % [nEraw,cEraw] = hist(Et,edges{1});
% % 
% % % saveE(:,l)=nEraw;
% % % end
% % % size(saveE)
% % % aa=std(saveE,1,1)
% % % aa.^2
% % 
% % % size(aa)
% % 
% % 
% % 
% % bar(cEraw,nEraw,'BarWidth',0.75,'FaceColor', [160 160 160]/256);
% %         xlabel('E')
% %         ylabel('Frequency')
% %         xlim([xi xf])
% %         
% %         Ec0=[0.25 0.55 0.85];
%         numG=length(Ec0);
%         w0=sqrt(Ec0.*(1-Ec0)/n);
%        
%         for k=1:length(Ec0)
%         [~,heightspos(k)]=min(abs(Ec0(k)-cEraw))
%         
%         end
%         heights=nEraw(heightspos);
%         A0=heights.*w0*sqrt(pi/2);      
%         modelParam0=[Ec0 w0 A0]
%         
% %         fixParam=[0 0 0 0 0 0 0 0 0];
% fixParam=[fixE zeros(1,length(modelParam0)-length(fixE))]
% fixParam=logical(fixParam); %make sure its logical so it can be used for indexing
% nparam=length(modelParam0)-nnz(fixParam); %number of free parameters
% lb=zeros(1,length(modelParam0)); %lower bounds
% ub=Inf(1,length(modelParam0)); %upper bounds
%    
%         %% Fitting Preamble
% 
% %Solver properties
% maxiter=5000;
% maxfunevals=5000;
% tolfun=1e-8;
% tolx=1e-8;
% lsqOpt=[maxiter maxfunevals tolfun tolx];
%         
%         %Set options for solver
% %lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
% options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');
% 
% 
% 
% %the "heart" of the solver
% 
% if ~isempty(ub)||~isempty(lb)
%     %if there are any upper or lower bounds, use them
%     [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
% else
%     %only able to use levenberg-marquadt if lb and ub are empty AND you can't just have symbol ub, lb you really need to use [] []
%     [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,[],[],options);
% end
% 
% % modelParam

figure;
subplot(2,1,1)
hold all
bar(cEraw,nEraw,'BarWidth',0.75,'FaceColor', [160 160 160]/256);
%         xlabel('E')
set(gca,'XTickLabel',[])
% ylabel('')
        xlim([min(cEraw) max(cEraw)])
                ylim([0 1.05*max(nEraw)])
                box on
                hhist=gca;


        fEc=modelParam(1:numG)
        fw=modelParam(numG+1:2*numG)
        fA=modelParam(2*numG+1:end)
        
        fx=linspace(min(cEraw),max(cEraw),100);
        fy=zeros(size(fx));
        for j=1:length(fEc)
           
            fy=fy+(fA(j)/(fw(j)*sqrt(pi/2)))*exp(-2*((fx-fEc(j)).^2)/(fw(j)^2));
%             infy=(fA(j)/(fw(j)*sqrt(pi/2)))*exp(-2*((fx-fEc(j)).^2)/(fw(j)^2));
%             plot(fx(infy>1),infy(infy>1),'LineWidth',2)
        end
        
plot(fx,fy,'LineWidth',2,'Color','k')

fx=linspace(min(cEraw),max(cEraw),100);
%         fy=zeros(size(fx));
        for j=1:length(fEc)
           
%             fy=fy+(fA(j)/(fw(j)*sqrt(pi/2)))*exp(-2*((fx-fEc(j)).^2)/(fw(j)^2));
            infy=(fA(j)/(fw(j)*sqrt(pi/2)))*exp(-2*((fx-fEc(j)).^2)/(fw(j)^2));
            subfy(:,j)=infy;
            plot(fx,infy,'LineWidth',2)
        end
size(subfy)
        subplot(2,1,2)
        bar(cEraw,residual,'BarWidth',0.75,'FaceColor', [160 160 160]/256);
%         xlabel('E')
%         ylabel('Residual')
        axis tight
        xlim([min(cEraw) max(cEraw)])
        ylim([1.1*min(residual) 1.1*max(residual)])
        set(gca,'YTick',[-2 -1 0 1 2])
        box on
        hres=gca;
        
       
        left=0.1
        bottom=0.1
        height1=0.65;
        height2=0.2;
        width=0.85;
        
        set(hhist,'Position',[left bottom+height2+0.05 width height1])
        set(hres,'Position',[left bottom width height2])
       
%         save(name,'cEraw','nEraw','fx','fy','subfy','fEc')
        
        
        NiceEHist_subs(cEraw,nEraw,[],name,0,fx,fy,subfy,fEc)
        
        
%         figure;
%         plot(cEraw,residual)
        
%         
% %errors of fit
% dof = length(residual)-nparam;
% redchi=resnorm/dof;
% Jacobianf=full(jacobian); %lsqnonlin returns  Jacobian as sparse matrix
% Jacobianf(:,fixParam)=[]; %the columns corresponding to fixed parameters should be deleted to avoid singular Jacobian inverse problem
% varp=resnorm*((Jacobianf'*Jacobianf)^-1)/dof;
% stdp=sqrt(diag(varp));
% 
% cinv=diag(varp^-1);
% c=diag(varp);
% 
% dep=1-(1./cinv.*c);%if eqn is overparameterized a mutual dependency exists
% %values close to 1 indicate strong dependnency
% dep=dep';
% %if some parameters are fixed, must rewritre stdp vector
% ind=find(fixParam); % eg, fixp= [1 0 0 0 1 0 1] Rinf and bgx fixed at zero
% % ind =[1,5,7]
% %stdp=[2 3 4 6] but should be [0 2 3 4 0 6 0]
% stdp=stdp';
% if ~isempty(ind)
%     for i=1:nnz(fixParam) %three iterations in thsi example
%         if ind(i)==1
%             stdp=[0 stdp]; %=[0 2 3 4 6] on iteration 1
%             dep=[0 dep];
%         elseif ind(i)==length(fixParam)
%             stdp=[stdp 0]; %=[0 2 3 4 0 6 0]
%             dep=[dep 0];
%         else
%             stdp=[stdp(1:ind(i)-1) 0 stdp(ind(i):end)];
%             %=[1 2 3 4 0 6] on iteration 2
%             dep=[dep(1:ind(i)-1) 0 dep(ind(i):end)];
%         end
%     end
% end
% 
% 
% str=sprintf('The dof = %f = length residual %f - number of parameters %f + number of fixed parameters %f',dof,length(residual),length(modelParam),nnz(fixParam));
% 
% str1 = ['Reduced ChiSq is ',num2str(redchi),'.'];
% logEntry=sprintf('%s \r\n \r\n %s \r\n \r\n %s \r\n \r\n %s',output.message,output.algorithm,str,str1)


end