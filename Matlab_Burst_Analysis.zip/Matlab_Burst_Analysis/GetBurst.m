function [ind,sstime,timetag] = GetBurst(Tburst,S,tau,router,marker,dt)
%UNTITLED Simulate burst of duration Tburst with signal vector S
%   ind, sstime, timetag are purely physical - contains no special marker

%improvements- start/stop of photon record not synchronized with excitation

% clc;
% % clear all;
% close all;

% dt=0.008;
% laserrep=80; %in MHz
% Tlaser=1/(laserrep*1E6); %laser rep period in seconds

indGreen=router(1); %router channels for detectors
indRed=router(2);
M1=marker(1); %index for special marker M1, here representing green exc
M2=marker(2); %index for special marker M2, here representign red exc

SimTime=Tburst; %simulation time in seconds
tauRed=tau(2); %lifetimes of dyes
tauGreen=tau(1);
%Count rates in green and red channel after green and red excitation
Sgg=S(1); %cps
Sgr=S(2);
Srr=S(3);
Srg=S(4);

%Total counts after green excitation
Sge=Sgg+Srg;

%Total counts after red excitation
Sre=Srr+Sgr;

Tge=100; %green excitation periodicity microseconds
Tge=Tge/1E6; %now in seconds
Tre=100; %red excitation periodicity microseconds;
Tre=Tre/1E6;
Tcycle=Tge+Tre;%
Ncycles=floor(SimTime/Tcycle);

%the time tags for the special markers
ttM1=0:(Tge+Tre):Ncycles*(Tge+Tre);
ttM2=Tge:(Tge+Tre):(Ncycles-1)*(Tge+Tre)+Tge;

% Tburst=1000; %average burst duration in microseconds;

%During the T microseconds, how many photons should there be?
%This is the number of events N, in a given interval duration T. 
%We seek p(N|r,T) where r is the rate.
%p(N|r,T) = ((rT)^N)exp(-rT)/N! the Poisson distribution for N with 
%parameter lambda=rT;

%A fundamental property of independent Poisson processes is that there
%pooler process is also a Poisson process with arrival-rate parameter
%equal to the sum of the individual arrival rate.

%The number of photons after green excitation, irrespective of being
%detected in the green or red channel is:
% Nge=zeros([1 Ncycles])
% while ~all(Nge) %I don't like this, but if Nge (i) is zero, 
Nge=poissrnd(Sge*Tge,[1 Ncycles]);
% end

%and similarly for red excitation.
% Nre=zeros([1 Ncycles])
% while ~all(Nre)
Nre=poissrnd(Sre*Tre,[1 Ncycles])
% end


Nph=sum(Nge+Nre)
FileSize=32*(Nph+2*Ncycles)/(1E6) %File Size in Mb assuming each Photon and special marker is a 32 bit record

 
%Now we know how many photons that arrived during red or green excitation
%but not their arrival times, or in which channel they arrived.

%Strategy, create ind, sstime, timetag, add overflow etc afters.

currT=0; %current Time, seconds
curr_ind=[];
curr_sstime=[];
curr_timetag=[];
DurRed=zeros(1,length(Ncycles));
DurGreen=zeros(1,length(Ncycles));
for i=1:Ncycles
    
    if Nge(i)~=0
    %initialize
    curr_ind_ge=zeros(1,Nge(i));
    curr_sstime_ge=zeros(1,Nge(i));
    curr_timetag_ge=zeros(1,Nge(i));
    test0=size(curr_timetag_ge)
    for j=1:Nge(i)
        
        %Nge photons occur during each Tge microsecond green excitation
        %interval. They arrive at the green detector with rate Sgg and arrive at
        %the red detector with rate Srg.
        
        %The expeceted total number of arrivals is (Sgg +Srg)*Tge
        %The expected number of green detector arrivals is Sgg*Tge
        %Thus, the fraction of green arrivals is Sgg/(Sgg+Srg).
        %Because of the no-memory property os Poisson processes, each
        %arrival is an independent Bernoulli experiment, with probability
        %of green detection Pg=Sgg/(Sgg+Srg) and Pr=1-Pg.
        
        %So for each photon, we will decide whether it is green or red
        Pg=Sgg/(Sgg +Srg);
        
        test=rand(1);
        if test<=Pg
            ind=indGreen;
            %            lambda=Sgg;
        else
            ind=indRed;
            %            lambda=Srg;
        end
        
        lambda=Sgg+Srg;
        
        %What is its arrival time? Arrival times are i.i.d random variables
        %drawn from the exponential distribution with parameter lambda the
        %rate.
        
        %is this lambda=(Sgg+Srg) regardless or Sgg for green and
        %Srr for red?
        
        %wait time will be the wait time since real photon event.
        waittime=exprnd(1/lambda); %wait time in seconds
        timetag=currT +waittime; %currT was the arrival time of the last photon record %in seconds
%         k=0;
%         if i~=Nge
%         while timetag > (i-1)*Tre + i*Tge
%             %this photon would arrive after the green special marker
%             %example, on the first loop no red excitation period has passed
%             %if the random wait time would cause the photon to arrive after
%             %the special marker. 
%             
%             waittime=exprnd(1/lambda); 
%             timetag=currT +waittime;
%             sprintf('timetag=%f, Condition = %f, i=%f',timetag,(i-1)*Tre + i*Tge,i)
%             k=k+1; %avoid infinite loop
%             if k>10
%             errordlg( 'Exit due to infinite loop Green')
%             return 
%             end
%           
%         end
%         end
        
        
        sstime=floor(exprnd(tauGreen/dt)); %random number from exponential distribution
        if sstime>4095
            while(sstime)>4095
                sstime=floor(exprnd(tauGreen/dt));
            end
        end
     
        curr_ind_ge(j)=ind;
        curr_sstime_ge(j)=sstime;
        curr_timetag_ge(j)=timetag;
        currT=timetag;
    end

   test1=size(curr_timetag_ge)
   DurGreen(i)=(curr_timetag_ge(end)-curr_timetag_ge(1))/(1E-6); %duration green in microseconds
    else
        curr_ind_ge=[];
        curr_sstime_ge=[];
        curr_timetag_ge=[];
    end 
   
    if Nre(i)~=0
    curr_ind_re=zeros(1,Nre(i));
    curr_sstime_re=zeros(1,Nre(i));
    curr_timetag_re=zeros(1,Nre(i));
    
    test2=size(curr_timetag_re)
   
    for j=1:Nre(i)
            
        %So for each photon, we will decide whether it is green or red
        Pg=Sgr/(Sgr +Srr);
        
        test=rand(1);
        if test<=Pg
            ind=indGreen;
            %            lambda=Sgg;
        else
            ind=indRed;
            %            lambda=Srg;
        end
        
        lambda=Sgr+Srr;
        
        %wait time will be the wait time since last real photon event.
        waittime=exprnd(1/lambda); %wait time in seconds
        timetag=currT +waittime; %currT was the arrival time of the last photon record %in seconds
%         k=0;
%         while timetag > i*Tre + i*Tge
%             %this photon would arrive after the red special marker
%             %example, on the first loop one green period has passed
%             %if the random wait time would cause the photon to arrive after
%             %the special marker. Is it more valid to ignore these photons
%             %or to regenerate a photon?
%             
%             waittime=exprnd(1/lambda); 
%             timetag=currT +waittime;
%             sprintf('timetag=%f, Condition = %f,i=%f',timetag,i*Tre + i*Tge,i)
%             k=k+1; %avoid infinite loop
%             if k>10
%             errordlg( 'Exit due to infinite loop Red')
%             return   
%             end
%            
%         end
        
        
        sstime=floor(exprnd(tauRed/dt)); %random number from exponential distribution
        if sstime>4095
            while(sstime)>4095
                sstime=floor(exprnd(tauRed/dt));
            end
        end
        
        curr_ind_re(j)=ind;
        curr_sstime_re(j)=sstime;
        curr_timetag_re(j)=timetag;
        currT=timetag;
    end
    
    DurRed(i)=(curr_timetag_re(end)-curr_timetag_re(1))/(1E-6); %duration red in microseconds
    
         test2=size(curr_timetag_re)
    else
        curr_ind_re=[];
        curr_sstime_re=[];
        curr_timetag_re=[];
    end
    
    
        %Assemble and add in special markers
        curr_ind=[curr_ind curr_ind_ge curr_ind_re];
        curr_sstime=[curr_sstime curr_sstime_ge curr_sstime_re];
        curr_timetag=[curr_timetag curr_timetag_ge curr_timetag_re];

end

%% Add in the special markers



%the special marker information is encoded in sstime
ssM1=repmat(M1,size(ttM1));
ssM2=repmat(M2,size(ttM2));

% special markers are signified by index==15
indM1=repmat(15,size(ttM1));
indM2=repmat(15,size(ttM2));

%append them to the other data
curr_ind=[curr_ind indM1 indM2];
curr_sstime=[curr_sstime ssM1 ssM2];
curr_timetag=[curr_timetag ttM1 ttM2];

%now sort them by timetag and apply this sorting to ind and sstime to have 
%monotonically increasing timetag.

[timetag,sorti]=sort(curr_timetag);
ind=curr_ind(sorti);
sstime=curr_sstime(sorti);

% %% The outputs of this function
% ind=curr_ind;
% sstime=curr_sstime;
% timetag=curr_timetag;


% testt=sort(timetag);
% testresult=isequal(timetag,testt)









% figure;
% plot(DurGreen)
% figure;
% plot(DurRed)
% meanGreenDur=mean(DurGreen)
% meanRedDur=mean(DurRed)

% edges=0:1E-6:SimTime;
% TrajGreen=histc(curr_timetag(curr_ind==indGreen),edges);
% TrajRed=histc(curr_timetag(curr_ind==indRed),edges);
% 
% figure;
% plot(edges,TrajGreen,'g',edges,TrajRed,'r')
% 
% 
% edges_ss=0:dt:16;
% hist_ss_ge=histc(curr_sstime(curr_ind==indGreen),edges_ss);
% hist_ss_re=histc(curr_sstime(curr_ind==indRed),edges_ss);
% figure;
% plot(edges_ss,hist_ss_ge,'g',edges_ss,hist_ss_re,'r')


%% The task now is to convert from sstime in ns to one which would
%have been encoded by Picoharp, and same with timetag.




% 
%   %Start with a special marker, say green excitation
%     ind=M1;
%     sstime=exprnd(1/4); %random number from exponential distribution
%     %to simulate lifetime of 4 ns
%     sstime=round(sstime/dt);
%     if sstime>4096
%         sstime=sstime-4096; %wrap around
%     end
%     currT=currT+sstime;
%     timetag=currT;
%         sstime=round(sstime/dt);
%         if sstime>4096
%             sstime=sstime-4096; %wrap around %probably not correct
%         end

end

