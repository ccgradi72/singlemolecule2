function [index,sstime,timetag] = GetBurst_coerceTimes(Tburst,Texc,S,tau,router,marker,dt)
%UNTITLED Simulate burst of duration Tburst with signal vector S
%   Starts with M1 ends with M1

indGreen=router(1); %router channels for detectors
indRed=router(2);
M1=marker(1); %index for special marker M1, here representing green exc
M2=marker(2); %index for special marker M2, here representign red exc

SimTime=Tburst; %simulation time in seconds
tauRed=tau(2); %lifetimes of dyes
tauGreen=tau(1);
%Count rates in green and red channel after green and red excitation
Sgg=S(1); %cps
Sgr=S(2);
Srr=S(3);
Srg=S(4);

Tge=Texc(1); %green excitation periodicity microseconds
Tge=Tge/1E6; %now in seconds
Tre=Texc(2); %red excitation periodicity microseconds;
Tre=Tre/1E6;
Tcycle=Tge+Tre;%
Ncycles=floor(SimTime/Tcycle);

%the time tags for the special markers
ttM1=0:(Tge+Tre):Ncycles*(Tge+Tre);
ttM2=Tge:(Tge+Tre):(Ncycles-1)*(Tge+Tre)+Tge;
timetag=0; %initialize
index=0;
sstime=0;

for i=1:length(ttM2)
    
    %A special marker for green
    timetag(end)=ttM1(i);
    index(end)=15;
    sstime(end)=M1;
    
    while (ttM1(i) <= timetag(end) ) && (timetag(end) < ttM2(i))
        
        %interphoton times are Poisson distributed
        lambda=Sgg+Srg;
        waittime=exprnd(1/lambda); %wait time in seconds
        timetag=[timetag timetag(end)+waittime];
        
        %is it green or red?
        Pg=Sgg/(Sgg +Srg); %probability to be green
        
        test=rand(1);
        if test<=Pg
            index=[index indGreen];
        else
            index=[index indRed];
        end
        
        %sstime in TCSPC channel numbers
        sst=floor(exprnd(tauGreen/dt)); %random number from exponential distribution
        if sst>4095
            while(sst)>4095
                sst=floor(exprnd(tauGreen/dt));
            end
        end
        sstime=[sstime sst];
    end
    
    
    %A special marker for red - replace the last one since its timetag >
    %ttM2(i)
    timetag(end)=ttM2(i);
    index(end)=15;
    sstime(end)=M2;
    
    while (ttM2(i) <= timetag(end) ) && (timetag(end) < ttM1(i+1))
        
        %interphoton times are Poisson distributed
        lambda=Sgr+Srr;
        waittime=exprnd(1/lambda); %wait time in seconds
        timetag=[timetag timetag(end)+waittime];
        
        %is it green or red?
        Pg=Sgr/(Sgr +Srr); %probability to be green
        
        test=rand(1);
        if test<=Pg
            index=[index indGreen];
        else
            index=[index indRed];
        end
        
        %sstime in TCSPC channel numbers
        sst=floor(exprnd(tauRed/dt)); %random number from exponential distribution
        if sst>4095
            while(sst)>4095
                sst=floor(exprnd(tauRed/dt));
            end
        end
        sstime=[sstime sst];
    end
    
end



end

