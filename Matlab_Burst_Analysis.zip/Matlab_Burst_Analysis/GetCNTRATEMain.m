function [folder_name] = GetCNTRATEMain(StartPath)
%UNTITLED2 Does Two things: Get offsets, get bkg removed IRF
%   Detailed explanation goes here

%% Global variables for time resolved
global talkative numFiles mCNT vCNT vDeltaT mDeltaT PCHdd PCHad PCHaa


%% Main Loop to build histogram
%Choose a directory
% StartPath='T:\14_May\2014, May28\Sarah\IRFCoverslip_1720h';
folder_name=uigetdir(StartPath,'Choose Folder');
d=dir(fullfile(folder_name,'*.bin'));
sync_count=0;

if isempty(numFiles)
    N=numel(d);
else
    N=numFiles;
end

STOREmCNT=[];
STOREvCNT=[];
STOREmDeltaT=[];
STOREvDeltaT=[];

for i=1:N %Directory Loop
    if talkative
    sprintf('Analysing Bkg File %f of %f',i,numel(d)) 
    end
   [sync_count]= FileAnalysisCNTRate2(strcat(folder_name,'\',d(i).name),sync_count);
   
   STOREmCNT=[STOREmCNT; mCNT]
   STOREvCNT=[STOREvCNT; vCNT]
   STOREmDeltaT=[STOREmDeltaT;mDeltaT]
   STOREvDeltaT=[STOREvDeltaT;vDeltaT]
   
end %Directory Loop

m=STOREmCNT(:,7)
v=STOREvCNT(:,7)

B=v./m %Brightness is variance over mean
Nmb=(m.^2)./v; %number of molecules

n=(m.^2)./(v-m);
epsi=(v-m)./m;

figure;
[hAx,hLine1,hLine2]=plotyy(1:1:N,epsi/1000,1:1:N,n);
title({'Number and Brightness each file ' ; folder_name})
xlabel('File Number')
ylabel(hAx(1),'Brightness (kcps/molecule)') % left y-axis
ylabel(hAx(2),'Number') % right y-axis
set(hLine1,'LineStyle','-')
set(hLine2,'LineStyle','-')
set(hLine1,'LineWidth',2)
set(hLine2,'LineWidth',2)
set(hLine1,'Marker','o')
set(hLine2,'Marker','o')
set(hLine1,'MarkerEdgeColor','k')
set(hLine2,'MarkerEdgeColor','k')
set(hLine1,'MarkerFaceColor','b')
set(hLine2,'MarkerFaceColor','g')

% This is the plot line color.
set(hLine1, 'Color', 'b');
set(hLine2, 'Color', 'g');
set(hAx(1), 'YColor', 'b');
set(hAx(2), 'YColor', 'g');



% figure;
% plot(1:1:N,n)
% title({'Number each file' ; folder_name})

meanNUM=mean(n)
meanEPS=mean(epsi)
stdNUM=std(n,1)
stdEPS=std(epsi,1)
meanDeltaT=mean(STOREmDeltaT)
stdDeltaT=std(STOREmDeltaT)

end

