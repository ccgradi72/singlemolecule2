function [folder_name] = GetCNTRATEMain2(StartPath)
%UNTITLED2 Does Two things: Get offsets, get bkg removed IRF
%   Detailed explanation goes here

%% Global variables for time resolved
global talkative numFiles mCNT vCNT  PCHdd PCHad PCHaa avgtime PCHbinWidth PCHEndBin

  STOREmCNT=[];
   STOREvCNT=[];

%% Main Loop to build histogram
%Choose a directory
% StartPath='T:\14_May\2014, May28\Sarah\IRFCoverslip_1720h';
folder_name=uigetdir(StartPath,'Choose Folder');
d=dir(fullfile(folder_name,'*.bin'));
sync_count=0;

if isempty(numFiles)
    N=numel(d);
else
    N=numFiles;
end


for i=1:N %Directory Loop
    
    PCHbins=0:PCHbinWidth:PCHEndBin;
    PCHdd=zeros(size(PCHbins));
    PCHad=zeros(size(PCHbins));
    PCHaa=zeros(size(PCHbins));
    
    
    if talkative
    sprintf('Analysing Bkg File %f of %f',i,numel(d)) 
    end
   [sync_count]= FileAnalysisCNTRate2(strcat(folder_name,'\',d(i).name),sync_count);
   sync_count=0; %%MULTIPLE UNRELATED FILES --> DON'T CARRY OVER SYNC COUNT
  
   PCHdd=PCHdd/sum(PCHdd);
   PCHad=PCHad/sum(PCHad);
   PCHaa=PCHaa/sum(PCHaa);
    ToPrint=[PCHbins(:) PCHdd(:) PCHad(:) PCHaa(:)];

PathFileNametxt=strcat(folder_name,'\',d(i).name);
PathFileNametxt(end-7:end)='_PCH.txt';
fileID = fopen(PathFileNametxt,'w+');
fprintf(fileID,'%f \t %f \t %f \t %f \r\n',ToPrint');
  
end %Directory Loop


figure;
hold all
plot(PCHbins,PCHdd)
plot(PCHbins,PCHad)
plot(PCHbins,PCHaa)
set(gca,'YScale','log')
axis tight

end

