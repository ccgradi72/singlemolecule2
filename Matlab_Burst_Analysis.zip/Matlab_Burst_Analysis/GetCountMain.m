function [folder_name] = GetBKGMain(StartPath)
%UNTITLED2 Does Two things: Get offsets, get bkg removed IRF
%   Detailed explanation goes here

%% Global variables for time resolved
global cal_DPar cal_DPerp cal_APar cal_APerp t0 dt c_Dpar c_Dperp draw_microtimeG MinPhCal Gaa Gdd ALEX talkative T3mode
global JustCount

%% Main Loop to build histogram
%Choose a directory
StartPath='T:\';
folder_name=uigetdir(StartPath,'JustCounting');
d=dir(fullfile(folder_name,'*.bin'));
sync_count=0;
% for i=1:numel(d) %Directory Loop
for i=1:1 %Directory Loop
    if talkative
    sprintf('Analysing File %f of %f',i,numel(d)) 
    end
   [sync_count]= FileAnalysisCount(strcat(folder_name,'\',d(i).name),sync_count);
   
end %Directory Loop

disp('Counting')
JustCount=JustCount/1E3

DD=JustCount(1)+JustCount(2)
AD=JustCount(3)+JustCount(4)
AA=JustCount(5)+JustCount(6)

l=0.055;
gamma=0.5
direxc=AD-l*DD*gamma

dd=direxc/AA



end

