function [ folder_name ] = GetIRFmain(StartPath)
%UNTITLED2 Does Two things: Get offsets, get bkg removed IRF
%   Detailed explanation goes here

%% Global variables for time resolved
global Irf_DPar Irf_DPerp Irf_APar Irf_APerp t0 dt c_Dpar c_Dperp draw_microtimeIRF MinPhIRF talkative c_Apar c_Aperp

% %For testing only
% draw_microtime=1;
% Irf_DPar=zeros(1,256);
% Irf_DPerp=zeros(1,256);
% t0=2.5;
% global ind_Dpar ind_Dperp ALEX numRecords
% ind_Dpar = 1;
% ind_Dperp = 2;
% ALEX = 0;
% numRecords = 50000;
% clc;
% close all;

%% Main Loop to build histogram
%Choose a directory
% StartPath='T:\14_May\2014, May28\Sarah\IRFCoverslip_1720h';
folder_name=uigetdir(StartPath,'IRF Files');
d=dir(fullfile(folder_name,'*.bin'));
sync_count=0;
for i=1:numel(d) %Directory Loop
    if talkative
    sprintf('Analysing IRF File %f of %f',i,numel(d)) 
    end
   [sync_count]= FileAnalysisIRF(strcat(folder_name,'\',d(i).name),sync_count);
   
   NphDpar=sum(Irf_DPar);
   NphDperp=sum(Irf_DPerp);
   
   if talkative
       sprintf('NphDpar = %f \r\n NphDperp=%f',NphDpar,NphDperp)
   end
   
   if (NphDpar > MinPhIRF) && (NphDperp > MinPhIRF)
       break
   end

end %Directory Loop
% for i=1:2 %Directory Loop
%     sprintf('Analysing IRF File %f of %f',i,numel(d)) 
%    [sync_count]= FileAnalysisIRF(strcat(folder_name,'\',d(i).name),sync_count);
% end %Directory Loop

%% Now we have histogram, lets apply offset in time and update c global vars and irfs
sprintf('Calculating temporal offset to achieve t0=%f ns',t0)
n = length(Irf_DPar);
tv = 1:n;
% size(Irf_DPar)
% size(Irf_DPerp)
% size(tv)
tv=tv';
t0n=(t0*1E-9)/dt; %desired start time in TCSPC channels (dt is now 256*original dt)

if c_Dpar==0
[~,nmax_Dpar_0]=max(Irf_DPar); %current start time
c_Dpar=floor(t0n-nmax_Dpar_0);
end
if c_Dperp==0
[~,nmax_Dperp_0]=max(Irf_DPerp); %current start time
c_Dperp=floor(t0n-nmax_Dperp_0);
end
if c_Apar==0
[~,nmax_Apar_0]=max(Irf_APar); %current start time
c_Apar=floor(t0n-nmax_Apar_0);
end
if c_Aperp==0
[~,nmax_Aperp_0]=max(Irf_APerp); %current start time
c_Aperp=floor(t0n-nmax_Aperp_0);
end

[Irf_APerp]=offsetter(Irf_APerp,c_Aperp,tv,n);
[Irf_DPar]=offsetter(Irf_DPar,c_Dpar,tv,n);
[Irf_DPerp]=offsetter(Irf_DPerp,c_Dperp,tv,n);
[Irf_APar]=offsetter(Irf_APar,c_Apar,tv,n);

sprintf('Global temporal offset c_Dpar=%f and c_Dperp=%f \r\n in rebinned (4096==>256) TCSPC units (16*Picoharp Resolution)',c_Dpar,c_Dperp)
 
%% And now we have to remove bkg
bkg_Dpar=mean(Irf_DPar(end-floor(5*1E-9/dt):end)) %check out the last 5 ns of histogram
bkg_Dperp=mean(Irf_DPerp(end-floor(5*1E-9/dt):end))
bkg_Apar=mean(Irf_APar(end-floor(5*1E-9/dt):end)) %check out the last 5 ns of histogram
bkg_Aperp=mean(Irf_APerp(end-floor(5*1E-9/dt):end))

if draw_microtimeIRF
%Test plot here
figure;
hold all
semilogy((0:length(Irf_DPar)-1)*dt*1E9,Irf_DPar,(0:length(Irf_DPar)-1)*dt*1E9,Irf_DPerp)
semilogy((0:length(Irf_APar)-1)*dt*1E9,Irf_APar,(0:length(Irf_APar)-1)*dt*1E9,Irf_APerp)
set(gca,'YScale','log')
title('Before bkg subtraction')
end

Irf_DPar=Irf_DPar-bkg_Dpar;
Irf_DPerp=Irf_DPerp-bkg_Dperp;
Irf_APar=Irf_APar-bkg_Apar;
Irf_APerp=Irf_APerp-bkg_Aperp;

% %% Test plot here
% % figure;
% % semilogy((0:length(Irf_DPar)-1)*dt*1E9,Irf_DPar,(0:length(Irf_DPar)-1)*dt*1E9,Irf_DPerp)

%Some clean up
Irf_DPar(Irf_DPar<0 | isnan(Irf_DPar))=0;
Irf_DPerp(Irf_DPerp<0 | isnan(Irf_DPerp))=0;
Irf_APar(Irf_APar<0 | isnan(Irf_APar))=0;
Irf_APerp(Irf_APerp<0 | isnan(Irf_APerp))=0;

sprintf('Global Irf_DPar and Irf_DPerp have been set')

% %Normalize
% Irf_DPar=Irf_DPar/sum(Irf_DPar);
% Irf_DPerp=Irf_DPerp/sum(Irf_DPerp);

% if draw_microtimeIRF
% %Test plot here
% figure;
% plot((0:length(Irf_DPar)-1)*dt*1E9,Irf_DPar,(0:length(Irf_DPar)-1)*dt*1E9,Irf_DPerp)
% title('After bkg subtraction')
% end

if draw_microtimeIRF
%Test plot here
figure;
hold all
semilogy((0:length(Irf_DPar)-1)*dt*1E9,Irf_DPar,(0:length(Irf_DPar)-1)*dt*1E9,Irf_DPerp)
semilogy((0:length(Irf_APar)-1)*dt*1E9,Irf_APar,(0:length(Irf_APar)-1)*dt*1E9,Irf_APerp)
set(gca,'YScale','log')
title('After bkg subtraction')
end

end

