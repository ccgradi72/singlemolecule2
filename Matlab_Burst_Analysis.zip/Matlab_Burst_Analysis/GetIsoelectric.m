

% Plot the charge against the pH for a short polypeptide sequence.
isoelectric('MTPSTPPRSRGTRYLAQPSGNTSSSALMQGQKTPQKPSCNLVPVTPSTTKSFKNAPLLAPPNSNMGMTSPFNGLTSPQRSPFPKSSVKRT', 'CHART', true)

% % Get the Rh blood group D antigen from NCBI and calculate
% % its charge at pH 7.3 (typical blood pH).
% gpSeq = getgenpept('AAB39602')
% [pI Charge] = isoelectric(gpSeq, 'Charge', 7.38)