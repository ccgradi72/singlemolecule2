function [  ] = GetOffsetIRF( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

synccount=0;
numRecords=50000;

%% LVM File
[FileName,PathName] = uigetfile('*.bin','Select the data file','T:\14_Feb\2014, Feb11\Greg\');
disp('Now analyzing:')
disp(FileName)
%for the lvm file
FileNameLVM=FileName;
FileNameLVM(end-3:end)='.lvm';
% Read the file into matrix
fid = fopen(strcat(PathName,FileNameLVM));
DATA=textscan(fid,'%f','HeaderLines',23)
dt=DATA{1}(4)/1000 %in ns
dt=dt*1E-9; %now in seconds
f0=DATA{1}(5)
Tpp=1/f0 %in seconds
fclose(fid);

%% Read record(s)
data=dir(strcat(PathName,FileName));
filesize=(data.bytes)/4 %4bytes is one uint32 record.
if numRecords>filesize
    errordlg('NumRecords is too big')
    return
end
fid=fopen(strcat(PathName,FileName),'r');
[ind,sstime,timetag,synccount] = ReadT3Files(fid,Tpp,dt,synccount,numRecords);

%remove special markers
timetag=timetag(ind~=15);
sstime=sstime(ind~=15);
ind=ind(ind~=15);

%% Actual Testing here
edges_ss=0:16:4095;
dt=16*dt;
I_Dpar=histc(sstime(ind==1),edges_ss);
I_Dperp=histc(sstime(ind==2),edges_ss);

I_Dpar=I_Dpar(1:floor(Tpp/dt));
I_Dperp=I_Dperp(1:floor(Tpp/dt));
edges_ss=edges_ss(1:floor(Tpp/dt));

figure;
plot(edges_ss*dt*1E9,I_Dpar,edges_ss*dt*1E9,I_Dperp)

n = length(I_Dpar);
tv = 1:n;

t0n=(2.5E-9)/dt %desired start time in TCSPC channels
[~,nmax_Dpar_0]=max(I_Dpar); %current start time
c_par=floor(t0n-nmax_Dpar_0);
[I_Dpar]=offsetter(I_Dpar,c_par);
[~,nmax_Dperp_0]=max(I_Dperp) %current start time
c_perp=floor(t0n-nmax_Dperp_0);
[I_Dperp]=offsetter(I_Dperp,c_perp);
 
 [~,nmax_Dpar_0]=max(I_Dpar) %current start time
 [~,nmax_Dperp_0]=max(I_Dperp) %current start time
 
 
 %All the below isn't needed, don't need to minimize some function, simply
 %do subtraction to find the number of channels offset you need.
 
% %  figure;
% % c=-floor((1*1E-9)/dt):floor((2*1E-9)/dt);
% % for i=1:length(c)
% %     [I_Dpar_temp]=offsetter(I_Dpar,c(i));
% %     [~,nmax_Dpar]=max(I_Dpar_temp);
% %     temp=t0n-nmax_Dpar; %in TCSPC channels
% %     plot(edges_ss*dt*1E9,I_Dpar_temp)
% %     drawnow 
% %     if temp<=1 %less than two TCSPC difference
% %         cout=c(i)
% %         [I_Dpar]=offsetter(I_Dpar,cout);
% %         plot(edges_ss*dt*1E9,I_Dpar_temp)
% %         drawnow
% %         break
% %     end    
% % end
% % 
% %  [~,nmax_Dperp_0]=max(I_Dperp)
% % for i=1:length(c)
% %     [I_Dperp_temp]=offsetter(I_Dperp,c(i));
% %     [~,nmax_Dperp]=max(I_Dperp_temp);
% %     temp=t0n-nmax_Dpar; %in TCSPC channels
% %     plot(edges_ss*dt*1E9,I_Dperp_temp)
% %     drawnow 
% %     if temp<=1 %less than two TCSPC difference
% %         cout_perp=c(i)
% %         [I_Dperp]=offsetter(I_Dperp,cout);
% %         plot(edges_ss*dt*1E9,I_Dperp_temp)
% %         drawnow
% %         break
% %     end    
% % end

% 
% [~,imin]=min(temp)
% [I_Dpar]=offsetter(I_Dpar,c(imin));
% % plot(edges_ss*dt*1E9,I_Dpar)



% [x,fval,exitflag] = fmincon(@objfcn,[-3,-3],[],[],[],[],[-10,-10],[10,10])
% % 
% %     function [err]=objfcn(offsets)
% %         
%         c=offsets(1); %Offset for parallel
%         b=offsets(2); %Offset for perpendicular
%         
%        I_Dpar= (1-c+floor(c))*I_Dpar(rem(rem(tv-floor(c)-1, n)+n,n)+1) + (c-floor(c))*I_Dpar(rem(rem(tv-ceil(c)-1, n)+n,n)+1); %shifted by c channels
%        I_Dperp= (1-b+floor(b))*I_Dperp(rem(rem(tv-floor(b)-1, n)+n,n)+1) + (b-floor(b))*I_Dperp(rem(rem(tv-ceil(b)-1, n)+n,n)+1); %shifted by b channels
%        
%        [~,nmax_Dpar]=max(I_Dpar);
%        [~,nmax_Dpar]=max(I_Dpar);
%        
%        err=((t0/dt)-nmax_Dpar) + ((t0/dt)-nmax_Dpar); 
%        
%        plot(edges_ss*dt*1E9,I_Dpar,edges_ss*dt*1E9,I_Dperp)
%        drawnow
%        
% %        err=(I_Dpar(1:nmax)/sum(I_Dpar))-(I_Dperp(1:nmax)/sum(I_Dperp))
%     end


    function [I_out]=offsetter(I_in,c)
       
        I_out= (1-c+floor(c))*I_in(rem(rem(tv-floor(c)-1, n)+n,n)+1) + (c-floor(c))*I_in(rem(rem(tv-ceil(c)-1, n)+n,n)+1); %shifted by c channels
        
    end
end

