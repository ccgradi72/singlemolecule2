function [Anew]=InsertIn(A,B,Bi)
        
        %A the vector to insert into
        %B the value(s) to insert
        %Bi the index to insert these values
        
        Bi=Bi+1; %If I put Bi=[3 5 10] I want the new values to appear
                 %after the third, fifth and tenth element of A.
        
        if ~isequal(length(B),length(Bi))
            B=repmat(B,size(Bi));
        end
        
        Anew = zeros(1,length(A)+length(B)) + NaN;
        Anew(Bi+(0:length(Bi)-1)) = B;
        Anew(isnan(Anew)) = A;
       
    end

