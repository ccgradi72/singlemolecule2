

NumToCon=2; %number of files to concatanate
hl=0;
BigDATA=[];

for i=1:NumToCon
[FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    fprintf('Finished loading and saving %s from text file. \r\n It is a %g by %g matrix\r\n',FileName,size(DATA,1),size(DATA,2))
    
    BigDATA=[BigDATA;DATA];
    
    fprintf('BigDATA is now a %g by %g matrix\r\n',size(BigDATA,1),size(BigDATA,2))
end

[FileName,PathName,~] = uiputfile('*.txt','Save joined bursts as:');
fid_burst_txt=fopen([PathName FileName],'w');
fprintf(fid_burst_txt,[repmat('%f \t',1,size(BigDATA,2)) '\r\n'],BigDATA);

fclose all