function []=Just_Explore_Bursts()

clear all
close all

[FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    hl=0;
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BurstWorkstate.mat','DATA','PathName','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)
    
    
    bstart=DATA(:,1);
bdur=DATA(:,3);
S=DATA(:,27);
E=DATA(:,24);
Txd=DATA(:,17);
Txa=DATA(:,18);
Tdd=DATA(:,19);
Tad=DATA(:,20);
Sd=DATA(:,5)+DATA(:,6) ;
Sa=DATA(:,7)+DATA(:,8);
Saa=DATA(:,9)+DATA(:,10);
Bd=DATA(:,11)+DATA(:,12);
Ba=DATA(:,13)+DATA(:,14);
Baa=DATA(:,15)+DATA(:,16);
Fa=Sa-bdur.*Ba;
Fd=Sd-bdur.*Bd;
Faa=Saa-bdur.*Baa;

tslb=DATA(:,4);
tauD=DATA(:,21);
rD=DATA(:,22);

figure;
scatter(Fd+Fa,Faa)

figure;
hist(bdur*1000,50)

figure;
[n,c]=hist(1E-3*(Saa./bdur),0:1:150);
plot(c,n,'s')
pp=poisspdf(c*1000,Baa(1));
pp=pp*max(n)/max(pp);
xlabel('Intensity AA kCPS')
hold all
figure;
plot(c,pp,'o')
figure;
hist(1E-3*((Fa+Fd)./bdur),50)

xlabel('Intensity A+D kcps')

length(Faa)

filt=Faa<30 & Fd+Fa>30;
disp('Donor Only 1')
nnz(filt)/length(Faa)
% filt=Faa<30 & Fd>30;
% disp('Donor Only 2')
% nnz(filt)/length(Faa)
% filt=Faa<30 & Fa>30;
% disp('Donor Only 3')
% nnz(filt)/length(Faa)
% Fd(filt)=[];
% Fa(filt)=[];
% Faa(filt)=[];


% filt=Fd+Fa<30 & Faa>50;
% disp('Acceptor Only')
% nnz(filt)/length(Faa)
% Fd(filt)=[];
% Fa(filt)=[];
% Faa(filt)=[];

% filt=Faa<10 | (Fd+Fa)<10;
% Fd(filt)=[];
% Fa(filt)=[];
% Faa(filt)=[];


if 0
    filt=(Fd+Fa)<30;
    Fd(filt)=[];
    Fa(filt)=[];
    Faa(filt)=[];
    
    figure;
    hist(Faa(Faa<200|Faa==0),50)
end

if 0
    filt=Faa<30;
    Fd(filt)=[];
    Fa(filt)=[];
    Faa(filt)=[];
    
    filt=(Fd+Fa)>150;
    Fd(filt)=[];
    Fa(filt)=[];
    Faa(filt)=[];
    
    figure;
    hist(Fd+Fa,100)
end


filt=Fd+Fa>30 & Faa>30;
disp('FRET')
nnz(filt)/length(Faa)

Slim=[-0.1 1.1];
Elim=[-0.1 1.1];

[E] = correct_E_gamma_leak_dir(Fd,Fa,Faa,1,0,0,'ALEX');
[S] = correct_Stoich_gamma_leak_dir(Fd,Fa,Faa,1,0,0,'ALEX');
filt=E<Elim(1)|E>Elim(2) | S<Slim(1) | S>Slim(2);
disp('Fraction Thrown away')
nnz(filt)/length(E)

E(filt)=[];
S(filt)=[];
Fd(filt)=[];
Fa(filt)=[];
Faa(filt)=[];
bdur(filt)=[];
figure;
hist(E,35)
figure;
hist(S,35)

figure;
scatter(E,S)

figure;
[edgesX2,edgesY2,N] =ndhist(E,S,'axis',[Elim Slim],'filter',10,'binsx',1,'binsy',1);
xlabel('E')
ylabel('S')
xlim(Elim)
ylim(Slim)

% figure; 
% [Cm,hCont]=contourf(edgesX2,edgesY2,N,15);
% cm=flipud(gray);
% colormap(cm);
% xlabel('E')
% ylabel('S')


figure;
hist(Faa,50)

figure;
hist(1E-3*((Fa+Fd)./bdur),50)

xlabel('Intensity A+D kcps')

% Fd(filt)=[];
% Fa(filt)=[];
% Faa(filt)=[];
% 
% figure;
% scatter(Fd+Fa,Faa)
% 
% figure;
% [edgesX2,edgesY2,N] =ndhist(Fd+Fa ,Faa);
% xlabel('Fd+Fa')
% ylabel('Faa')
% xlim([-0.1 1.1])
% ylim([-0.1 1.1])
% 
% figure; 
% [Cm,hCont]=contourf(edgesX2,edgesY2,N,5);
% cm=flipud(gray);
% colormap(cm);
% xlabel('Fd+Fa')
% ylabel('Faa')


end