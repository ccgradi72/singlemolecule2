function [ ] = MinimalBurstExplorer_20180728( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
global k1 k2
k1=0.33; 
k2=0.065;

savetitle='Sic1-forShiftFigure-more'

clc;
close all;

hl=0;
NewData=1;

DNA=0;
Ro_DNA1=54.4;
TauDO_DNA1=3.71;
% sigma_DNA1=8.6;
sigma_DNA1=5;
Ro_DNA2=54.79;
TauDO_DNA2=3.71;
% sigma_DNA2=11.1;
sigma_DNA2=15;


%% Plotting related
scres=20;
fs=18;
fsa=15;
lw=2;
lw_Ehist=2; %line width for E histogram gauss fits
Ebins=30;
EXTRA=0; %print a bunch of extra useless plots
h_kde=5; %smoothing for ndhist kde


%% Select for which population? 1 will keep this population only. all 0 if you want full.
FRET=1;
Aonly=0;
Donly=0;



%% Common filtering
L=30; %photon threshold
AccL=35;
max_bdur=10E-3; %ms
min_bdur=0E-3;
TxdTxa_dif=0.5E-3; %ms (commonly ~1/2 burst duration, try 0.5 ms, 1 ms.
MaxA_Donly=10;
MaxD_Aonly=10;
Slim=[0.25 0.7];
Elim=[-0.1 1.1];
Taulim=[0 10];

E_max_low=1;
E_min_high=0;
% E_max_low=0.29;
% E_min_high=0.31;


%Solver properties
maxiter=5000;
maxfunevals=5000;
tolfun=1e-4;
tolx=1e-4;
lsqOpt=[maxiter maxfunevals tolfun tolx];
%         
%         %Set options for solver
% %lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');
%

%% Correction factors
% gamma=0.76; %Main data Sic1,pSic1, Y14A
gamma=0.71; %Aug 10 Sic1 and Sic1 Y14A
% gamma=0.8
% Lk=0.0158; 
di=0.005;
% gamma=0.8 %Sic1 salt titration, *1.06 for 1M
Lk=0.0135; 
% di=0.005;
% gamma=1; %Sic1 salt titration, *1.06 for 1M
% Lk=0.0; 
% di=0.00;


corrFlag='ABS'; %Either ALEX or ABS - see correct_E_gamma_leak_dir() fcn for details

%% Necessary inputs for multiparameter graphs
% tauD0=3.629; %MLE fit donor only
% tauD0=3.741; %w. scatter lifetime
tauD0=3.605; %w. scatter lifetime
rho=1;
Ro=52.5; %nm for dynamic line avg calculation 52.3 500 mM NaCl 52.5 150 mM NaCl
Nr=90; %number of residues for dynamic line avg
coeff='100rhc4'; %for dynamic line avg

%% Initial guesses for E fitting later!
Eco=[0.4];
Ewo=[0.1 ];
lbEc=[0];
ubEc=[1];



%%Graphing stuff
fw='Normal';
fn='Helvetica';
axw='Normal';
cc=[255, 153, 0]/255
cc2=[48, 94 168]/255
fontsizeax=16;
fontsizel=12;
lwax=1;
ticksize=20;
linewidthbestfit=0.4;
linewidthErrBar=1;
markersize=5;
lw=4;
lwe=2;
ms=markersize;

%%


if exist('BurstWorkstate.mat','file') && ~NewData
    %big files take a long time to read text, better to load if you have
    %already worked with this file already.
    load('BurstWorkstate.mat','DATA','PathName','FileName')
    fprintf('Finished loading from .mat file\r\n')

else
    % Find Data
    [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BurstWorkstate.mat','DATA','PathName','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)
end

fid=fopen(strcat(PathName,FileName(1:end-4),'.log'),'a+');
fprintf(fid,'-------------------- \r\n')
fprintf(fid,'-------------------- \r\n')
fprintf(fid,'-------------------- \r\n')
fprintf(fid,'----New Analysis---- \r\n')
fprintf(fid,datestr(datetime))
fprintf(fid,'\r\n-------------------- \r\n')
fprintf(fid,'-------------------- \r\n')
fprintf(fid,'User inputs \r\n')
fprintf(fid,'gamma=%f, Lk=%f, Dir=%f, TauD0=%f,Ro=%f \r\n',gamma,Lk,di,tauD0,Ro)
fprintf(fid,'L=%f, Lacc=%f, max_bdur=%f, TxdTxa_dif=%f \r\n',L,AccL,max_bdur,TxdTxa_dif)

%DATA is number of bursts by 28 columns with each column representing a
%parameter describing the burst (eg. duration, E, anisotropy, lifetime etc)

%recall bursts were saved as
%currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ... 4
%        Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ... 10
%        Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ... 16
%        Txd Txa Tdd Tad ... 20
%        tauD rD rA... 23
%        Eraw Sraw E S numPh Sda_par Sda_perp]; 30

% %  currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ... %4
% %         Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...   %10
% %         Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...    %16
% %         Txd Txa Tdd Tad ...                              %20
% %         tauD rD rA...            %23
% %         Eraw Sraw E S numPh Sda_par Sda_perp];               %30


% r=randi(size(DATA,1),1,size(DATA,1));
% DATA=DATA(r,:);


% % %         [rDBkg] = Aniso(Sdd_par,Sdd_perp,'D',[]);

bstart=DATA(:,1);
bend=DATA(:,2);
bdur=DATA(:,3);
S=DATA(:,27);
E=DATA(:,24);
Txd=DATA(:,17);
Txa=DATA(:,18);
Tdd=DATA(:,19);
Tad=DATA(:,20);
Sd=DATA(:,5)+DATA(:,6) ;
Sa=DATA(:,7)+DATA(:,8);
Saa=DATA(:,9)+DATA(:,10);
Bd=DATA(:,11)+DATA(:,12);
Ba=DATA(:,13)+DATA(:,14);
Baa=DATA(:,15)+DATA(:,16);
Fa=Sa-bdur.*Ba;
Fd=Sd-bdur.*Bd;
Faa=Saa-bdur.*Baa;

tslb=DATA(:,4);
tauD=DATA(:,21);
rD=DATA(:,22);
rA=DATA(:,23);

Dpar=DATA(:,5)-bdur.*DATA(:,11);
Dperp=DATA(:,6)-bdur.*DATA(:,12);
% rD= Aniso(Dpar,Dperp,'D',1.25);


if length(~isinf(rA))<1
    rA=zeros(size(rA));
end

%check size(DATA,2) if DATA(:,31) DATA(:,32)

try 
mTauD=DATA(:,31)/16;
mTauA=DATA(:,32)/16;
catch
    mTauD=zeros(size(rD));
    mTauA=zeros(size(rD));
end
% mTauD=zeros(size(rD));
% mTauA=zeros(size(rD));

fprintf(fid,'%g bursts in file \r\n',length(bstart))
%% Some stats
lastburst=bstart(end)
Nbursts=length(bstart)
t_bursts=(bstart(end)-bstart(1)); % time from first to last burst in seconds
t_bursts=t_bursts/60 %now minutes
% t_bursts=t_bursts/60 %now hours.
BurstRate=Nbursts/t_bursts
mtslb=mean(tslb*1000) %mean time since last burst in ms
fprintf(fid,'%f Time from first to last burst (minutes) \n',t_bursts)
fprintf(fid,'%f Mean time between bursts ms \n',mtslb)



%% Some preliminary common clean up
filt=bdur>max_bdur | bdur<min_bdur;
fprintf(fid,'%g bursts filtered from max_bdur filter \n',nnz(filt))
bstart(filt)=[];
E(filt)=[];
S(filt)=[];
Faa(filt)=[];
Fd(filt)=[];
Fa(filt)=[];
Tdd(filt)=[];
Tad(filt)=[];
Txd(filt)=[];
Txa(filt)=[];
tauD(filt)=[];
rD(filt)=[];
bdur(filt)=[];
mTauD(filt)=[];
mTauA(filt)=[];
rA(filt)=[];
bend(filt)=[];





%% For filtering, do this on non-corrected E and S, apply corrections after filtering.
if 1
[E] = correct_E_gamma_leak_dir(Fd,Fa,Faa,1,Lk,di,corrFlag);
% [E] = correct_E_gamma_leak_dir(Fd,Fa,Faa,gamma,Lk,di,corrFlag);
[S] = correct_Stoich_gamma_leak_dir(Fd,Fa,Faa,1,Lk,di,corrFlag);
end

%% Get rid of obviously terrible bursts that are never recoverable
    filt=(E> 1.1 | E<-0.2); 
    bstart(filt)=[];
    E(filt)=[];
    S(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
    mTauD(filt)=[];
mTauA(filt)=[];
rA(filt)=[];
bend(filt)=[];
fprintf(fid,'%g bursts filtered from E cleanup filter \n',nnz(filt))
    
    filt=(S> 1.1 | S<-0.1);  
    bstart(filt)=[];
    E(filt)=[];
    S(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
    mTauD(filt)=[];
mTauA(filt)=[];
rA(filt)=[];
bend(filt)=[];
fprintf(fid,'%g bursts filtered from S cleanup filter \n',nnz(filt))


if 0
%% E vs S before filtering

figure;
[edgesX2,edgesY2,N] =ndhist(E ,S,'axis',[-0.1 1.1 -0.1 1.1],'filter',h_kde,'binsx',1,'binsy',1);
% xlabel('E')
% ylabel('S')
xlim([-0.1 1.1])
ylim([-0.1 1.1])
% title('E vs S before filtering')

 set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'on' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
        
%          left1=0.1;
%         left2=left1;
%         width1=0.85;
%         width2=width1;
%         
%         height1=0.85;
%         height2=0.15;
%         
%         bottom1=0.1;
%         bottom2=bottom1+height2+0.03;

 
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_ES_pre'))


figure;
[edgesX2,edgesY2,N] =ndhist(E ,tauD,'axis',[-0.1 1.1 0 7],'filter',h_kde,'binsx',2,'binsy',2);
% xlabel('E')
% ylabel('tauD')
xlim([-0.1 1.1])
% ylim([-0.1 1.1])
% title('E vs tau before filtering')

 set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'on' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
 
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_Etau_pre'))

% figure;
% [edgesX2,edgesY2,N] =ndhist(E ,tauD,'axis',[-0.1 1.05 0 6],'filter',h_kde,'binsx',2,'binsy',2,'log');
% xlabel('E')
% ylabel('tauD')
% xlim([-0.1 1.1])
% % ylim([-0.1 1.1])
% title('LOG E vs tau before filtering')

figure;
[edgesX2,edgesY2,N] =ndhist(E,(Txd-Txa)*1000,'axis',[Elim -1.5 1.5],'filter',h_kde,'binsx',1,'binsy',1,'log');
% xlabel('E')
% ylabel('Tx-Txa')
axis tight
% title('E vs Txd-Txa before filter')
set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'on' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
 
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_ETxDTxa_pre'))

% figure;
% [edgesX2,edgesY2,N] =ndhist(E,(Tdd-Tad)*1000,'axis',[Elim -2 2],'filter',h_kde,'binsx',1,'binsy',1,'log');
% % xlabel('E')
% % ylabel('Tx-Txa')
% axis tight


figure;
xf=1.1;
xi=-0.1;
dx=(xf-xi)/(Ebins-1);
edges{1}=[xi:dx:xf]; % bin for x axis
[nEraw,cEraw]=hist(E(E>xi & S>Slim(1)),edges{1});
title('E before filtering')

hfig=NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4),'_Ecor'),0);
% parmhat=lognfit(nEraw)
numG=length(Eco);

EAo=[];
for i=1:length(Ewo)
EAo=[EAo max(nEraw)*Ewo(i)*sqrt(pi/2)];
end
modelParam0=[Eco Ewo EAo];
lb=[lbEc zeros(1,length(modelParam0)-length(lbEc))];
ub=[ubEc Inf(size(Ewo)) Inf(size(EAo))];


[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnE,modelParam0,lb,ub,options);
% [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnElogn,modelParam0,lb,ub,options);

fitE=modelParam(1:length(Eco))
fitEwo=modelParam(length(Eco)+1:2*length(Eco))
fitEAo=modelParam(2*length(Eco)+1:end)

myx=linspace(min(cEraw),max(cEraw),100);
figure(hfig);
hold on

for i=1:length(fitE)
numG=1; %I know - this is so hacky. But MakeGauss needs to know how many Gaussians you gave it - and Im  a bad programmer who uses global variables    
[myfun]=MakeGauss([fitE(i) fitEwo(i) fitEAo(i)]);
% myfun=makelogn(modelParam);
plot(myx,myfun,'-k','LineWidth',lw_Ehist)
end

xlabel(gca,'')
ylabel(gca,'')

yl=ylim(gca);
% plot(repmat(fitE(1),1,100),linspace(yl(1),yl(2),100),'Color',[0 0 128]/256,'LineWidth',3)

wshot=2*sqrt((fitE.*(1-fitE))/L)
extraw=fitEwo./wshot
modelParamShot=[fitE wshot max(myfun)*wshot*sqrt(pi/2)]

% if ~isempty(myYlim)
% set(gca,'Ylim',[0 myYlim])
% end
xlabel(gca,'')
ylabel(gca,'')
set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'on' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
 
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2

hold off
figure(hfig)
print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_Efit_before_filt'))
fprintf(fid,'Fit to E Histogram w/ Gaussian(s) \r\n')
for i=1:length(fitE)
    fprintf(fid,'%g: Center = %f \r\n',i,fitE(i))
    RDA=Ro*((1-fitE(i))/fitE(i))^(1/6);
    fprintf(fid,'%g: Simple R = %f with Ro=%f \r\n',i,RDA,Ro)
    fprintf(fid,'%g: Width  = %f \r\n',i,fitEwo(i))
    fprintf(fid,'%g: Area  = %f \r\n',i,fitEAo(i))
end

Epre=E(S>Slim(1));
Taupre=tauD(S>Slim(1));

figure;
[edgesX2,edgesY2,N] =ndhist(tauD(S>Slim(1)),rD(S>Slim(1)),'axis',[0 5 -0.2 0.6],'binsx',1,'binsy',1,'filter',h_kde);
hold all
taux=0:0.1:6;
rper=0.4./(1+(taux/rho));
plot(taux,rper,'r')
xlabel('tauD')
ylabel('rD')
figure;
[Cm,hCont]=contourf(edgesX2,edgesY2,N,5);
cm=flipud(gray);
colormap(cm);
hold on
plot(taux,rper,'r')
xlabel('tauD')
ylabel('rD')
print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_TauDrD_pre'))
% 
% 
% figure;
% hold all
% scatter(tauD(S>Slim(2)),rD(S>Slim(2)))
% scatter(tauD(S>Slim(1)&S<Slim(2)),rD(S>Slim(1)&S<Slim(2)))
% 



figure;
xf=1.1;
xi=-0.1;
dx=(xf-xi)/(Ebins-1);
edges{1}=[xi:dx:xf]; % bin for x axis
hist(S(S>xi),edges{1});
title('S before filtering')
end


%% Group selection
if FRET
    disp('FRET bursts')
    if 0
        %I'm not sure that I like this way of filtering anymore
        filt=(Fd +Fa <L);  % filter out acceptor only
        bstart(filt)=[];
        E(filt)=[];
        S(filt)=[];
        Faa(filt)=[];
        Fd(filt)=[];
        Fa(filt)=[];
        Txd(filt)=[];
        Txa(filt)=[];
        Tdd(filt)=[];
        Tad(filt)=[];
        tauD(filt)=[];
        rD(filt)=[];
        bdur(filt)=[];
        rA(filt)=[];
        
        filt=(Faa<AccL); % filter out donor only
        bstart(filt)=[];
        E(filt)=[];
        S(filt)=[];
        Txd(filt)=[];
        Txa(filt)=[];
        Tdd(filt)=[];
        Tad(filt)=[];
        tauD(filt)=[];
        rD(filt)=[];
        bdur(filt)=[];
        Faa(filt)=[];
        Fd(filt)=[];
        Fa(filt)=[];
        rA(filt)=[];
    end
%     mTau=mean(tauD)
    
    filt=E<Elim(1)|E>Elim(2) | S<Slim(1) | S>Slim(2) | tauD >Taulim(2) | tauD < Taulim(1) | Fd+Fa <L;
    bstart(filt)=[];
    E(filt)=[];
    S(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    mTauD(filt)=[];
    mTauA(filt)=[];
    rA(filt)=[];
    bend(filt)=[];
    fprintf(fid,'%g bursts filtered from FRET-selection filter \n',nnz(filt))

    filt=abs(Txd-Txa)>TxdTxa_dif;
    fprintf(fid,'%g bursts filtered from TxdTxa_dif filter \n',nnz(filt))
    bstart(filt)=[];
    E(filt)=[];
    S(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
    mTauD(filt)=[];
    mTauA(filt)=[];
    rA(filt)=[];
    bend(filt)=[];
    
    
end

if Aonly
    disp('A-Only bursts')
    filt=(Fd> MaxD_Aonly);  % keep ONLY acceptor only
    E(filt)=[];
    S(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
    
    filt=(Faa<AccL); % filter out donor only
    E(filt)=[];
    S(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
    
    filt=(S>0.15); % 
    E(filt)=[];
    S(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
    
    meanFaa=mean(Faa)
    mS=mean(S(S>0)) %mean S acceptor only,
    d=mS/(1-mS) %direct excitation coeeff, IF you selected acceptor only bursts
    
    if 1
        figure;
        edges=linspace(-0.1,0.5,50);
        [n,c]=hist(S,edges);
        [~,ind]=max(n);
        d3=c(ind)/(1-c(ind));
        bar(c,n,1,'FaceColor','r')
        hold all
        f = fit(c(:),n(:),'gauss1')
        plot(f);
        d2=f.b1/(1-f.b1) %direct excitation coeeff, IF you selected acceptor only bursts
    end
    
    fid1=fopen(strcat(PathName,FileName,'_AonlyBursts.log'),'a+');
    fprintf(fid1,'Acceptor Only Bursts \r\n')
    fprintf(fid1,'%g bursts \r\n',length(E))
    fprintf(fid1,'Method 1: DirectExc. from S of Acceptor Only = %f \r\n',d)
    fprintf(fid1,'Method 2 (best): DirectExc. from S of Acceptor Only = %f \r\n',d2)
    fprintf(fid1,'Method 3: DirectExc. from S of Acceptor Only = %f \r\n',d3)
end
if Donly
    
%     disp('D-Only bursts')
    filt=(S<0.9);  % filter out acceptor only
    E(filt)=[];
    S(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
        mTauD(filt)=[];
    
    
    
    disp('D-Only bursts')
    filt=(Fd<L);  % filter out acceptor only
    E(filt)=[];
    S(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
        mTauD(filt)=[];
    
    filt=(Fa>MaxA_Donly);  % filter out acceptor only
    E(filt)=[];
    S(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
        mTauD(filt)=[];
    
    filt=(Faa>MaxA_Donly); % filter out presence of acceptor
    E(filt)=[];
    S(filt)=[];
    Faa(filt)=[];
    Fd(filt)=[];
    Fa(filt)=[];
    Txd(filt)=[];
    Txa(filt)=[];
    Tdd(filt)=[];
    Tad(filt)=[];
    tauD(filt)=[];
    rD(filt)=[];
    bdur(filt)=[];
        mTauD(filt)=[];
    
    mE=mean(E(E>0))
    l=mE/(1-mE) %leakage coeffecient
    
    if 1
        figure;
        edgess=linspace(-0.1,0.3,50);
        [n,c]=hist(E,edgess);
        bar(c,n,1,'FaceColor','r')
        [~,ind]=max(n);
        l3=c(ind)/(1-c(ind));
        hold all
        f = fit(c(:),n(:),'gauss1')
        l2=f.b1/(1-f.b1) %direct excitation coeeff, IF you selected acceptor only bursts
        plot(f);
%         figure;
%         hexscatter(E, S,'res',scres,'xlim', [-0.1 1.1],'ylim',[-0.1 1.1])
%         xlabel('E')
%         ylabel('S')
%         xlim([-0.1 1.1])
%         ylim([-0.1 1.1])
    end
    
    figure;
    xf=8;
    xi=0;
    optM=20;
    dx=(xf-xi)/(optM-1);
    edges{1}=[xi:dx:xf]; % bin for x axis
    [nTau,cTau] = hist(tauD,edges{1});
    NiceTauHist(cTau,nTau,FileName(1:end-4),strcat(PathName,FileName(1:end-4),'_tau'),1);
    
    co=mean(tauD)
    wo=std(tauD)
    Ao=sum(nTau)
    modelParam0=[co wo Ao]
    numG=length(co);
    lb=zeros(length(modelParam0));
    ub=Inf(size(modelParam0));
    %Solver properties
    maxiter=5000;
    maxfunevals=5000;
    tolfun=1e-8;
    tolx=1e-8;
    lsqOpt=[maxiter maxfunevals tolfun tolx];
    
    %Set options for solver
    %lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
    options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');
    
    [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcntau,modelParam0,lb,ub,options);
    myx=linspace(min(cTau),max(cTau),100);
    [myfun]=MakeGauss(modelParam);
    hold on
    plot(myx,myfun,'-k','LineWidth',2)
    
    fittau=modelParam(1:length(co))
    fittauwo=modelParam(length(co)+1:2*length(co))
    fitAo=modelParam(2*length(co)+1:end)
    
    mTau=mean(tauD)
    
    mrd=mean(rD)
    
    mTau2=sum(nTau.*cTau)/sum(nTau)
    
    fid1=fopen(strcat(PathName,FileName,'_DonlyBursts.log'),'a+');
    fprintf(fid1,'----------\r\n')
    fprintf(fid1,datestr(datetime))
    fprintf(fid1,'Donor Only Bursts \r\n')
    fprintf(fid1,'%g bursts \r\n',length(tauD))
    fprintf(fid1,'Fit to Gaussian Tau= %f \r\n',fittau)
    mTau1=mean(tauD)
    mtau2=sum(Fd.*tauD)/sum(Fd)
    mtau3=sum(Fd.*(tauD.^2)/sum(Fd.*tauD))
    fprintf(fid1,'Simple Mean Donor MLE Tau=%f \r\n',nanmean(tauD))
    fprintf(fid1,'Fd Weighted MLE Tau=%f \r\n',mtau2)
    fprintf(fid1,'Fd/Intensity Weighted MLE Tau=%f \r\n',mtau3)
    fprintf(fid1,'Method 1: Leakage from E of Donor Only = %f \r\n',l)
    fprintf(fid1,'Method 2 (best): Leakage from E of Donor Only = %f \r\n',l2)
    fprintf(fid1,'Method 3: Leakage from E of Donor Only = %f \r\n',l3)
    fprintf(fid1,'Mean rD = %f \r\n',mrd)
    
    testytest=mean(mTauD)
end




meanBurstWidth=mean(bdur)*1000 %in ms

fprintf(fid,'Mean burst duration (ms)=%f\r\n',meanBurstWidth)


NburstsRem=length(E)
SelectRatePercent=100*NburstsRem/Nbursts

fprintf(fid,'Bursts remaining=%f, Select Percent=%f \r\n',NburstsRem,SelectRatePercent)
fprintf(fid,'Mean Fd+Fa = %f \r\n',mean(Fd+Fa))
fprintf(fid,'Mean Faa = %f \r\n',mean(Faa))

xf=1.1;
xi=-0.1;
optM = optBINS(E(E>=xi & E<=xf)',25);
optM=20;
dx=(xf-xi)/(optM-1);

% edges{1}=[xi:dx:xf]; % bin for x axis
% [nEraw,cEraw] = hist(E,edges{1});
% % NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4)))
% NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4),'_Ecor'),0);
% 
% xf=1.1;
% xi=-0.1;
% % optM = optBINS(E',25);
% dx=(xf-xi)/(optM-1);
% edges{1}=[xi:dx:xf]; % bin for x axis
% [nSraw,cSraw] = hist(S,edges{1});
% NiceEHist(cSraw,nSraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4),'_S_cor'),1);

if FRET 
    
%% Apply corrections
if 1
[E] = correct_E_gamma_leak_dir(Fd,Fa,Faa,gamma,Lk,di,corrFlag);
[S] = correct_Stoich_gamma_leak_dir(Fd,Fa,Faa,gamma,Lk,di,corrFlag);
[Epr] = correct_E_gamma_leak_dir(Fd,Fa,Faa,1,Lk,di,corrFlag);
[Spr] = correct_Stoich_gamma_leak_dir(Fd,Fa,Faa,1,Lk,di,corrFlag);
end    
    
% figure;
% scatter(E,1./S)
% xlabel('E')
% ylabel('1/S')

figure;
[edgesX2,edgesY2,N] =ndhist(bstart ,E,'axis',[min(bstart) max(bstart) -0.1 1.1],'filter',h_kde,'binsx',1,'binsy',1,'log');
xlabel('bstart')
ylabel('E')



figure;
[edgesX2,edgesY2,N] =ndhist(E ,S,'axis',[-0.1 1.05 -0.1 1.1],'filter',h_kde,'binsx',1,'binsy',1);
xlabel('E')
ylabel('S')
xlim([-0.1 1.1])
ylim([-0.1 1.1])
title('E vs S after filtering')
save('ES','edgesX2','edgesY2','N')
    
figure;
[edgesX2,edgesY2,N] =ndhist(E,(Txd-Txa)*1000,'axis',[Elim -0.5 0.5],'filter',h_kde,'binsx',1,'binsy',1);
axis tight
% title('E vs Txd-Txa before filter')
set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'on' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
 
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_ETxDTxa_pre'))

figure;
[edgesX2,edgesY2,N] =ndhist((Tdd-Tad)*1000,(Txd-Txa)*1000,'axis',[-0.5 0.5 -0.5 0.5],'filter',h_kde,'binsx',1,'binsy',1);
xlabel('Tdd-Tad')
ylabel('Tx-Txa')   

figure;
[edgesX2,edgesY2,N] =ndhist(E,1E6*bdur./(gamma*Fd+Fa),'axis',[Elim 0 60],'filter',h_kde,'binsx',1,'binsy',1);
xlabel('E')
ylabel('Interph(gammaweighted)')


figure;
[edgesX2,edgesY2,N] =ndhist(E,bdur*1000,'axis',[Elim 0 5],'filter',h_kde,'binsx',1,'binsy',1);
xlabel('E')
ylabel('bdur')   

figure;
[edgesX2,edgesY2,N] =ndhist(E,Fa+gamma*Fd,'axis',[Elim 0 150],'filter',h_kde,'binsx',1,'binsy',1);
xlabel('E')
ylabel('Fa+gamma*Fd')

% if nnz(mTauA)>1
% figure;
% [edgesX2,edgesY2,N] =ndhist(E,mTauD,'axis',[Elim 0 6],'filter',h_kde,'binsx',1,'binsy',1);
% xlabel('E')
% ylabel('mTauD') 
% 
% figure;
% [edgesX2,edgesY2,N] =ndhist(E,mTauA,'axis',[Elim 0 6],'filter',h_kde,'binsx',1,'binsy',1);
% xlabel('E')
% ylabel('mTauA') 
% 
% figure;
% [edgesX2,edgesY2,N] =ndhist(S,mTauA,'axis',[Slim 0 5],'filter',h_kde,'binsx',1,'binsy',1);
% xlabel('S')
% ylabel('mTauA')
% title('Is it PIFE?')
% 
% figure;
% [edgesX2,edgesY2,N] =ndhist(S,tauD,'axis',[Slim 0 5],'filter',h_kde,'binsx',1,'binsy',1);
% xlabel('S')
% ylabel('MLE TauD')
% title('Is it PIFE?')
% 
% figure;
% [edgesX2,edgesY2,N] =ndhist(E,mTauA-mTauD,'axis',[Elim -1 6],'filter',h_kde,'binsx',1,'binsy',1);
% xlabel('E')
% ylabel('mTauA-mtauD') 
% end

% % if any(rA)
% % figure;
% % [edgesX2,edgesY2,N] =ndhist(E,rA,'axis',[Elim -0.2 0.4],'filter',h_kde,'binsx',1,'binsy',1);
% % xlabel('E')
% % ylabel('rA') 
% % end

if any(rD)
figure;
[edgesX2,edgesY2,N] =ndhist(tauD,rD,'axis',[0 5 -0.2 0.4],'filter',h_kde,'binsx',1,'binsy',1);
xlabel('\tau')
ylabel('rD') 


figure;
[edgesX2,edgesY2,N] =ndhist(E,rD,'axis',[Elim -0.2 0.4],'filter',h_kde,'binsx',1,'binsy',1,'log');
xlabel('E')
ylabel('rD')

figure;
[edgesX2,edgesY2,N] =ndhist(E,rD,'axis',[Elim -0.2 1],'filter',h_kde,'binsx',1,'binsy',1,'log');
xlabel('E')
ylabel('rD')

end
    
mrd=mean(rD)
mra=mean(rA)
% figure;
% [n1,c1]=hist(E(1E6*bdur./(gamma*Fd+Fa) < 0.5*mean(1E6*bdur./(gamma*Fd+Fa))),linspace(0,1,30));
% [n2,c2]=hist(E(1E6*bdur./(gamma*Fd+Fa) > 1.5*mean(1E6*bdur./(gamma*Fd+Fa))),linspace(0,1,30));
% hold all
% plot(c1,n1/sum(n1),'-o')
% plot(c2,n2/sum(n2),'-s')
% legend('Short interph','long interph time')


% return

% tauD_low=tauD(Epr<E_max_low);
% tauD_high=tauD(Epr>E_min_high);
% tauA_low=mTauA(Epr<E_max_low);
% tauA_high=mTauA(Epr>E_min_high);
% 
% S_low=S(Epr<E_max_low);
% S_high=S(Epr>E_min_high);
% 
% figure;
% edges=linspace(-0.1,1.1,30);
% [n,c]=hist(S_low,edges);
% bar(c,n,1,'FaceColor','r')
% hold all
% f = fit(c(:),n(:),'gauss1')
% fitmeanS_low=f.b1
% plot(f);
% title('S low FRET')
% 
% figure;
% edges=linspace(-0.1,1.1,30);
% [n,c]=hist(S_high,edges);
% bar(c,n,1,'FaceColor','r')
% hold all
% f = fit(c(:),n(:),'gauss1')
% fitmeanS_high=f.b1
% plot(f);
% title('S high FRET')


% figure;
% edges=linspace(0,6,30);
% [n,c]=hist(tauD_low,edges);
% bar(c,n,1,'FaceColor','r')
% hold all
% f = fit(c(:),n(:),'gauss1')
% fitmean_low=f.b1
% plot(f);
% title('tauD low FRET')
% 
% figure;
% edges=linspace(0,6,30);
% [n,c]=hist(tauD_high,edges);
% bar(c,n,1,'FaceColor','r')
% hold all
% f = fit(c(:),n(:),'gauss1')
% fitmeanD_high=f.b1
% plot(f);
% title('tauD high FRET')
% 
% figure;
% edges=linspace(0,6,30);
% [n,c]=hist(tauA_low,edges);
% bar(c,n,1,'FaceColor','r')
% hold all
% f = fit(c(:),n(:),'gauss1')
% fitmeanA_low=f.b1
% plot(f);
% title('tauA low FRET')
% 
% figure;
% edges=linspace(0,6,30);
% [n,c]=hist(tauA_high,edges);
% bar(c,n,1,'FaceColor','r')
% hold all
% f = fit(c(:),n(:),'gauss1')
% fitmeanA_high=f.b1
% plot(f);
% title('tauA high FRET')

% 
% mDelTau=nanmean(mTauA-mTauD)
% mDelTau1=nanmean(mTauA(E<0.4)-mTauD(E<0.4))
% mDelTau2=nanmean(mTauA(E>0.55)-mTauD(E>0.55))
%     
% 
% fprintf(fid,'First Moment Donor Delay Times=%f \r\n',nanmean(mTauD))
% fprintf(fid,'First Moment Acceptor Delay Times=%f \r\n',nanmean(mTauA))
% fprintf(fid,'First Moment Donor-Acceptor Delay Times=%f \r\n',nanmean(mTauA-mTauD))
% 
mTau1=mean(tauD)
mtau2=sum(Fd.*tauD)/sum(Fd)
mtau3=sum(Fd.*(tauD.^2)/sum(Fd.*tauD))
fprintf(fid,'Simple Mean Donor MLE Tau=%f \r\n',nanmean(tauD))
fprintf(fid,'Fd Weighted MLE Tau=%f \r\n',mtau2)
fprintf(fid,'Fd/Intensity Weighted MLE Tau=%f \r\n',mtau3)
% 
% 
% 
%     
xf=8;
xi=0;
% optM = optBINS(E',25);
dx=(xf-xi)/(optM-1);
edges{1}=[xi:dx:xf]; % bin for x axis
[nTau,cTau] = hist(tauD,edges{1});
NiceTauHist(cTau,nTau,FileName(1:end-4),strcat(PathName,FileName(1:end-4),'_tau'),1);

co=mean(tauD)
wo=std(tauD)
Ao=sum(nTau)
modelParam0=[co wo Ao]
numG=length(co);
lb=zeros(length(modelParam0));
ub=Inf(size(modelParam0));
 
[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcntau,modelParam0,lb,ub,options);
myx=linspace(min(cTau),max(cTau),100);
[myfun]=MakeGauss(modelParam);
hold on
plot(myx,myfun,'-k','LineWidth',2)
fittau=modelParam(1:length(co))
fittauwo=modelParam(length(co)+1:2*length(co))
fitAo=modelParam(2*length(co)+1:end)    
hold off    

fprintf(fid,'Fit to MLE Tau Histogram w/ Gaussian \r\n')
for i=1:length(fittau)
    fprintf(fid,'%g: Center = %f \r\n',i,fittau(i))
    fprintf(fid,'%g: Width  = %f \r\n',i,fittauwo(i))
    fprintf(fid,'%g: Area  = %f \r\n',i,fitAo(i))
end


% save('ForRasp','E','bstart','bend')

save(savetitle,'E')

%% One dimensional E histograms

xf=1.1;
xi=-0.1;
optM = optBINS(E(E>=xi & E<=xf)',100);
dx=(xf-xi)/(Ebins-1);
edges=[xi:dx:xf]; % bin for x axis
[nEraw,cEraw] = hist(E(E>xi),edges);
% NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4)))
hfig=NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4),'_Ecor'),0);
% parmhat=lognfit(nEraw)
numG=length(Eco);

EAo=[];
for i=1:length(Ewo)
EAo=[EAo max(nEraw)*Ewo(i)*sqrt(pi/2)];
end
modelParam0=[Eco Ewo EAo];
lb=[lbEc zeros(1,length(modelParam0)-length(lbEc))];
ub=[ubEc Inf(size(Ewo)) Inf(size(EAo))];


[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnE,modelParam0,lb,ub,options);
% [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnElogn,modelParam0,lb,ub,options);

fitE=modelParam(1:length(Eco))
fitEwo=modelParam(length(Eco)+1:2*length(Eco))
fitEAo=modelParam(2*length(Eco)+1:end)

myx=linspace(min(cEraw),max(cEraw),100);
figure(hfig);
hold on

for i=1:length(fitE)
numG=1; %I know - this is so hacky. But MakeGauss needs to know how many Gaussians you gave it - and Im  a bad programmer who uses global variables    
[myfun]=MakeGauss([fitE(i) fitEwo(i) fitEAo(i)]);
% myfun=makelogn(modelParam);
plot(myx,myfun,'-k','LineWidth',lw_Ehist)
end

yl=ylim(gca);
% plot(repmat(fitE(1),1,100),linspace(yl(1),yl(2),100),'Color',[0 0 128]/256,'LineWidth',3)

wshot=2*sqrt((fitE.*(1-fitE))/L)
extraw=fitEwo./wshot
modelParamShot=[fitE wshot max(myfun)*wshot*sqrt(pi/2)]

% if ~isempty(myYlim)
% set(gca,'Ylim',[0 myYlim])
% end
xlabel(gca,'')
ylabel(gca,'')
set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'on' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
 
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2

hold off
figure(hfig)
print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_Efit'))

% hold off
% figure(hfig)
% print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_Efit'))
fprintf(fid,'Fit to E Histogram w/ Gaussian(s) \r\n')
for i=1:length(fitE)
    fprintf(fid,'%g: Center = %f \r\n',i,fitE(i))
    RDA=Ro*((1-fitE(i))/fitE(i))^(1/6);
    fprintf(fid,'%g: Simple R = %f with Ro=%f \r\n',i,RDA,Ro)
    fprintf(fid,'%g: Width  = %f \r\n',i,fitEwo(i))
    fprintf(fid,'%g: Area  = %f \r\n',i,fitEAo(i))
end



%% One d s

xf=1.1;
xi=-0.1;
% optM = optBINS(E(E>=xi & E<=xf)',25);
dx=(xf-xi)/(Ebins-1);
edges=[xi:dx:xf]; % bin for x axis
[nEraw,cEraw] = hist(S(S>xi),edges);
% NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4)))
hfig=NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4),'_Scor'),0);
% parmhat=lognfit(nEraw)
numG=length(Eco);


EAo=[];
for i=1:length(Ewo)
EAo=[EAo max(nEraw)*Ewo(i)*sqrt(pi/2)];
end
modelParam0=[Eco Ewo EAo];
lb=[lbEc zeros(1,length(modelParam0)-length(lbEc))];
ub=[ubEc Inf(size(Ewo)) Inf(size(EAo))];

[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnE,modelParam0,lb,ub,options);
% [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnElogn,modelParam0,lb,ub,options);

fitE=modelParam(1:length(Eco))
fitEwo=modelParam(length(Eco)+1:2*length(Eco))
fitEAo=modelParam(2*length(Eco)+1:end)

myx=linspace(min(cEraw),max(cEraw),100);
figure(hfig);
hold on

for i=1:length(fitE)
numG=1; %I know - this is so hacky. But MakeGauss needs to know how many Gaussians you gave it - and Im  a bad programmer who uses global variables    
[myfun]=MakeGauss([fitE(i) fitEwo(i) fitEAo(i)]);
% myfun=makelogn(modelParam);
plot(myx,myfun,'-k','LineWidth',lw_Ehist)
end
xlabel('S')



save('ESvec','E','S','tauD')
save('ToRecolor','Fd','Fa','bdur')
















% return
% % % x=[fitE(1) fitE(2)];
% % % 
% % % y=1./[fitmeanS_low fitmeanS_high];
% % % 
% % % A=[x;ones(1,length(x))];
% % % p=y/A;
% % % mfit=p(1);
% % % bfit=p(2);
% % % 
% % % f=p*A; %the best fit function using best fit m and b
% % % % 
% % % % figure;
% % % % hold all
% % % % plot(E,1./S,'o')
% % % % plot(E,f)
% % % 
% % % gammaES=(bfit-1)/(bfit+mfit-1)

% return

% [Rg0,EGC,ESAW,EWLC,TauDAavGC,TauDAavSAW,TauDAavWLC]=GetDynAvgLines(Ro,tauD0,Nr,coeff);




% for i=1:length(fitE)
% sprintf('-----------------------------\r\n')
% sprintf('-----------------------------\r\n')
% sprintf('-----------------------------\r\n')
% sprintf('The mean E %g is %f \r\n',i,fitE(i))
% RDA=Ro*((1-fitE(i))/fitE(i))^(1/6);
% sprintf('Using static FRET equation RDA is %f \r\n',RDA)
% end
% sprintf('-----------------------------\r\n')
% sprintf('-----------------------------\r\n')



%% Temporaray plotting space

% figure;
% scatter(E,bdur)
% 
% figure;
% scatter(E,Txd-Txa)
% 
% figure;
% scatter(E,Fd+Fa)
% 
% figure;
% scatter(Fd,Fa)
% hold all
% scatter(Fd(E>0.8),Fa(E>0.8))
% 
% figure;
% scatter(E,rD)
% % % % % % return
% 
% % figure;
% % scatter(bstart,E)
% return


%% Multiparameter histograms below . .. . 


%% E vs S histograms

% figure;
% scatter(E,S)
% xlabel('E')
% ylabel('S')
% figure;
% hexscatter(E, S,'res',scres,'xlim', [-0.1 1.1],'ylim',[-0.1 1.1])
% xlabel('E')
% ylabel('S')
% xlim([-0.1 1.1])
% ylim([-0.1 1.1])

% figure;
% [edgesX2,edgesY2,N] =ndhist(E ,S,'axis',[-0.1 1.05 -0.1 1.1],'filter',h_kde,'binsx',1,'binsy',1);
% xlabel('E')
% ylabel('S')
% xlim([-0.1 1.1])
% ylim([-0.1 1.1])
% 
% figure; 
% [Cm,hCont]=contourf(edgesX2,edgesY2,N,5);
% cm=flipud(gray);
% colormap(cm);
% xlabel('E')
% ylabel('S')
% xlim([-0.1 1.1])
% ylim([-0.1 1.1])
% hold on

%% E vs Tau histograms

% figure;
% scatter(E,tauD)
% xlabel('E')
% ylabel('tauD')

[Rg0,EGC,ESAW,EWLC,TauDAavGC,TauDAavSAW,TauDAavWLC]=GetDynAvgLines(Ro,tauD0,Nr,coeff);
LimSAW=5;
% ESAW(Rg0>LimSAW)=[];
% TauDAavSAW(Rg0>LimSAW)=[];
% TauRAT=TauDAavGC./tauD0;
TauRAT=TauDAavSAW./tauD0;
Ep=ESAW;

figure;
plot(Rg0*6.26,ESAW);
xlabel('Rsaw')
ylabel('ESAW')

figure;
plot(Rg0*6.26,TauRAT);
xlabel('Rsaw')
ylabel('Esaw')

lw=3;
if DNA
[ mE1,rat1] = GenerateStaticFRETLine(Ro_DNA1,TauDO_DNA1,sigma_DNA1); %for the DNA samples
[ mE2,rat2] = GenerateStaticFRETLine(Ro_DNA2,TauDO_DNA2,sigma_DNA2);
% [ mE1,rat1] = GenerateStaticFRETLine(Ro_DNA1,3.7519,8.6); %for the DNA samples
% [ mE2,rat2] = GenerateStaticFRETLine(54.792,3.7519,11.1);
end
% figure;
% hexscatter(E, tauD/tauD0,'res',scres,'xlim', [-0.1 1.05],'ylim',[-0.1 1.05])
% hold all
% plot(EGC,TauDAavGC/tauD0,'r','LineWidth',lw)
% plot(EGC,1-EGC,'k','LineWidth',lw)
% % plot(mE1,rat1,'r','LineWidth',lw)
% % plot(mE2,rat2,'g','LineWidth',lw)
% % plot(ESAW,TauDAavSAW/tauD0,'b','LineWidth',lw)
% xlabel('E')
% ylabel('tau/tauD0')
% xlim([-0.1 1.05])
% ylim([-0.1 1.05])

% tauD=tauD(E>0.5);
% E=E(E>0.5);

figure;
[edgesX2,edgesY2,N] =ndhist(E,tauD/tauD0,'axis',[-0.1 1.05 -0.1 1.2],'binsx',1,'binsy',1,'filter',h_kde,'log');
hold all
if DNA
plot(mE1,rat1,'r','LineWidth',lw)
plot(mE2,rat2,'g','LineWidth',lw)
else
plot(EGC,TauDAavGC/tauD0,'r','LineWidth',lw)
plot(EGC,1-EGC,'k','LineWidth',lw)        
end


% plot(ESAW,TauDAavSAW/tauD0,'b','LineWidth',lw)
xlabel('E')
ylabel('tau/tauD0')
xlim([-0.1 1])
ylim([-0.1 1])
title('E vs lifetime log')


figure;
[edgesX2,edgesY2,N] =ndhist(E,tauD/tauD0,'axis',[-0.1 1.05 -0.1 1.2],'binsx',1,'binsy',1,'filter',h_kde);
hold all
if DNA
plot(mE1,rat1,'r','LineWidth',lw)
plot(mE2,rat2,'g','LineWidth',lw)
else
plot(EGC,TauDAavGC/tauD0,'r','LineWidth',lw)
plot(EGC,1-EGC,'k','LineWidth',lw)        
end


% plot(ESAW,TauDAavSAW/tauD0,'b','LineWidth',lw)
xlabel('E')
ylabel('tau/tauD0')
xlim([-0.1 1])
ylim([-0.1 1])

save('Etau','edgesX2','edgesY2','N')

figure;
subplot(2,2,2); 
[Cm,hCont]=contourf(edgesX2,edgesY2,N,5);
cm=flipud(gray);
colormap(cm);
hold on

if DNA
plot(mE1,rat1,'r','LineWidth',lw)
plot(mE2,rat2,'g','LineWidth',lw)
else
plot(EGC,TauDAavGC/tauD0,'r','LineWidth',lw)
plot(EGC,1-EGC,'k','LineWidth',lw)        
end

% plot(EGC,TauDAavGC/tauD0,'r','LineWidth',lw)
% plot(EGC,1-EGC,'k','LineWidth',lw)
% plot(mE1,rat1,'r','LineWidth',lw)
% plot(mE2,rat2,'g','LineWidth',lw)
% plot(ESAW,TauDAavSAW/tauD0,'b','LineWidth',lw)

h1=gca;
% hXLabel = xlabel('E');
% hYLabel = ylabel('\tau_{DA}/\tau');
hXLabel = xlabel('');
hYLabel = ylabel('');
set( gca                       , ...
    'FontSize'   , fsa          ,...
    'FontName'   , 'Helvetica' );
set([hXLabel, hYLabel], ...
    'FontName'   , 'Helvetica');
set([hXLabel, hYLabel]  , ...
    'FontSize'   , fs          );
% hMain=gca;
set(gca, ...
  'Box'         , 'on'     , ...
  'TickDir'     , 'in'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'      , ...
  'YMinorTick'  , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'XColor'      , [.1 .1 .1], ...
  'YColor'      , [.1 .1 .1], ...
  'YTick'       , [0:0.2:1], ...
  'XTick'       , [0:0.2:1], ...
  'LineWidth'   , 1         );
getxlim=xlim();
getylim=ylim();
subplot(2,2,4);
bar(edgesX2(1:end),sum(N,1),1,'FaceColor', 'k');
axis tight
hx = gca; 
xlim(getxlim); %links the x axis to that of the contour plot
set(gca, ...
    'Box'         , 'on'     , ...
    'TickDir'     , 'in'     , ...
    'TickLength'  , [.02 .02] , ...
    'XMinorTick'  , 'off'      , ...
    'YMinorTick'  , 'off'      , ...
    'YGrid'       , 'off'      , ...
    'XColor'      , [.1 .1 .1], ...
    'YColor'      , [.1 .1 .1], ...
    'XTick'       , [0:0.2:1], ...
    'XTickLabel'  , [], ...
    'LineWidth'   , 1         );
%     'YTick'       , [500 1500], ... 
set( gca                       , ...
    'FontSize'   , fsa          ,...
    'FontName'   , 'Helvetica' );
subplot(2,2,1); 
hold on
barh(edgesY2,sum(N,2),1,'FaceColor', 'k'); 
axis tight
hy = gca; 
ylim(getylim)
tmp=xlim(gca);
x_lim=tmp(2);
set(gca, ...
  'Box'         , 'on'     , ...
  'TickDir'     , 'in'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'off'      , ...
  'YMinorTick'  , 'off'      , ...
  'YGrid'       , 'off'      , ...
  'XColor'      , [.1 .1 .1], ...
  'YColor'      , [.1 .1 .1], ...
  'YTick'       , [0:0.1:1], ... 
  'YTickLabel'  , [], ...
  'LineWidth'   , 1         );
%     'XTick'       , [500 1500], ... 
set( gca                       , ...
    'FontSize'   , fsa          ,...
    'FontName'   , 'Helvetica' );
% [left bottom width height]The left and bottom elements define the 
%distance from the lower-left corner of the container to the lower-left 
%corner of the axes. The width and height elements are the axes dimensions.
L= 0.15; %left
B= 0.15; %bottom
W= 0.6; %2d histogram width (shared with marginal x width)
H=0.6; %2d histogram heigh (shared with marginal y height)
mH=0.17; %marginal histogram height
gapv=0.01;
gaph=0.01;
set(h1,'Position',[L B W H]); %main 2d histogram and overlay
%x marginal histogram shares its left edge with 2d hist and has same width
set(hx,'Position',[L B+H+gapv W mH]); 
%y marginal histogram shares its bottom edge with 2d hist and has same
%height
set(hy,'Position',[L+W+gaph B mH H]); %y marginal histogram
set(gcf, 'PaperPositionMode', 'manual');
set(gcf,'PaperUnits','inches');
papersizex=6;
papersizey=5;
marginx=0.5;
marginy=0.5;
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
           papersizey-2*(marginy)]);
set(gcf, 'color', 'w');
print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_EvsTau'))


% % % % % figure;
% % % % % [edgesX2,edgesY2,N] =ndhist(Epre,Taupre/tauD0,'axis',[-0.1 1.05 -0.1 1.2],'binsx',1,'binsy',1,'filter',h_kde);
% % % % % hold all
% % % % % if DNA
% % % % % plot(mE1,rat1,'r','LineWidth',lw)
% % % % % plot(mE2,rat2,'g','LineWidth',lw)
% % % % % else
% % % % % plot(EGC,TauDAavGC/tauD0,'r','LineWidth',lw)
% % % % % plot(EGC,1-EGC,'k','LineWidth',lw)        
% % % % % end
% % % % % 
% % % % % 
% % % % % % plot(ESAW,TauDAavSAW/tauD0,'b','LineWidth',lw)
% % % % % xlabel('E')
% % % % % ylabel('tau/tauD0')
% % % % % xlim([-0.1 1])
% % % % % ylim([-0.1 1])
% % % % % 
% % % % % 
% % % % % figure;
% % % % % subplot(2,2,2); 
% % % % % [Cm,hCont]=contourf(edgesX2,edgesY2,N,15);
% % % % % cm=flipud(gray);
% % % % % colormap(cm);
% % % % % hold on
% % % % % 
% % % % % if DNA
% % % % % plot(mE1,rat1,'r','LineWidth',lw)
% % % % % plot(mE2,rat2,'g','LineWidth',lw)
% % % % % else
% % % % % plot(EGC,TauDAavGC/tauD0,'r','LineWidth',lw)
% % % % % plot(EGC,1-EGC,'k','LineWidth',lw)        
% % % % % end
% % % % % 
% % % % % % plot(EGC,TauDAavGC/tauD0,'r','LineWidth',lw)
% % % % % % plot(EGC,1-EGC,'k','LineWidth',lw)
% % % % % % plot(mE1,rat1,'r','LineWidth',lw)
% % % % % % plot(mE2,rat2,'g','LineWidth',lw)
% % % % % % plot(ESAW,TauDAavSAW/tauD0,'b','LineWidth',lw)
% % % % % 
% % % % % h1=gca;
% % % % % % hXLabel = xlabel('E');
% % % % % % hYLabel = ylabel('\tau_{DA}/\tau');
% % % % % hXLabel = xlabel('');
% % % % % hYLabel = ylabel('');
% % % % % set( gca                       , ...
% % % % %     'FontSize'   , fsa          ,...
% % % % %     'FontName'   , 'Helvetica' );
% % % % % set([hXLabel, hYLabel], ...
% % % % %     'FontName'   , 'Helvetica');
% % % % % set([hXLabel, hYLabel]  , ...
% % % % %     'FontSize'   , fs          );
% % % % % % hMain=gca;
% % % % % set(gca, ...
% % % % %   'Box'         , 'on'     , ...
% % % % %   'TickDir'     , 'in'     , ...
% % % % %   'TickLength'  , [.02 .02] , ...
% % % % %   'XMinorTick'  , 'off'      , ...
% % % % %   'YMinorTick'  , 'off'      , ...
% % % % %   'YGrid'       , 'off'      , ...
% % % % %   'XColor'      , [.1 .1 .1], ...
% % % % %   'YColor'      , [.1 .1 .1], ...
% % % % %   'YTick'       , [0:0.2:1], ...
% % % % %   'XTick'       , [0:0.2:1], ...
% % % % %   'LineWidth'   , 1         );
% % % % % getxlim=xlim();
% % % % % getylim=ylim();
% % % % % subplot(2,2,4);
% % % % % bar(edgesX2(1:end),sum(N,1),1,'FaceColor', 'k');
% % % % % axis tight
% % % % % hx = gca; 
% % % % % xlim(getxlim); %links the x axis to that of the contour plot
% % % % % set(gca, ...
% % % % %     'Box'         , 'on'     , ...
% % % % %     'TickDir'     , 'in'     , ...
% % % % %     'TickLength'  , [.02 .02] , ...
% % % % %     'XMinorTick'  , 'off'      , ...
% % % % %     'YMinorTick'  , 'off'      , ...
% % % % %     'YGrid'       , 'off'      , ...
% % % % %     'XColor'      , [.1 .1 .1], ...
% % % % %     'YColor'      , [.1 .1 .1], ...
% % % % %     'XTick'       , [0:0.2:1], ...
% % % % %     'XTickLabel'  , [], ...
% % % % %     'LineWidth'   , 1         );
% % % % % %     'YTick'       , [500 1500], ... 
% % % % % set( gca                       , ...
% % % % %     'FontSize'   , fsa          ,...
% % % % %     'FontName'   , 'Helvetica' );
% % % % % subplot(2,2,1); 
% % % % % hold on
% % % % % barh(edgesY2,sum(N,2),1,'FaceColor', 'k'); 
% % % % % axis tight
% % % % % hy = gca; 
% % % % % ylim(getylim)
% % % % % tmp=xlim(gca);
% % % % % x_lim=tmp(2);
% % % % % set(gca, ...
% % % % %   'Box'         , 'on'     , ...
% % % % %   'TickDir'     , 'in'     , ...
% % % % %   'TickLength'  , [.02 .02] , ...
% % % % %   'XMinorTick'  , 'off'      , ...
% % % % %   'YMinorTick'  , 'off'      , ...
% % % % %   'YGrid'       , 'off'      , ...
% % % % %   'XColor'      , [.1 .1 .1], ...
% % % % %   'YColor'      , [.1 .1 .1], ...
% % % % %   'YTick'       , [0:0.1:1], ... 
% % % % %   'YTickLabel'  , [], ...
% % % % %   'LineWidth'   , 1         );
% % % % % %     'XTick'       , [500 1500], ... 
% % % % % set( gca                       , ...
% % % % %     'FontSize'   , fsa          ,...
% % % % %     'FontName'   , 'Helvetica' );
% % % % % % [left bottom width height]The left and bottom elements define the 
% % % % % %distance from the lower-left corner of the container to the lower-left 
% % % % % %corner of the axes. The width and height elements are the axes dimensions.
% % % % % L= 0.15; %left
% % % % % B= 0.15; %bottom
% % % % % W= 0.6; %2d histogram width (shared with marginal x width)
% % % % % H=0.6; %2d histogram heigh (shared with marginal y height)
% % % % % mH=0.17; %marginal histogram height
% % % % % gapv=0.01;
% % % % % gaph=0.01;
% % % % % set(h1,'Position',[L B W H]); %main 2d histogram and overlay
% % % % % %x marginal histogram shares its left edge with 2d hist and has same width
% % % % % set(hx,'Position',[L B+H+gapv W mH]); 
% % % % % %y marginal histogram shares its bottom edge with 2d hist and has same
% % % % % %height
% % % % % set(hy,'Position',[L+W+gaph B mH H]); %y marginal histogram
% % % % % set(gcf, 'PaperPositionMode', 'manual');
% % % % % set(gcf,'PaperUnits','inches');
% % % % % papersizex=6;
% % % % % papersizey=5;
% % % % % marginx=0.5;
% % % % % marginy=0.5;
% % % % % set(gcf, 'PaperSize', [papersizex papersizey]);
% % % % % set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
% % % % %            papersizey-2*(marginy)]);
% % % % % set(gcf, 'color', 'w');
% % % % % print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_EvsTau_bad'))

%% Tau vs anisotropy histograms

figure;
[edgesX2,edgesY2,N] =ndhist(tauD,rD,'axis',[0 5 -0.2 0.6],'binsx',1,'binsy',1,'filter',h_kde);
hold all

taux=linspace(0,9);
rper=zeros(size(taux));

rho=[0.3669 1.8765]
fr=[0.6453 (1-0.6453)]

for i=1:length(fr)
rper=rper+(fr(i)./(1+(taux/rho(i))));
end
rper=rper*0.37;

rper2=zeros(size(taux));

rho=[0.739 6.572]
fr=[0.632 (1-0.632)]

for i=1:length(fr)
rper2=rper2+(fr(i)./(1+(taux/rho(i))));
end
rper2=rper2*0.37;

hold all
plot(taux,rper,'-r','linewidth',lw)
plot(taux,rper2,'-g','linewidth',lw)

% taux=0:0.1:6;
% rper=0.4./(1+(taux/rho));
% plot(taux,rper,'r','linewidth',lw)
% xlabel('tauD')
% ylabel('rD')
figure;
[Cm,hCont]=contourf(edgesX2,edgesY2,N,5);
cm=flipud(gray);
colormap(cm);
% hold on
% plot(taux,rper,'r','linewidth',lw)
% xlabel('tauD')
% ylabel('rD')
% print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_TauDrD'))


hold all
plot(taux,rper,'-r','linewidth',lw)
plot(taux,rper2,'-g','linewidth',lw)

xlim([0 5])
ylim([0 0.45])

set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'on' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
 
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_tauDrd'))



if EXTRA
figure;
[edgesX2,edgesY2,N] =ndhist(E,rD,'axis',[0 1 -0.2 0.6],'binsx',1,'binsy',1,'filter',h_kde);
hold all
xlabel('E')
ylabel('rD')
figure;
[Cm,hCont]=contourf(edgesX2,edgesY2,N,5);
cm=flipud(gray);
colormap(cm);
hold on
xlabel('E')
ylabel('rD')
end

end



%% Some useful commented out ways of manipulating data that I want to keep the code but not use

% C=Fd+Fa+Faa;
% figure;
% hist(C,25)
% mC=mean(C)
% stdC=std(C)
% figure;
% hist(C(C<mC+2*stdC))
% 
% filt=(C>mC+2*stdC); % filter out multimolecular events
% E(filt)=[];
% S(filt)=[];
% Faa(filt)=[];
% Fd(filt)=[];
% Fa(filt)=[];
% Txd(filt)=[];
% Txa(filt)=[];
% Tdd(filt)=[];
% Tad(filt)=[];
% % tauD(filt)=[];
% % rD(filt)=[];
% % bdur(filt)=[];
% 
% mtau0=mean(tauD(Faa>30 & (Fd+Fa)>30 & E<0.1))
% hist(tauD(Faa>30 & (Fd+Fa)>30 & E<0.1 & tauD<5))

% figure;
% hold all
% plot(ESAW(ESAW>0.2 & ESAW<0.8),Rg0(ESAW>0.2 & ESAW<0.8))
% plot(EGC(EGC>0.2 & EGC<0.8),Rg0(EGC>0.2 & EGC<0.8))
% xlabel('Rg')
% ylabel('E')
% legend('SAW','GC')

































    function output=obj_fcn(gamma)
        %Function to minimize
        tempE=correct_E_gamma_leak_dir(Fd,Fa,Faa,gamma,Lk,di,'ALEX');
%         [nEraw,cEraw] = hist(tempE,edges{1});
%         
%         co=mean(tempE);
%         wo=std(tempE);
%         Ao=max(nEraw)*wo*sqrt(pi/2);
%         modelParam0=[co wo Ao]
%         numG=length(co);
%         lb=zeros(length(modelParam0));
%         ub=[ones(size(co)) Inf(size(wo)) Inf(size(Ao))] ;
%         %Solver properties
% %         maxiter=5000;
% %         maxfunevals=5000;
% %         tolfun=1e-8;
% %         tolx=1e-8;
% %         lsqOpt=[maxiter maxfunevals tolfun tolx];
% %         
% %         %Set options for solver
% %         %lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
% %         options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');
%         
%         [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnE,modelParam0,lb,ub,options);
%         
%         cf=modelParam(1:length(co));
%         wf=modelParam(length(co)+1:2*length(co));
%         Af=modelParam(2*length(co)+1:end);
%         mE=cf(Af==max(Af));
        
        mE=mean(tempE);

        output=abs(mE-Eobj);
        
        
        
    end

function [myfun]=objfcnE(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(1,length(cEraw));
        for j=1:length(c)
           
            y=y+(A(j)/(w(j)*sqrt(pi/2)))*exp(-2*((cEraw-c(j)).^2)/(w(j)^2));
            
            
        end
        
       
        myfun=(nEraw-y);
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
end

function [myfun]=objfcnElogn(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(1,length(cEraw));
        
           
            y=y+(A./(cEraw*w*sqrt(2*pi))).*exp(-((log(cEraw)-c).^2)/(2*(w)^2));
            
            
       
        myfun=(nEraw-y);
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
end

function [myfun]=makelogn(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(1,length(myx));
        
           
            y=y+(A./(myx*w*sqrt(2*pi))).*exp(-((log(myx)-c).^2)/(2*(w)^2));
            
            
       
        myfun=y;
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
end


function [myfun]=objfcntau(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(1,length(nTau));
        for j=1:length(c)
           
            y=y+(A(j)/(w(j)*sqrt(pi/2)))*exp(-2*((cTau-c(j)).^2)/(w(j)^2));
            
            
        end
        
       
        myfun=(nTau-y);
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
end

function [myfun]=MakeGauss(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(size(myx));
        for j=1:length(c)
           
            y=y+(A(j)/(w(j)*sqrt(pi/2)))*exp(-2*((myx-c(j)).^2)/(w(j)^2));
            
            
        end
        
       
        myfun=y;
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
    end

end

