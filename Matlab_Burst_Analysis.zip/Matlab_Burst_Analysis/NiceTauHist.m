function [ ] = NiceEHist(cEraw,nEraw,titles,mytitle,tag)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
% clc;
% close all;
myOrange=[238 131 66]/256;
myRed=[232 57 55]/256;
myLiBlu=[95 173 219]/256;
myGreen=[60 147 73]/256;
myYellow=[244 232 70]/256;


% CT=cbrewer('qual', 'Dark2', 8);
CT=cbrewer('qual', 'Paired', 8);

% CT2=cbrewer('qual', 'Pastel2', 8);
CT2=cbrewer('qual', 'Pastel1', 8);
% CT2=cbrewer('qual', 'Set2', 8);

Kshade=CT2(7,:);

% col_san=myLiBlu;
% col_saw=myGreen;
% col_g=myOrange;
% col_exp=myRed;
% k=1;
% inc=1;
% col_san=CT(4,:);
% col_saw=CT(5,:);
% col_g=CT(1,:);
% col_exp=CT(2,:);

col_san=CT(1,:);
col_saw=CT(2,:);
col_g=CT(3,:);
col_exp=CT(4,:);
col_SAXS=CT(5,:);
% col_low=CT(4,:);
% col_high=CT(5,:);
lw=1;
lwfit=2;
lwsub=1;
lwfit2=1;
% names={'NewFretPair'}
% titles={'AttoRho101-Atto647N';'1 M KCl'}
cols={CT(7,:)};
cols2={CT(8,:)};
figure;

i=1;
%The top most panel;
% load(names{i})

hold all
bar(cEraw,nEraw,'BarWidth',1,'FaceColor',cols{i},'EdgeColor','k','LineWidth',lw);

% plot(fx,fy/1000,'LineWidth',lwfit,'Color','k')
% for j=1:length(fEc)
%     y=subfy(:,j);
%     x=fx(y>1);
%     y=y(y>1);
%     
%     plot(x,y/1000,'LineWidth',lwsub,'Color','k')
% end
% refmean(i)=fEc(2);
% plot(repmat(fEc(2),1,100),linspace(0,1.05*max(nEraw/1000),100),'Color',cols2{i},'LineWidth',lwfit2)
set(gca,'XTickLabel',{'0';'2';'4';'6';'8';'10'})
set(gca,'XTick',[0 2 4 6 8 10])
% ylabel('Events X $\rm 10^{3}$','Interpreter','LaTex')
xlim([0 8])
% ht(i)=title(titles)
% ht(i)=title(titles,'HorizontalAlignment','center','Interpreter','LaTex')
hyl=ylabel('Events$','Interpreter','LaTex');

hxl=xlabel('$\rm \tau (ns)$','Interpreter','LaTex');

% ylim([0 1.05*max(nEraw/1000)])
box on
h(i)=gca;

% left=0.09;
left=0.15;
bottom=0.13;
width=0.8;
height=0.8;
set(h(1),'Position',[left bottom width height]);




% savetype='-dpng';
savetype='-dpdf';
resolution='-r600';

papersizex=9;
papersizey=6;
marginx=0;
marginy=0;
fontsizeax=21;
fontsizet=20;
ticksize=25;
% offset=[0.1 0.3 0];
offset=[-0.0 0.56 0];
% offset3=[-0.3 1.5 0]
fw='normal';
i=1;
        set(h(i),'FontSize', ticksize);
        set(h(i),'FontWeight',fw);
        set(h(i),'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', 1) ;
        set(h(i), 'Box' , 'on' )
        
set(gca, 'Layer','top')
        
% if max(nEraw/1000) < 1
%     if max(nEraw/1000) < 0.1
%         
%         ytix=0:0.01:0.1;
%         set(h(i),'YTick',ytix);
%         
%         yTickLabels = cell(1,numel(ytix));  % Empty cell array the same length as xAxis
%         a=ytix(1:2:numel(ytix));
%         a=cellstr(num2str(a'))';
%         yTickLabels(1:2:numel(ytix)) = a;
%         % Fills in only the values you want
%         set(gca,'YTickLabel',yTickLabels);   % Update the tick labels
%         
%     else
%         
%         ytix=0:0.25:1;
%         set(h(i),'YTick',ytix)
%     end
%     
% elseif max(nEraw/1000)> 20
% ytix=0:10:round(max(nEraw/1000));
%     set(h(i),'YTick',ytix);
%     
%     yTickLabels = cell(1,numel(ytix));  % Empty cell array the same length as xAxis
%     a=ytix(1:2:numel(ytix));
%     a=cellstr(num2str(a'))';
%     yTickLabels(1:2:numel(ytix)) = a;
%     % Fills in only the values you want
%     set(gca,'YTickLabel',yTickLabels);   % Update the tick labels    
%     
% elseif max(nEraw/1000)> 10 && max(nEraw/1000)< 20
% ytix=0:2:round(max(nEraw/1000));
%     set(h(i),'YTick',ytix);
%     
%     yTickLabels = cell(1,numel(ytix));  % Empty cell array the same length as xAxis
%     a=ytix(1:2:numel(ytix));
%     a=cellstr(num2str(a'))';
%     yTickLabels(1:2:numel(ytix)) = a;
%     % Fills in only the values you want
%     set(gca,'YTickLabel',yTickLabels);   % Update the tick labels
% else
%     %         set(h(i),'YTick',[0 0.5 1 1.5 2 2.5 3 3.5])
%     %         set(h(i),'YTickLabel',{'0';'';'1';'';'2';'';'3';''})
%     ytix=0:0.5:round(max(nEraw/1000));
%     set(h(i),'YTick',ytix);
%     
%     yTickLabels = cell(1,numel(ytix));  % Empty cell array the same length as xAxis
%     a=ytix(1:2:numel(ytix));
%     a=cellstr(num2str(a'))';
%     yTickLabels(1:2:numel(ytix)) = a;
%     % Fills in only the values you want
%     set(gca,'YTickLabel',yTickLabels);   % Update the tick labels
%     
% end
set(get(h(i),'xlabel'),'FontSize',fontsizeax, 'FontWeight', fw...
    ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
set(get(h(i),'ylabel'),'FontSize',fontsizeax, 'FontWeight', fw...
    ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
set(get(h(i),'title'),'FontSize',fontsizet, 'FontWeight', fw...
    ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
%       origpos=get(ht(i),'position');
%       set(ht(i),'position',origpos-offset)

set(hyl, 'Units', 'Normalized', 'Position', [-0.12, 0.5, 0]);
set(hxl, 'Units', 'Normalized', 'Position', [0.5, -0.11, 0]);

set(gcf,'PaperUnits','inches');
set(gcf, 'PaperSize', [papersizex papersizey]);
set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
    papersizey-2*(marginy)]);
set(gcf, 'PaperPositionMode','manual');
set(gcf, 'color', 'w');

%  print('-painters','-dpdf',resolution,mytitle)
print('-dpdf',resolution,mytitle)
print('-dpng',resolution,mytitle)

% print('-dpng','-r150',sprintf('%s_EHist',currName));

end

