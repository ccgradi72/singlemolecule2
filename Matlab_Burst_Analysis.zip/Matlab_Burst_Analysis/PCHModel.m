function [ output_args ] = PCHModel( input_args )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
clear all
close all
clc

eps=9030;
Nm=1.28;

k=1:1:30;
y=0:0.01:100;
N=0:1:5;

pke=zeros(length(y),length(k));
for i=1:length(y)
pke(i,:)=gamma(k).*gammainc(eps*exp(-2*(y(i).^2)),k);
end


pke=sum(pke,1);
pke=(1./factorial(k)).*pke;
pke=pke/trapz(k,pke);

hold all
plot(k,pke)
set(gca,'Yscale','log')

Ncon=pke;
pken=zeros(length(N),length(k));

for i=1:length(N) %Ntimes convolution
    Ncon=Convol(Ncon,pke);
    Ncon=Ncon';
    Ncon=Ncon/trapz(k,Ncon);
    pken(i,:)=Ncon.*poisspdf(N(i),Nm);
end

pk=sum(pken,1);
pk=pk/sum(pk); %normalize
figure;
plot(k,pke)
set(gca,'Yscale','log')


end

