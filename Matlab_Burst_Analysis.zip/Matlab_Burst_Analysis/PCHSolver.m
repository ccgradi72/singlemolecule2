function [ output_args ] = PCHSolver( input_args )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

close all
% clear all
clc

% load('PCHMat','PCHData','PCHbins')

[FileName,PathName] = uigetfile('*.txt','Select the PCH txt file');
fid=fopen(strcat(PathName,FileName));
DATA=textscan(fid,'%f %f ');



global PCHData PCHbins Q PCHEndBin NZsteps NRsteps
PCHbins=DATA{1}';
PCHData=DATA{2}';

NZsteps=100;
NRsteps=100;

PCHEndBin=PCHbins(end);
Q=2; %simulation/integration volume is Q*(size 3d gaussian)

plot(PCHbins,PCHData)
set(gca,'YScale','log')

%Solver properties
    maxiter=3000;
    maxfunevals=10000;
    tolfun=1e-8;
    tolx=1e-6;
    lsqOpt=[maxiter maxfunevals tolfun tolx];
    options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt','Display','iter');
   


eps0=0.2;
N_aver0=0.8;
F0=0.76;



param0=[N_aver0 eps0 F0];
paramin=[0 0 0];
paramax=[Inf Inf Inf];
        
[param,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@pch_xcomp,param0,paramin,paramax,options);

param

[fit, err] = pch_1compFITResults(param);

figure;
hold on
plot(PCHbins,PCHData,'-bo')
plot(PCHbins,fit,'-ro')
legend('Data','Fit')
set(gca,'YScale','log')
figure;
plot(PCHbins,err)


chisq=resnorm/(length(fit)-length(param))

end

