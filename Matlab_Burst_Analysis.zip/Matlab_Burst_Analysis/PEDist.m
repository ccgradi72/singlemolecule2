
clc;
clear all;
close all;

dE=0.001
E=0.001:dE:0.999;
Ro=50;
R=50;

r=Ro*(1-(1./E)).^(1/6);

figure;
plot((1:length(r)),r)

dr=diff(r);

Pr=4*pi*(r.^2).*((3/(2*pi*R^2)).^(3/2)).*exp(-(3/2)*((r/R).^2));
Pr=Pr(1:length(dr));
r=r(1:length(dr));
E=E(1:length(dr));

PE=Pr.*abs((dr/dE));

figure;
plot(r,Pr);

figure;
plot(E,PE);


