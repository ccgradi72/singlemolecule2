
clc;
clear all
close all;
lw=1.5;
load('BurstTraj.mat')
figure;
hold all
    plot(edges,TrajG,'g',edges,-1*TrajR,'r','Linewidth',lw)
%     plot(edges,TrajBG,'k',edges,-1*TrajBR,'k','Linewidth',lw)
    plot(bursttimes,0.8*burstheads,'ob','MarkerFaceColor','b');

bstart=bstart-edges(1);
bend=bend-edges(1);
edges=edges-edges(1);


edges=edges*1000;
bstart=bstart*1000;
bend=bend*1000;

        subplot(2,1,1)
            hold all
            plot(edges,TrajGG,'g',edges,-1*TrajRG,'r')
%             plot(edges,-(Bad_par+Bad_perp)*dtTraj*ones(size(edges)),'k')
%             plot(edges,(Bdd_par+Bdd_perp)*dtTraj*ones(size(edges)),'k')
            MC1=max(TrajGG);
            MC2=max(TrajRG);
            MC=max(MC1,MC2);
            plot(bstart,0,'ob');  
            plot(bend,0,'dm');
            myylabel='Photon Counts';
            ylabel(myylabel)
            xlabel('time(s)')
            title(sprintf('Green Excitation, %d bursts in %.3f ms',length(bstart),(edges(end)-edges(1))*1000))
            axis tight
            xlim( [edges(1) edges(end)])
            hold off
            subplot(2,1,2)
            hold all
            plot(edges,TrajGR,'g',edges,-1*TrajRR,'r')
%             plot(edges,-(Baa_par+Baa_perp)*dtTraj*ones(size(edges)),'k')
            MC1=max(TrajGR);
            MC2=max(TrajRR);
            MC=max(MC1,MC2);
                plot(bstart,0,'ob');  
            plot(bend,0,'dm');
            myylabel='Photon Counts';
            ylabel(myylabel)
            xlabel('time(s)')
            title(sprintf('Red Excitation, %d bursts in %.3f ms',length(bstart),(edges(end)-edges(1))*1000))
            axis tight
            xlim( [edges(1) edges(end)])
            hold off

%     ylabel('Photon Counts, 500 $\rm \mu$s bins','Interpreter','Latex')
%     xlabel('time(s)','Interpreter','Latex')
%     axis tight
    h(1)=gca;
    
    % savetype='-dpng';
savetype='-dpdf';
resolution='-r600';

papersizex=6;
papersizey=4;
marginx=0;
marginy=0;
fontsizeax=25;
ticksize=12;
% offset=[0.1 0.3 0];
% offset=[-0.3 0.8 0];
fw='normal';
% 
% for i=1:2
%         set(h(i),'FontSize', ticksize);
%         set(h(i),'FontWeight',fw);
%         set(h(i),'TickDir','in', ...
%             'TickLength'  , [.02 .02] , ...
%             'XMinorTick'  , 'off'      , ...
%             'YMinorTick'  , 'off'      , ...
%             'YGrid'       , 'off'      , ...
%             'XColor'      , [.1 .1 .1], ...
%             'YColor'      , [.1 .1 .1], ...
%             'LineWidth', 1) ;
%         set(h(i), 'Box' , 'on' )
% %         set(h(i),'YTick',[0 0.5 1 1.5 2 2.5 3 3.5])
% %         set(h(i),'YTickLabel',{'0';'';'1';'';'2';'';'3';''})
        set(get(gca,'xlabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
         set(get(gca,'ylabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
% %         set(get(h(i),'title'),'FontSize',fontsizeax, 'FontWeight', fw...
% %             ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
% %       origpos=get(ht(i),'position');
% %       set(ht(i),'position',origpos-offset)
% end
      
left=0.15;
bottom=0.15;
width=0.8;
height=0.7;

% set(gca, 'Position',[left bottom width height])

set(gcf,'PaperUnits','inches');
        set(gcf, 'PaperSize', [papersizex papersizey]);
        set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
            papersizey-2*(marginy)]);
        set(gcf, 'PaperPositionMode','manual');
        set(gcf, 'color', 'w');
    mytitle='ExampleTraj2017';
%  print('-painters','-dpdf',resolution,mytitle)
print('-dpdf',resolution,mytitle)
print('-dpng',resolution,mytitle)

