

Nav=6.02E23;
Vh=0.55;
% Ndye=0.1;

% Cdye=120E-12; %mol/L

% Ndye=Cdye*Vh*Nav/(1E15)

n=0:0.001:0.1;

P1=exp(-n).*(n);
P0=exp(-n);

p=(1-P0-P1)./P1;

figure;
plot(n,p)


Cdye=(n*1E15)/(Vh*Nav)
Cdye=Cdye/(1E-12)

figure;
plot(Cdye,p)