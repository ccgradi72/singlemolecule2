function [Eraw] = ProximityRatio(nD,nA)
%Eraw: Computes proximity ratio Eraw from nD and nA, the acceptor and donor detected counts with only
%background correction (no leakage,direct excitation).
%   Detailed explanation goes here

nA=nA(:)';
nD=nD(:)';

Eraw=nA./(nA+nD);


end

