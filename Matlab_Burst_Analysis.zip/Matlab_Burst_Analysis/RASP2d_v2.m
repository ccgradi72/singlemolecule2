function [ ] = RASP2d( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%Notation/method follows closely to Hoffmann et al PCCP 2011
clc;
close all;

% % % hl=0;
% % % NewData=1;
% % % 
% % % 
% % % L=30; %photon threshold
% % % AccL=30;
% % % 
% % % % gamma=0.5;
% % % gamma=1
% % % Lk=0.000; %or 0.0254 
% % % di=0.00;

xf=1.1;
xi=-0.1;
nxBins=20;
dx=(xf-xi)/nxBins;
edges{1}=[xi:dx:xf]; % bin for x axis
xf2=1.1;
xi2=-0.1;
nxBins2=20;
dx2=(xf2-xi2)/nxBins2;
edges{2}=[xi2:dx2:xf2]; % bin for x axis



Trange{1}=[0 10]/1000; %in ms/1000 = s
Trange{2}=[10 1000]/1000; %in ms/1000 = s


% Trange{1}=[0 0.2]/1000; %in ms/1000 = s
% Trange{2}=[0.2 0.5]/1000; %in ms/1000 = s
% Trange{3}=[0.5 1]/1000;
% Trange{4}=[1 5]/1000;
% Trange{5}=[5 10]/1000;
% Trange{6}=[10 1000]/1000;

length(Trange)

% % % if exist('BurstWorkstate.mat','file') && ~NewData
% % %     %big BVAfiles take a long time to read text, better to load if you have
% % %     %already worked with this BVAfile already.
% % %     load('BurstWorkstate.mat','DATA','FileName')
% % %     fprintf('Finished loading from .mat file\r\n')
% % % else
% % %     % Find Data
% % %     [FileName,PathName] = uigetfile('*.txt','Select the data file');
% % %     delimiterIn = '\t';
% % %     DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
% % %     save('BurstWorkstate.mat','DATA','FileName')
% % %     fprintf('Finished loading and saving %s from text file\r\n',FileName)
% % % end
% % % 
% % % %DATA is number of bursts by 27 columns with each column representing a
% % % %parameter describing the burst (eg. duration, E, anisotropy, lifetime etc)
% % % 
% % % %recall bursts were saved as
% % % %currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ...
% % % %        Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...
% % % %        Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...
% % % %        Txd Txa Tdd Tad ...
% % % %        tauD rD rA...
% % % %        Eraw Sraw E S];
% % % 
% % % % size(DATA)
% % % 
% % % %Want to extract a subset of bursts (b1,b2) such that the bursts b2 must be
% % % %detected during a time interval between t1 and t2 (the recurrence
% % % %interval) after a a previous burst b1 (the initial burst). Second the
% % % %initial bursts must be in a range  deltaE (the initial E range).
% % % 
% % % bstart=DATA(:,1);
% % % bend=DATA(:,2);
% % % bdur=DATA(:,3);
% % % S=DATA(:,27);
% % % E=DATA(:,24);
% % % Txd=DATA(:,17);
% % % Txa=DATA(:,18);
% % % Tdd=DATA(:,19);
% % % Tad=DATA(:,20);
% % % % AllRecords=DATA;
% % % Sd=DATA(:,5)+DATA(:,6) ;
% % % Sa=DATA(:,7)+DATA(:,8);
% % % Saa=DATA(:,9)+DATA(:,10);
% % % Bd=DATA(:,11)+DATA(:,12);
% % % Ba=DATA(:,13)+DATA(:,14);
% % % Baa=DATA(:,15)+DATA(:,16);
% % % Fa=Sa-bdur.*Ba;
% % % Fd=Sd-bdur.*Bd;
% % % Faa=Saa-bdur.*Baa;
% % % 
% % % tslb=DATA(:,4);
% % % tauD=DATA(:,21);
% % % rD=DATA(:,22);
% % % 
% % % if 1
% % % [E] = correct_E_gamma_leak_dir(Fd,Fa,Faa,gamma,Lk,di,'ALEX');
% % % [S] = correct_Stoich_gamma_leak_dir(Fd,Fa,Faa,gamma,Lk,di,'ALEX');
% % % end
% 
% [ E] = Eraw2Epr( E,gamma,Lk,di);

% % % Filtering for FRET only and no blinking shit
% % % 
% % % if 1
% % % filt=abs(Txd-Txa)>0.5E-3;
% % % sizefilt1=nnz(filt)
% % % E(filt)=[];
% % % S(filt)=[];
% % % Faa(filt)=[];
% % % Fd(filt)=[];
% % % Fa(filt)=[];
% % % Tdd(filt)=[];
% % % Tad(filt)=[];
% % % Txd(filt)=[];
% % % Txa(filt)=[];
% % % tauD(filt)=[];
% % % rD(filt)=[];
% % % bdur(filt)=[];
% % % bend(filt)=[];
% % % bstart(filt)=[];
% % % end
% % % 
% % % if 1
% % % filt=(Fd +Fa <AccL);  % filter out acceptor only
% % % bstart(filt)=[];
% % % E(filt)=[];
% % % S(filt)=[];
% % % Faa(filt)=[];
% % % Fd(filt)=[];
% % % Fa(filt)=[];
% % % Txd(filt)=[];
% % % Txa(filt)=[];
% % % Tdd(filt)=[];
% % % Tad(filt)=[];
% % % tauD(filt)=[];
% % % rD(filt)=[];
% % % bdur(filt)=[];
% % % bend(filt)=[];
% % % end
% % % 
% % % disp('FRET bursts')
% % % filt=(Fd +Fa <L);  % filter out acceptor only
% % % bstart(filt)=[];
% % % E(filt)=[];
% % % S(filt)=[];
% % % Faa(filt)=[];
% % % Fd(filt)=[];
% % % Fa(filt)=[];
% % % Txd(filt)=[];
% % % Txa(filt)=[];
% % % Tdd(filt)=[];
% % % Tad(filt)=[];
% % % tauD(filt)=[];
% % % rD(filt)=[];
% % % bdur(filt)=[];
% % % bend(filt)=[];
% % % 
% % % filt=(Faa<AccL); % filter out donor only
% % % bstart(filt)=[];
% % % E(filt)=[];
% % % S(filt)=[];
% % % Txd(filt)=[];
% % % Txa(filt)=[];
% % % Tdd(filt)=[];
% % % Tad(filt)=[];
% % % tauD(filt)=[];
% % % rD(filt)=[];
% % % bdur(filt)=[];
% % % Faa(filt)=[];
% % % Fd(filt)=[];
% % % Fa(filt)=[];
% % % bend(filt)=[];
% % % % 
% % % % %First throw out parameters not of interest
% % % % DATA=DATA(:,[1 2 26]);
% % % % % DATA(1,:)

load('ForRasp','E','bstart','bend')

Efull=E;
E_start=E;
E_end=E;
b_start=bstart;
b_end=bend;

%Delete first element of b_start (when first burst starts is irrelevent for
%recurrence since there are no bursts before it)
b_start(1)=[];

%the times in b_start now refer to  t2s t3s... tNs, (tis=time i start) ie these will be the end
%bursts. So do same operation to E_end.
E_end(1)=[];

%Now b_start is length N-1, need to make b_end become length N-1. Since
%there is no burst after burst N, its end time tNe (time i end) is irrelevant, and we can
%delete its last element.
b_end(end)=[];

% the times in b_end now correspond to t1e t2e t3e...tN-1e. So these will
% be the start bursts. Thus, make E_start match.
E_start(end)=[];

figure;
for j=1:length(Trange)
[n3d]=RaspHist(Trange{j},edges,E_start,E_end,b_start,b_end);
subplot(0.5*2^nextpow2(length(Trange)),2,j)
hold all
[C,hCont]=contourf(edges{1},edges{2},n3d,15);
% set(gca,'xtick',edges{1})
% set(gca,'ytick',edges2{1})
colormap(flipud(gray));
set(hCont,'LineColor','k')
plot(edges{1},edges{2},'-r')
ht{j}=title({sprintf('\\DeltaT=[%.3f,%.3f]ms',Trange{j}(1)*1000,Trange{j}(2)*1000);sprintf('# = %d',sum(sum(n3d)))});
set(gca,'XTick',[0 0.25 0.5 0.75 1])
set(gca,'YTick',[0 0.25 0.5 0.75 1])
if mod(j,2)
ylabel('E_{2}')
end
if j>length(Trange)-2
    xlabel('E_{1}')
end

% bar3(n3d)
% set(ht,'
xlim([-0.2 1.2])
ylim([-0.2 1.2])
hold off
set(gca ,'Layer', 'Top')
% drawnow
h{j}=gca;
end

width=0.3;
height=0.25;
left=0.2;
bot=0.13;
hs=0.01;
ws=0.01;

set(h{5},'Position',[left bot width height])
set(h{6},'Position',[left+width+ws bot width height])
set(h{3},'Position',[left bot+height+hs width height])
set(h{4},'Position',[left+width+ws bot+height+hs width height])
set(h{1},'Position',[left bot+2*height+2*hs width height])
set(h{2},'Position',[left+width+ws bot+2*height+2*hs width height])
set(h{1},'XTickLabel',[])
set(h{2},'XTickLabel',[])
set(h{3},'XTickLabel',[])
set(h{4},'XTickLabel',[])
set(h{2},'YTickLabel',[])
set(h{4},'YTickLabel',[])
set(h{6},'YTickLabel',[])
set(h{5},'XTickLabel',{'0';'';'0.5';'';'1'})
set(h{6},'XTickLabel',{'0';'';'0.5';'';'1'})
set(h{1},'YTickLabel',{'0';'';'0.5';'';'1'})
set(h{3},'YTickLabel',{'0';'';'0.5';'';'1'})
set(h{5},'YTickLabel',{'0';'';'0.5';'';'1'})
% set(h{5},'XLabel','E_{1}')
% set(h{6},'XLabel','E_{1}')

% fontsizeax=11;
% ticksize=11;
savetype='-dpng';
% savetype='-dpdf';
resolution='-r600';

papersizex=6;
papersizey=9;
marginx=0;
marginy=0;
fontsizeax=12;

ticksize=12;
% offset=[0.1 0.3 0];
offset=[0.1 0.6 0];
fw='normal';
for i=1:length(Trange)
        set(h{i},'FontSize', ticksize);
        set(h{i},'FontWeight',fw);
        set(h{i},'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', 1) ;
        set(h{i}, 'Box' , 'on' )
        set(get(h{i},'xlabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
         set(get(h{i},'ylabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
        set(get(h{i},'title'),'FontSize',fontsizeax/2, 'FontWeight', fw...
            ,'FontName', 'Helvetica','color',[0.1 0.1 0.1]);
      origpos=get(ht{i},'position');
      set(ht{i},'position',origpos-offset)
      
end   
        

 set(gcf,'PaperUnits','inches');
        set(gcf, 'PaperSize', [papersizex papersizey]);
        set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
            papersizey-2*(marginy)]);
        set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
    mytitle=sprintf('RASP %s.png','xxxx');
%  print('-painters','-dpdf',resolution,mytitle)
print(savetype,resolution,mytitle)

save('RaspResults.mat')        
        

    function [n3d]=RaspHist(Trange,edges,E_start,E_end,b_start,b_end)
        
        %Filter by recurrence interval
        deltaT=b_start-b_end;
        filt=find(deltaT>=Trange(1) & deltaT<= Trange(2));
        R_E_start=E_start(filt);
        R_b_start=b_start(filt);
        R_b_end=b_end(filt);
        R_E_end=E_end(filt);
        fprintf('The number of bursts meeting first condition is %f \r\n',length(R_E_start))
%         fprintf('-------------------\r\n')
%         fprintf('(deltaT) Filter results \r\n')
        % fprintf('The final set of burst pairs is of length %f \r\n',length(R_E_end))
%         deltaT=R_b_start-R_b_end;

%         fprintf('The average time between bursts is %f ms\r\n',mean(deltaT)*1000)
%         fprintf('The minimum time between bursts is %f ms\r\n',min(deltaT)*1000)
%         fprintf('The maximum time between bursts is %f ms\r\n',max(deltaT)*1000)
%         fprintf('The average FRET of E1 bursts is %f \r\n',mean(R_E_start))
%         fprintf('The minimum FRET of E1 bursts is %f \r\n',min(R_E_start))
%         fprintf('The maximum FRET of E1 bursts is %f \r\n',max(R_E_start))
%         fprintf('The average FRET of E2 bursts is %f \r\n',mean(R_E_end))
%         fprintf('The minimum FRET of E2 bursts is %f \r\n',min(R_E_end))
%         fprintf('The maximum FRET of E2 bursts is %f \r\n',max(R_E_end))
        
        n3d=zeros(length(edges{2}),length(edges{1}));
        for bin=1:length(edges{1})
            
            Erange=[edges{1}(bin)-dx/2 edges{1}(bin)+dx/2];
            %first filter to get all bursts whose E_start is in E range
       
            filt=R_E_start>=Erange(1) & R_E_start<= Erange(2);
            RR_E_start=R_E_start(filt);
            fprintf('The number of bursts meeting E=[%.3f,%.3f] and T=[%.3f %.3f] ms  is %f \r\n',Erange(1),Erange(2),Trange(1)*1000,Trange(2)*1000,length(RR_E_start))
            RR_b_start=R_b_start(filt);
            RR_b_end=R_b_end(filt);
            RR_E_end=R_E_end(filt);
            [nE2,~] = hist(RR_E_end,edges{2});
            % size(nE2)
            n3d(:,bin)=nE2(:);
            
        end
        
    end


end

