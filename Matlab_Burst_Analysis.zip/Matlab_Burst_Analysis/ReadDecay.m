close all
clear all
clc

[FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    hl=2;
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    t=0:length(DATA.data(:,2))-1;
    t=t*0.004;
    
    D_par=DATA.data(:,4);
    D_perp=DATA.data(:,5);
    
    figure;
    hold all
    plot(t,D_par)
    plot(t,D_perp)
    
    Yp=D_par;
    Yx=D_perp;
    G=1.028;
    c1=1-3*0.065; %High numerical aperture factor 1
c2=2-3*0.33;
    
    den=(c1*Yp+G*c2*Yx);
        num=(Yp-G*Yx);   
        %Calculated experimental anisotropy
        Rexp=num./den;
        Rexp(isnan(Rexp))=0;
        %Rexp(Rexp<0)=0;
        Rexp(den<=0)=0;
        
        figure;
        plot(t,Rexp)
        
    
    