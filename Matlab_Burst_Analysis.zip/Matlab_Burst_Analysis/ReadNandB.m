function [ output_args ] = ReadNandB( input_args )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
clc;
close all
clear all

[FileName,PathName] = uigetfile('*.txt','Select the NandB  BKG txt file');
if FileName~=0
fid=fopen(strcat(PathName,FileName));
DATA=textscan(fid,'%f',1);
BinTime=DATA{1};
DATA=textscan(fid,'%f %f %f %f %f %f %f ');

t=DATA{1};
BKGdd=DATA{2};
% vdd=DATA{3};
BKGad=DATA{4};
% vad=DATA{5};
BKGaa=DATA{6};
% vaa=DATA{7};

figure;
subplot(2,1,1)
hold all
plot(t,BKGdd/BinTime,'-b')
plot(t,-BKGad/BinTime,'-r')
title('BKG Dexc')
subplot(2,1,2)
plot(t,-BKGaa/BinTime,'-r')
title('BKG Aexc')


% BKGdd=(3.685)*1000*BinTime
mBKGdd=nanmean(BKGdd)/(1000*BinTime)
stdBKGdd=nanstd(BKGdd/(1000*BinTime))/sqrt(length(BKGdd))
mBKGad=nanmean(BKGad)/(1000*BinTime)
stdBKGad=nanstd(BKGad/(1000*BinTime))/sqrt(length(BKGad))
mBKGaa=nanmean(BKGaa)/(1000*BinTime)
stdBKGaa=nanstd(BKGaa/(1000*BinTime))/sqrt(length(BKGaa))

else
    BKGdd=0;
    BKGad=0;
    BKGaa=0;
end




[FileName,PathName] = uigetfile('*.txt','Select the NandB txt file');
fid=fopen(strcat(PathName,FileName));
DATA=textscan(fid,'%f',1);
BinTime=DATA{1};
DATA=textscan(fid,'%f %f %f %f %f %f %f ');

t=DATA{1};
mdd=DATA{2};
vdd=DATA{3};
mad=DATA{4};
vad=DATA{5};
maa=DATA{6};
vaa=DATA{7};

figure;
subplot(2,1,1)
hold all
plot(t,mdd/BinTime,'-b')
plot(t,-mad/BinTime,'-r')
title('Signal Dexc')
subplot(2,1,2)
plot(t,-maa/BinTime,'-r')
title('Signal Aexc')

% plot(t(2:end)-t(1:end-1)>0)
% 
% mdd=mdd(t(2:end)-t(1:end-1)>0);
% vdd=vdd(t(2:end)-t(1:end-1)>0);
% t=t(t(2:end)-t(1:end-1)>0);

[Ndd,edd]=NBAnalysis(mdd,vdd,nanmean(BKGdd));
[Nad,ead]=NBAnalysis(mad,vad,nanmean(BKGad));
[Naa,eaa]=NBAnalysis(maa,vaa,nanmean(BKGaa));

figure;
[hCont,hx ,hy] = Histogram2d(Nad,ead,[],[],20,20,10,'N','e',[],[],[],[])


figure;
[hAx,hLine1,hLine2]=plotyy(t,edd/(1000*BinTime),t,Ndd);
% title('Number and Brightness 250 uW ')
xlabel('t (s)')
ylabel(hAx(1),'Brightness (kcps/molecule)') % left y-axis
ylabel(hAx(2),'Number') % right y-axis
set(hLine1,'LineStyle','-')
set(hLine2,'LineStyle','-')
set(hLine1,'LineWidth',1)
set(hLine2,'LineWidth',1)
title('Donor Channel after Donor Excitation')

% ylim(hAx(2),[0 nanmean(Ndd)+3*nanstd(Ndd)])

figure;
[hAx,hLine1,hLine2]=plotyy(t,ead/(1000*BinTime),t,Nad);
% title('Number and Brightness 250 uW ')
xlabel('t (s)')
ylabel(hAx(1),'Brightness (kcps/molecule)') % left y-axis
ylabel(hAx(2),'Number') % right y-axis
set(hLine1,'LineStyle','-')
set(hLine2,'LineStyle','-')
set(hLine1,'LineWidth',1)
set(hLine2,'LineWidth',1)
title('Acceptor Channel after Donor Excitation')
% ylim(hAx(2),[0 nanmean(Nad)+3*nanstd(Nad)])

% This is the plot line color.
set(hLine1, 'Color', 'b');
set(hLine2, 'Color', 'k');
set(hAx(1), 'YColor', 'b');
set(hAx(2), 'YColor', 'k');

figure;
% Naa(t<10)=[];
% eaa(t<10)=[];
% t(t<10)=[];
[hAx,hLine1,hLine2]=plotyy(t,eaa/(1000*BinTime),t,Naa);
% title('Number and Brightness 250 uW ')
xlabel('t (s)')
ylabel(hAx(1),'Brightness (kcps/molecule)') % left y-axis
ylabel(hAx(2),'Number') % right y-axis
set(hLine1,'LineStyle','-')
set(hLine2,'LineStyle','-')
set(hLine1,'LineWidth',1)
set(hLine2,'LineWidth',1)
title('Acceptor Channel after Acceptor Excitation')

% ylim(hAx(2),[0 nanmean(Nad)+3*nanstd(Nad)])

% This is the plot line color.
set(hLine1, 'Color', 'b');
set(hLine2, 'Color', 'k');
set(hAx(1), 'YColor', 'b');
set(hAx(2), 'YColor', 'k');

meanNUMdd=nanmean(Ndd)
meanEPSdd=nanmean(edd)
meanEPSdd=nanmean(edd/(1000*BinTime))
stdNUMdd=nanstd(Ndd,1)/sqrt(length(Ndd))
stdEPSdd=nanstd(edd,1)/sqrt(length(Ndd))
stdEPSdd=nanstd(edd/(1000*BinTime),1)/sqrt(length(Ndd))


meanNUMad=nanmean(Nad)
meanEPSad=nanmean(ead)
meanEPSad=nanmean(ead/(1000*BinTime))
stdNUMad=nanstd(Nad,1)/sqrt(length(Nad))
stdEPSad=nanstd(ead,1)/sqrt(length(Nad))
stdEPSad=nanstd(ead/(1000*BinTime),1)/sqrt(length(Nad))


meanNUMaa=nanmean(Naa)
meanEPSaa=nanmean(eaa)
meanEPSaa=nanmean(eaa/(1000*BinTime))
stdNUMaa=nanstd(Naa,1)/sqrt(length(Naa))
stdEPSaa=nanstd(eaa,1)/sqrt(length(Naa))
stdEPSaa=nanstd(eaa/(1000*BinTime),1)/sqrt(length(Naa))


 function [N,ee]=NBAnalysis(m,v,bkg)
                
        N=((m-bkg).^2)./(v-m);
        ee=(v-m)./(m-bkg);
        
        N(N<0)=0;
        ee(ee<0)=0;
        N(isinf(N))=NaN;
        ee(isinf(ee))=NaN;
    end

end

