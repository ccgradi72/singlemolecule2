%test MLE result

clc
close all

fw='Normal';
fn='Helvetica';
axw='Normal';
cc=[255, 153, 0]/255
cc2=[48, 94 168]/255
fontsizeax=16;
fontsizel=12;
lwax=1;
ticksize=20;
linewidthbestfit=0.4;
linewidthErrBar=1;
markersize=10;
lw=4;
lwe=2;
ms=markersize;



% % % N=[15 30 50 75 100]
% % % errMLE=[-224 -77 -7 -28 35]
% % % stdMLE=[56 39 29 23 20]
% % % errMLE1=[-335 -143 -70 -61 -7]
% % % stdMLE1=[54 38 28 22 20]
% % % errM1=[-868 -815 -784 -796 -781]
% % % stdM1=[22 16 13 10 9]

gamma=0.15;
N=[15 30 50 75 100]
errMLE=[-294 -193 -77 -67 -56] 
stdMLE=[60 46 33 28 22]
errMLE1=[-1029 -847 -764 -743 -747]
stdMLE1=[54 38 27 23 17]
errM1=[-1344 -1332 -1277 -1260 -1264]
stdM1=[24 17 13 11 9]


figure;
hold all
lw=2
x=linspace(0,120,100);
yy=zeros(size(x));
plot(x,yy,'--','Color',[128 128 128]/256)
errorbar(N,errMLE,stdMLE*sqrt(1000),'--ro','MarkerFaceColor','r','Linewidth',lw,'MarkerSize',ms)
errorbar(N,errMLE1,stdMLE1*sqrt(1000),'--go','MarkerFaceColor','g','Linewidth',lw,'MarkerSize',ms)
errorbar(N,errM1,stdM1*sqrt(1000),'--bo','MarkerFaceColor','b','Linewidth',lw,'MarkerSize',ms)

% errorbar(N,errMLE,stdMLE,'--ko','MarkerFaceColor','k','Linewidth',lw)
% errorbar(N,errMLE1,stdMLE1,'--ro','MarkerFaceColor','r','Linewidth',lw)
% errorbar(N,errM1,stdM1,'--bo','MarkerFaceColor','b','Linewidth',lw)

% axis tight

ylim([-3000 2500])
xlim([0 120])
   set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'on' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
        
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        print('-dpng','-r600','gamma15')




% N=[15 30 50 75 100]
% errMLE=[60 -224 -132 -98 -66]
% stdMLE=[63 44 35 26 21]
% errMLE1=[-1024 -834 -814 -779 -720]
% errM1=[-1305 -1289  -1277 -1280 -1264]
% stdM1=[24 17 13 10 8]

N=[15 30 50 75 100]
errMLE=[-11 -87 -68 -3 -6]
stdMLE=[60 41 31 24 20]
errMLE1=[-218 -172 -139 -51 -56]
stdMLE1=[57 41 30 24 19]
errM1=[-814 -804 -835 -780 -795]
stdM1=[23 17 13 10 9]


figure;
hold all
lw=2
errorbar(N,errMLE,stdMLE*sqrt(1000),'--ko','MarkerFaceColor','k','Linewidth',lw,'MarkerSize',ms)
errorbar(N,errMLE1,stdMLE1*sqrt(1000),'--bo','MarkerFaceColor','b','Linewidth',lw,'MarkerSize',ms)
errorbar(N,errM1,stdM1*sqrt(1000),'--ro','MarkerFaceColor','r','Linewidth',lw,'MarkerSize',ms)
% errorbar(N,errMLE,stdMLE,'--ko','MarkerFaceColor','k','Linewidth',lw)
% errorbar(N,errMLE1,stdMLE1*sqrt(1000),'--ro','MarkerFaceColor','r','Linewidth',lw)
% errorbar(N,errM1,stdM1,'--bo','MarkerFaceColor','b','Linewidth',lw)

% axis tight
ylim([-2000 2000])
xlim([0 120])

   set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'on' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
        
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        print('-dpng','-r600','gamma0')

