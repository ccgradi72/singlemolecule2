function []=RgvsC()

%% Plotting
%% Some plotting preamble
fw='Normal';
fn='Helvetica';
axw='Normal';
myOrange=[238 131 66]/256;
myRed=[232 57 55]/256;
myLiBlu=[95 173 219]/256;
myGreen=[60 147 73]/256;
myYellow=[244 232 70]/256;
papersizex=3.42*2;
% papersizex=3.42;
papersizey=0.75*papersizex; 
marginx=0;
marginy=0;
fontsizeax=16;
lwax=1;

ticksize=20;
linewidthbestfit=0.4;
linewidthErrBar=1;
markersize=8;

%Solver properties
maxiter=5000;
maxfunevals=5000;
tolfun=1e-8;
tolx=1e-8;
lsqOpt=[maxiter maxfunevals tolfun tolx];

C=[0 1 3 6]
Rg=[2.947 3.104 mean([3.104 3.366]) 3.366];
Rgp=[3.008 3.1261 mean([3.1261 3.2958]) 3.2958]
ss=0.1

options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');

modelParam0=[0.5 1]
lb=[0 0]
ub=[Inf Inf]


% test=TanfordGdmClActivity(0);

% CData=C;
CData=TanfordGdmClActivity(C);
stdData=repmat(ss,size(CData));

RgData=Rg;
[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
afit=modelParam(1)
Kfit=modelParam(2)
Cx=linspace(0,6,100);
myx=TanfordGdmClActivity(Cx);
[Rgfit]=MakeModel(modelParam);

        dof = length(RgData)-2;
        Jacobianf=full(jacobian); %lsqnonlin returns  Jacobian as sparse matrix
        varp=resnorm*((Jacobianf'*Jacobianf)^-1)/dof;
        stdp=sqrt(diag(varp));
        std_a=stdp(1)
        std_K=stdp(2)

RgData=Rgp;
[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcn,modelParam0,lb,ub,options);
afitp=modelParam(1)
Kfitp=modelParam(2)
% myx=linspace(0,6,100);
[Rgfitp]=MakeModel(modelParam);
        dof = length(RgData)-2;
        Jacobianf=full(jacobian); %lsqnonlin returns  Jacobian as sparse matrix
        varp=resnorm*((Jacobianf'*Jacobianf)^-1)/dof;
        stdp=sqrt(diag(varp));
        std_a=stdp(1)
        std_K=stdp(2)


figure;
hold on
errorbar(C,Rg,repmat(ss,size(C)),'ko','MarkerEdgeColor','k',...
            'MarkerFaceColor',myGreen,...
            'LineWidth',linewidthErrBar,'MarkerSize',markersize,'Color',myGreen)
errorbar(C,Rgp,repmat(ss,size(C)),'ko','MarkerEdgeColor','k',...
            'MarkerFaceColor',myLiBlu,...
            'LineWidth',linewidthErrBar,'MarkerSize',markersize,'Color',myLiBlu)
        plot(Cx,Rgfit,'-','LineWidth',1,'Color',myGreen)
        plot(Cx,Rgfitp,'-','LineWidth',1,'Color',myLiBlu)

        ylabel('R_{g} (nm)')
        set(get(gca,'ylabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', fn,'color',[0.1 0.1 0.1]);
        
        %Adjust axes limits
        set(gca,'Xlim', [-0.5 6.5], 'Ylim', [2.75 3.5]);
               
        %Adjust ticks
        set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'on'      , ...
            'YMinorTick'  , 'on'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
%         set(gca, 'YTick',yRgTick)
%         set(gca, 'XTick',myxtick)
%         set(gca,'XTickLabel',[])
%         set(gca,'YTickLabel',yRgTickLabel)
        set(gca, 'Box' , 'on' )
        hold off
        
 
        xlabel(gca,'[GdmCl] (M)')
         set(get(gca,'xlabel'),'FontSize',fontsizeax, 'FontWeight', fw...
            ,'FontName', fn,'color',[0.1 0.1 0.1]);
        
        % %paper position and background color
%         set(gcf,'PaperUnits','inches');
%         set(gcf, 'PaperSize', [papersizex papersizey]);
%         set(gcf, 'PaperPosition', [marginx marginy papersizex-2*(marginx)...
%             papersizey-2*(marginy)]);
        set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
        
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.7;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        print('-dpng','-r600','GdmClRgSAW')
        
        
        function [myfun]=objfcn(modelParam)
        
        
       a=modelParam(1);
        K=modelParam(2);
        
        
        y=RgData(1)*(1+ a*(K*CData)./(1 + K*CData));
       
        myfun=(RgData-y)./stdData;
        
%         myfun(isnan(myfun))=0;
%         myfun(isinf(myfun))=0;
        
       
        end
    
        function [myfun]=MakeModel(modelParam)
        
        
       a=modelParam(1);
        K=modelParam(2);
        
        
        y=RgData(1)*(1+ a*(K*myx)./(1 + K*myx));
       
        myfun=y;
        
%         myfun(isnan(myfun))=0;
%         myfun(isinf(myfun))=0;
        
       
        end
    
       function [a]=TanfordGdmClActivity(C)
        
        %c is molar concentration
        % a designates activity
        
        %This is from K.C Aune and C. Tanford (1969) Biochemistry 8, 4579
        %Equation 2
        
        logA =-0.5191 + 1.4839*log10(C) -0.2562*(log10(C)).^2 +0.5884*(log10(C)).^3;
        a=10.^(logA);
        
    end
end
        