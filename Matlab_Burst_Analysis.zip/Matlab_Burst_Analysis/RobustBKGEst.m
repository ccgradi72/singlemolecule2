function [B_Dpar,B_Dperp,B_Apar,B_Aperp,B_AApar,B_AAperp] = RobustBKGEst(t,ind,i_start,i_end)
global ind_Dpar ind_Dperp ind_Aperp ind_Apar ind_Dexc ind_Aexc



%estimate the background
%look in the regions in between bursts and count how many photons and
%divide by the duration.

%   vB_Dpar=[];
%     vB_Dperp=[];
%     vB_Aperp=[];
%     vB_Apar=[];
   
        
    
% for i=1:length(i_end)-1
%     tempTT=t(i_end(i):i_start(i+1));
%     tempIND=ind(i_end(i):i_start(i+1));
%     size(tempTT)
%     size(tempIND)
%     B_Dpar=length(tempIND(tempIND==ind_Dpar))/(max(tempTT(tempIND==ind_Dpar))-min(tempTT(tempIND==ind_Dpar)));
%     B_Dperp=length(tempIND(tempIND==ind_Dperp))/(max(tempTT(tempIND==ind_Dperp))-min(tempTT(tempIND==ind_Dperp)));
%     B_Aperp=length(tempIND(tempIND==ind_Aperp))/(max(tempTT(tempIND==ind_Aperp))-min(tempTT(tempIND==ind_Aperp)));
%     B_Apar=length(tempIND(tempIND==ind_Apar))/(max(tempTT(tempIND==ind_Apar))-min(tempTT(tempIND==ind_Apar)));
%     
%     vB_Dpar=[vB_Dpar B_Dpar];
%     vB_Dperp=[vB_Dperp B_Dperp];
%     vB_Aperp=[vB_Aperp B_Aperp];
%     vB_Apar=[vB_Apar B_Apar];
% end


%     B_Dpar=mean(vB_Dpar(~isnan(vB_Dpar)));
%     B_Dperp=mean(vB_Dperp(~isnan(vB_Dperp)));
%     B_Aperp=mean(vB_Aperp(~isnan(vB_Aperp)));
%     B_Apar=mean(vB_Apar(~isnan(vB_Apar)));

% unique(ind)
% length(ind==ind_Dpar)

    S_Dpar=0;
    S_Dperp=0;
    S_Aperp=0;
    S_Apar=0;
    S_AAperp=0;
    S_AApar=0;

for i=1:length(i_start)
    
    
    %Count all the photons that came from bursts
        %Assumes that the number of bkg photons within a burst is small
        %compared to fluorescence photons
        %And if we over count a little bit, there are still plenty of bkg
        %photons outside bursts
    
    tempT=t(i_start(i):i_end(i));
    tempIND=ind(i_start(i):i_end(i));
   [tempINDD,~,~,tempINDA,~,~,~,~] = SortPhotonByALEXReal(tempIND,zeros(size(tempIND)),tempT,[ind_Dexc ind_Aexc]);
    S_Dpar=S_Dpar+length(tempINDD(tempINDD==ind_Dpar));
    S_Dperp=S_Dperp+length(tempINDD(tempINDD==ind_Dperp));
    S_Aperp=S_Aperp+length(tempINDD(tempINDD==ind_Aperp));
    S_Apar=S_Apar+length(tempINDD(tempINDD==ind_Apar));    
    S_AAperp=S_AAperp+length(tempINDA(tempINDA==ind_Aperp));
    S_AApar=S_AApar+length(tempINDA(tempINDA==ind_Apar));
    
end
 [indD,~,~,indA,~,~,~,~] = SortPhotonByALEXReal(ind,zeros(size(ind)),t,[ind_Dexc ind_Aexc]);
%the total signal
    T_Dpar=length(indD(indD==ind_Dpar));
    T_Dperp=length(indD(indD==ind_Dperp));
    T_Aperp=length(indD(indD==ind_Aperp));
    T_Apar=length(indD(indD==ind_Apar));
    
    T_AAperp=length(indA(indA==ind_Aperp));
    T_AApar=length(indA(indA==ind_Apar));
    
%the the total number of bkg photons is    
%this number was counted in an interval of time...
delT=t(end)-t(1);
    B_Dpar=(T_Dpar-S_Dpar)/delT;
    B_Dperp=(T_Dperp-S_Dperp)/delT;
    B_Aperp=(T_Aperp-S_Aperp)/delT;
    B_Apar=(T_Apar-S_Apar)/delT;
    B_AAperp=(T_AAperp-S_AAperp)/delT;
    B_AApar=(T_AApar-S_AApar)/delT;
    

end