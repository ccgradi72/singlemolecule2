function [ ] = MinimalBurstExplorer_Jan13_2017( )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


global name
name='1mW'

clc;
close all;

hl=0;
NewData=1;

%%
% Select for which population? 1 will keep this population only. all 0 if
% you want full.
FRET=1;
Aonly=0;
Donly=0;
AutoGamma=0; %try to find gamma factor automatically form E vs tau.

myYlim=[];

L=30; %photon threshold

gamma=1;
Lk=0.0; 
di=0.0; 
tauD0=3.74; %1M fittau=3.6472, mean tau=3.8998, D-A fittau=2.9333, fitE=0.4507
rho=0.3;

%%

% xf=1.2;
% xi=-0.2;
% nxBins=50;
% dx=(xf-xi)/nxBins;
% edges{1}=[xi:dx:xf]; % bin for x axis

if exist('BurstWorkstate.mat','file') && ~NewData
    %big files take a long time to read text, better to load if you have
    %already worked with this file already.
    load('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading from .mat file\r\n')
else
    % Find Data
    [FileName,PathName] = uigetfile('*.txt','Select the data file');
    delimiterIn = '\t';
    DATA = importdata(strcat(PathName,FileName),delimiterIn,hl);
    save('BurstWorkstate.mat','DATA','FileName')
    fprintf('Finished loading and saving %s from text file\r\n',FileName)
end

%DATA is number of bursts by 28 columns with each column representing a
%parameter describing the burst (eg. duration, E, anisotropy, lifetime etc)

%recall bursts were saved as
%currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ... 4
%        Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ... 10
%        Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ... 16
%        Txd Txa Tdd Tad ... 20
%        tauD rD rA... 23
%        Eraw Sraw E S numPh Sda_par Sda_perp]; 30

% %  currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ... %4
% %         Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...   %10
% %         Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...    %16
% %         Txd Txa Tdd Tad ...                              %20
% %         tauD rD rA...            %23
% %         Eraw Sraw E S numPh Sda_par Sda_perp];               %30

% size(DATA) 

% % %     Mean photon arrival time after donor excitation (all photons)
% % %     Txd=mean(timetagDexc(indDexc~=15));
% % %     Mean photon arrival time after acceptor excitation (all photons)
% % %     Txa=mean(timetagAexc(indAexc~=15));
% % %     Mean photon arrival time in donor channel after donor excitation
% % %     Tdd=mean(timetagDexc(indDexc==ind_Dpar | indDexc==ind_Dperp));
% % %     Mean photon arrival time in acceptor channel after donor excitation
% % %     Tad=mean(timetagDexc(indDexc==ind_Apar | indDexc==ind_Aperp));

%%% Tdd-Tad the difference of the burst-averaged macroscopic photon arrival
%%% time measured in the donor detection channel after donor excitation and
%%% the macroscopic photon arrival time measured in the acceptor detection
%%% channel after donor excitation allows identification of acceptor
%%% photobleaching events. Filter with |Tdd-Tad|<Tthresh e.g 0.7 ms.

%%%Although this approach allows for efficient removal of photobleaching
%%% events, it is difficult to distinguish between molecules
%%% undergoing photobleaching/blinking and molecules undergoing
%%% slow FRET dynamics, which may be of particular interest
%%% and should be included in the analysis.

%%% By comparing the burst-averaged macroscopic arrival time of all photons 
%%% after donor excitation Txd, with the burst-averaged macroscopic arrival
%%% time of all photons after acceptor excitation, Txa, photobleaching
%%% events can be removed with equal efficiency as
%%% above while dynamic bursts are unaffected.


getLk=0; %retrieve a saved Leakage file

if getLk 
        load('LkMat','Lk')
        fprintf('The  leakage %0.3f was loaded ',Lk)    
        
end
% 


bstart=DATA(:,1);
S=DATA(:,27);
E=DATA(:,24);
Txd=DATA(:,17);
Txa=DATA(:,18);
Tdd=DATA(:,19);
Tad=DATA(:,20);
% AllRecords=DATA;
Fd=DATA(:,5)+DATA(:,6) ;
Fa=DATA(:,7)+DATA(:,8);
Faa=DATA(:,9)+DATA(:,10);
tslb=DATA(:,4);
tauD=DATA(:,21);
rD=DATA(:,22);
bdur=DATA(:,3);

Ipar=DATA(:,5);
Iperp=DATA(:,6);
Ipar=Ipar(:)';
Iperp=Iperp(:)';
Gtrial=1;
k1=0;
k2=0;
r=(Ipar-Gtrial*Iperp)./((1-3*k2)*(Ipar)+Gtrial*(2-3*k1)*Iperp);

Fd=Fd-bdur*1000;
Fa=Fa-bdur*1000;



[E] = correct_E_gamma_leak_dir(Fd,Fa,Faa,gamma,Lk,di,'ALEX');
Nbursts=length(bstart)
t_bursts=(bstart(end)-bstart(1)); % time from first to last burst in seconds
t_bursts=t_bursts/60 %now minutes
% t_bursts=t_bursts/60 %now hours.

BurstRate=Nbursts/t_bursts

mtslb=mean(tslb*1000) %mean time since last burst in ms

% r=r(E>0.1);
% E=E(E>0.1);
% [edgesX2,edgesY2,N] =ndhist(E,r,'axis',[-0.1 1.1 -0.1 0.4],'binsx',2,'binsy',2,'filter',10);
% [Cm,hCont]=contourf(edgesX2,edgesY2,N,10);
% cm=flipud(gray);
% colormap(cm);
% xlabel('E')
% ylabel('r')

xf=1.1;
xi=-0.1;
% xi=0.05;
optM = optBINS(E(E>=xi & E<=xf)',25);
optM=35;
dx=(xf-xi)/(optM-1);

% jk=randi(1500,[1 374]);
% E=E(jk);

% E=E(S>0.2)
% S=S(S>0.2)
% E=E(S<0.8)

edges{1}=[xi:dx:xf]; % bin for x axis
[nEraw,cEraw] = hist(E,edges{1});
% NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4)))
hfig=NiceEHist(cEraw,nEraw,FileName(1:end-4),strcat(PathName,FileName(1:end-4),'_Ecor'),0);
% parmhat=lognfit(nEraw)
co=[0.01 0.3 0.8];
numG=length(co);
wo=2*sqrt((co.*(1-co))/min(Fa+Fd))
Ao=[max(nEraw)*wo*sqrt(pi/2)];
modelParam0=[co wo Ao];
lb=[zeros(size(modelParam0))];
ub=[ones(size(co)) Inf(size(wo)) Inf(size(Ao))] ;
% co=[0 mean(E)];
% wo=[0.05 std(E)];
% Ao=[30 max(nEraw)*wo(1)*sqrt(pi/2)];
% lb=zeros(length(modelParam0));
% ub=[0.08 1 Inf(size(wo)) Inf(size(Ao))] ;

modelParam0=[co wo Ao] ;

%Solver properties
maxiter=5000;
maxfunevals=5000;
tolfun=1e-8;
tolx=1e-8;
lsqOpt=[maxiter maxfunevals tolfun tolx];
        
        %Set options for solver
%lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');

[modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnE,modelParam0,lb,ub,options);
% [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnElogn,modelParam0,lb,ub,options);

myx=linspace(min(cEraw),max(cEraw),100);
[myfun]=MakeGauss(modelParam);
% myfun=makelogn(modelParam);
figure(hfig);
hold on
plot(myx,myfun,'-k','LineWidth',2)
fitE=modelParam(1:length(co))
fitEwo=modelParam(length(co)+1:2*length(co))
fitEAo=modelParam(2*length(co)+1:end)
yl=ylim(gca);
plot(repmat(fitE(1),1,100),linspace(yl(1),yl(2),100),'Color',[0 0 128]/256,'LineWidth',3)

wshot=2*sqrt((fitE.*(1-fitE))/L)

extraw=fitEwo./wshot
modelParamShot=[fitE wshot max(myfun)*wshot*sqrt(pi/2)]
% myx=linspace(min(cEraw),max(cEraw),100);
% [myfunshot]=MakeGauss(modelParamShot);
% figure(hfig)
% plot(myx,myfunshot,'-','LineWidth',2,'Color',[70 70 70]/256)

if ~isempty(myYlim)
set(gca,'Ylim',[0 myYlim])
end
hold off
figure(hfig)
print('-dpng','-r600',strcat(PathName,FileName(1:end-4),'_Efit'))
% Eobj
fitE




    function output=obj_fcn(gamma)
        %Function to minimize
        tempE=correct_E_gamma_leak_dir(Fd,Fa,Faa,gamma,Lk,di,'ALEX');
%         [nEraw,cEraw] = hist(tempE,edges{1});
%         
%         co=mean(tempE);
%         wo=std(tempE);
%         Ao=max(nEraw)*wo*sqrt(pi/2);
%         modelParam0=[co wo Ao]
%         numG=length(co);
%         lb=zeros(length(modelParam0));
%         ub=[ones(size(co)) Inf(size(wo)) Inf(size(Ao))] ;
%         %Solver properties
% %         maxiter=5000;
% %         maxfunevals=5000;
% %         tolfun=1e-8;
% %         tolx=1e-8;
% %         lsqOpt=[maxiter maxfunevals tolfun tolx];
% %         
% %         %Set options for solver
% %         %lsqOpt=[handles.maxiter handles.maxfunevals handles.tolfun handles.tolx];
% %         options=optimset('MaxIter',lsqOpt(1),'MaxFunEvals',lsqOpt(2),'TolFun',lsqOpt(3),'TolX',lsqOpt(4),'Algorithm','levenberg-marquardt');
%         
%         [modelParam,resnorm,residual,exitflag,output,lambda,jacobian]=lsqnonlin(@objfcnE,modelParam0,lb,ub,options);
%         
%         cf=modelParam(1:length(co));
%         wf=modelParam(length(co)+1:2*length(co));
%         Af=modelParam(2*length(co)+1:end);
%         mE=cf(Af==max(Af));
        
        mE=mean(tempE);

        output=abs(mE-Eobj);
        
        
        
    end

function [myfun]=objfcnE(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(1,length(cEraw));
        for j=1:length(c)
           
            y=y+(A(j)/(w(j)*sqrt(pi/2)))*exp(-2*((cEraw-c(j)).^2)/(w(j)^2));
            
            
        end
        
       
        myfun=(nEraw-y);
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
end

function [myfun]=objfcnElogn(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(1,length(cEraw));
        
           
            y=y+(A./(cEraw*w*sqrt(2*pi))).*exp(-((log(cEraw)-c).^2)/(2*(w)^2));
            
            
       
        myfun=(nEraw-y);
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
end

function [myfun]=makelogn(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(1,length(myx));
        
           
            y=y+(A./(myx*w*sqrt(2*pi))).*exp(-((log(myx)-c).^2)/(2*(w)^2));
            
            
       
        myfun=y;
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
end


function [myfun]=objfcntau(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(1,length(nTau));
        for j=1:length(c)
           
            y=y+(A(j)/(w(j)*sqrt(pi/2)))*exp(-2*((cTau-c(j)).^2)/(w(j)^2));
            
            
        end
        
       
        myfun=(nTau-y);
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
end

function [myfun]=MakeGauss(modelParam)
        
        %modelParam0=[r0i t0i A1i phi1i A2i phi2i phiGi];
        
        %fix certain parameters based on fixParam
        %Eg fixParam=[0 0 0 1 0] would fix the fourth element of modelParam
        %at the value given by the 4th value of modelParam0.
        %eg: a= [1 2 3 4] b=[5 6 7 8] c=[0 1 0 1] c=logical(c)
        % then a(c)=b(c) ---> a=[1 6 3 8]

        
       c=modelParam(1:numG);
        w=modelParam(numG+1:2*numG);
        A=modelParam(2*numG+1:end);
        
        y=zeros(size(myx));
        for j=1:length(c)
           
            y=y+(A(j)/(w(j)*sqrt(pi/2)))*exp(-2*((myx-c(j)).^2)/(w(j)^2));
            
            
        end
        
       
        myfun=y;
        
        myfun(isnan(myfun))=0;
        myfun(isinf(myfun))=0;
        
       
    end

end

