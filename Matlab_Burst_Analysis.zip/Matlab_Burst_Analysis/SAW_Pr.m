function P=SAW_Pr(R,r)

a1=0.299;
a2=1.269;
P1=4*pi*r.^(2);
P2=a1./(R.^3);
P3=(r./R).^0.269;
P4=exp(-a2*((r./R).^2.427));
        P=P1.*P2.*P3.*P4;

end