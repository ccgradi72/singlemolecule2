

fitE=0.35;
L=30;
wshot=sqrt((fitE.*(1-fitE))/L) %from beta dist
wshot2=(1/sqrt(L))*(fitE*sqrt(1-fitE) + (1-fitE)*sqrt(fitE)) %poiss?

w=wshot;

R = normrnd(fitE,w,1,1000)
