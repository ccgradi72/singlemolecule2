function [B_Dpar,B_Dperp,B_Apar,B_Aperp,i_start_out,i_end_out] = SlidingMLT_Bkg(t,ind)
%UNTITLED3 Inverse burst search: Find "inverse bursts" ie regions not
%containing fluorescence, defined by an region where the local count rate
%is < Mbkg/Tbkg .... ie photon waiting times > Tbkg. For Poisson process,
%the waiting times are exponentially distributed with a first moment "dt"
%then the rate parameter of this exponential distrbution (and the
%underlying Poisson process) is lambda=1/dt.
% t is the timetag array of interest. if t is in seconds, B will be the
% background count rate in cps.

global Mbkg Lbkg Tbkg

global ind_Dpar ind_Dperp ind_Apar ind_Aperp


in_burst = false;
above_min_rate = (t(Mbkg:end) - t(1:length(t)-Mbkg+1)) >= Tbkg;

i_start_out = [];
i_end_out=[];


dt_d_par=[];
dt_d_perp=[];
dt_a_par=[];
dt_a_perp=[];


for i=1:length(t)-Mbkg +1
    
    if above_min_rate(i)
        if ~in_burst
            i_start=i;           
            in_burst=true;
        end
    elseif in_burst
        
        in_burst=false;
        i_end=i+Mbkg-1; %last photon in current time window
               
        if i_end -i_start >= Lbkg
            
            %this region contains no fluorescence, lets gather the waiting
            %times for later averaging.
            
            i_start_out=[i_start_out i_start];
            i_end_out=[i_end_out i_end];
            
            t_in_burst=t(i_start:i_end);
            ind_in_burst=ind(i_start:i_end); 
            
            dt_d_par=[dt_d_par diff(t_in_burst(ind_in_burst==ind_Dpar))];
            dt_d_perp=[dt_d_perp diff(t_in_burst(ind_in_burst==ind_Dperp))];
            dt_a_par=[dt_a_par diff(t_in_burst(ind_in_burst==ind_Apar))];
            dt_a_perp=[dt_a_perp diff(t_in_burst(ind_in_burst==ind_Aperp))];

        end
        
    end
    
end


B_Dpar=1/mean(dt_d_par);
B_Dperp=1/mean(dt_d_perp);
B_Apar=1/mean(dt_a_par);
B_Aperp=1/mean(dt_a_perp);




end

