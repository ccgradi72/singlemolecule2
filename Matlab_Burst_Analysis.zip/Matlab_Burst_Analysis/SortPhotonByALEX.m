function [indM1,sstimeM1,timetagM1,indM2,sstimeM2,timetagM2] = SortPhotonByALEX(ind,sstime,timetag,marker)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

locM1=find(ind==15 & sstime==marker(1)); %location of M1 markers
locM2=find(ind==15 & sstime==marker(2));

if locM1(1)<locM2(1)
    %M1 is the first marker
    
    %the photons before first marker belong to M2 excitation
    indM2=ind(1:locM1(1)-1);
    sstimeM2=sstime(1:locM1(1)-1);
    timetagM2=timetag(1:locM1(1)-1);
    
    indM1=[];
    sstimeM1=[];
    timetagM1=[];
    
    if locM1(end)<locM2(end)
        
        %M1 if the first marker and M2 is the last marker
        
        for i=1:length(locM1)
            indM1=[indM1 ind(locM1(i)+1:locM2(i)-1)];
            sstimeM1=[sstimeM1 sstime(locM1(i)+1:locM2(i)-1)];
            timetagM1=[timetagM1 timetag(locM1(i)+1:locM2(i)-1)];
        end
        
        for i=1:length(locM2)-1
            indM2=[indM2 ind(locM2(i)+1:locM1(i+1)-1)];
            sstimeM2=[sstimeM2 sstime(locM2(i)+1:locM1(i+1)-1)];
            timetagM2=[timetagM2 timetag(locM2(i)+1:locM1(i+1)-1)];
        end
        
        %the photons after the last marker (M2) belong to M2
        indM2=[indM2 ind(locM2(end)+1:end)]
        sstimeM2=[sstimeM2 sstime(locM2(end)+1:end)]
        timetagM2=[timetagM2 timetag(locM2(end)+1:end)]
        
    else
        
        %M1 is the first and also the last marker
        for i=1:length(locM1)-1
            indM1=[indM1 ind(locM1(i)+1:locM2(i)-1)];
            sstimeM1=[sstimeM1 sstime(locM1(i)+1:locM2(i)-1)];
            timetagM1=[timetagM1 timetag(locM1(i)+1:locM2(i)-1)];
        end
        
        for i=1:length(locM2)
            indM2=[indM2 ind(locM2(i)+1:locM1(i+1)-1)];
            sstimeM2=[sstimeM2 sstime(locM2(i)+1:locM1(i+1)-1)];
            timetagM2=[timetagM2 timetag(locM2(i)+1:locM1(i+1)-1)];
        end
        
        %the photons after the last marker (M1) belong to M1
        indM1=[indM1 ind(locM1(end)+1:end)]
        sstimeM1=[sstimeM1 sstime(locM1(end)+1:end)]
        timetagM1=[timetagM1 timetag(locM1(end)+1:end)]
    end
    
else
    %M2 is the first marker
    
    %the photons before first marker belong to M1 excitation
    indM1=ind(1:locM2(1)-1);
    sstimeM1=sstime(1:locM2(1)-1);
    timetagM1=timetag(1:locM2(1)-1);
    
    indM2=[];
    sstimeM2=[];
    timetagM2=[];
    
    if locM2(end)<locM1(end)
        
        %M2 is the first marker and M1 is the last marker
        
        for i=1:length(locM2)
            indM2=[indM2 ind(locM2(i)+1:locM1(i)-1)];
            sstimeM2=[sstimeM2 sstime(locM2(i)+1:locM1(i)-1)];
            timetagM2=[timetagM2 timetag(locM2(i)+1:locM1(i)-1)];
        end
        
        for i=1:length(locM1)-1
            indM1=[indM1 ind(locM1(i)+1:locM2(i+1)-1)];
            sstimeM1=[sstimeM1 sstime(locM1(i)+1:locM2(i+1)-1)];
            timetagM1=[timetagM1 timetag(locM1(i)+1:locM2(i+1)-1)];
        end
        
        %the photons after the last marker (M1) belong to M1
        indM1=[indM1 ind(locM1(end)+1:end)]
        sstimeM1=[sstimeM1 sstime(locM1(end)+1:end)]
        timetagM1=[timetagM1 timetag(locM1(end)+1:end)]
        
    else
        
        %M2 is the first and also the last marker
        for i=1:length(locM2)-1
            indM2=[indM2 ind(locM2(i)+1:locM1(i)-1)];
            sstimeM2=[sstimeM2 sstime(locM2(i)+1:locM1(i)-1)];
            timetagM2=[timetagM2 timetag(locM2(i)+1:locM1(i)-1)];
        end
        
        for i=1:length(locM1)
            indM1=[indM1 ind(locM1(i)+1:locM2(i+1)-1)];
            sstimeM1=[sstimeM1 sstime(locM1(i)+1:locM2(i+1)-1)];
            timetagM1=[timetagM1 timetag(locM1(i)+1:locM2(i+1)-1)];
        end
        
        %the photons after the last marker (M2) belong to M2
        indM2=[indM2 ind(locM2(end)+1:end)]
        sstimeM2=[sstimeM2 sstime(locM2(end)+1:end)]
        timetagM2=[timetagM2 timetag(locM2(end)+1:end)]
    end
    
end


end

