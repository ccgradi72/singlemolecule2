clc;
close all;
clear all;


tp=1:4096;
dt=0.004;
p=12.5; %ns
tau=25; %ns
Nexc=1;

tau=tau/dt; %ch
p=p/dt; %ch


 x = exp(-(tp-1)*(1./tau)).*(1./(1-exp(-p./tau))); %repetive excitation period
%  x=x/sum(x);

 z=exp(-(tp-1)*(1./tau));
 for i=1:Nexc
     temp=exp(-(tp-1+i*p)*(1./(tau)));
    z=z+temp;
 end
%  z=z/sum(z);
 
 figure;
 hold all
 semilogy(dt*tp,x)
 semilogy(dt*tp,z,'--')
 semilogy(dt*tp,temp)
 set(gca,'YScale','log')
 legend('Analytical','Manual','temp')