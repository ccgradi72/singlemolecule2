function [ Sraw] =UncorrStoich(nD,nA,nAA)
%UNTITLED2 Calculates the uncorrected stoichiometry factor Sraw from nD and
%nA which are from donor excitation, and are only background corrected (no
%leakage or direct excitation corrections). nAA is acceptor emission after
%acceptor excitation.
%   Detailed explanation goes here

nD=nD(:)';
nA=nA(:)';
nAA=nAA(:)';

Sraw=(nD+nA)./(nD+nA+nAA);


end

