function [ ] = UpdateGraphsv2()
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%One-D histograms
% global Eraw_hist Sraw_hist TauD_hist burst_dur_hist InterBurst_hist
% 
% %Fluorescence Decay Histograms
% global subens_fluorplot
% 
% %Anisotropy Decay Histograms
% global subens_anisoplot
% 
% %2d histograms
% global anisotau_hist SrawEraw_hist AsymE_hist
% 
% %The data
% global AllRecords subEns1_Dpar subEns1_Dperp subEns2_Dpar subEns2_Dperp
% 
% %The figure handles so we don't create thousands of graphs
% global hTauD hEraw hSraw hBdur hTbwBur hSubFluo hSubAniso

global fid_burst_txt

% currRecord=[burst_start burst_end burst_duration TimeSinceLastBurst ...
%     Sdd_par Sdd_perp Sad_par Sad_perp Saa_par Saa_perp ...
%     Bdd_par Bdd_perp Bad_par Bad_perp Baa_par Baa_perp ...
%     Txd Txa Tdd Tad ...
%     tauD rD rA...
%     Eraw Sraw E S];

close gcf 

ReadRecords=textscan(fid_burst_txt,repmat('%f',1,27));

subplot(3,2,1)
 xf=7;
    xi=1;
    nxBins=20;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
    [nTauD,cTauD] = hist(ReadRecords{21},edges{1});
%      [nTauD,cTauD] = hist(ReadRecords(:,21),25);
    bar(cTauD,nTauD,'BarWidth',0.75,'FaceColor', 'r');
     xlabel('Donor Lifetime (ns)')
        ylabel('Frequency')
subplot(3,2,2)
 xf=1.1;
    xi=-0.1;
    nxBins=20;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
[nEraw,cEraw] = hist(ReadRecords{24},edges{1});
bar(cEraw,nEraw,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Eraw')
        ylabel('Frequency')
subplot(3,2,3)
    xf=1.1;
    xi=-0.1;
    nxBins=20;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
    [nSraw,cSraw] = hist(ReadRecords{25},edges{1});
        bar(cSraw,nSraw,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Sraw')
        ylabel('Frequency')

subplot(3,2,4)
    xf=500;
    xi=0;
    nxBins=1000;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
%     [nBdur,cBdur] = hist(AllRecords(:,3)*1E6,edges{1});
    [nBdur,cBdur] = hist(ReadRecords{3}*1E3,25);
      bar(cBdur,nBdur,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Burst Duration (milliseconds)')
subplot(3,2,5)
    xf=1000;
    xi=0;
    nxBins=100;
    dx=(xf-xi)/nxBins;
    edges{1}=[xi:dx:xf]; % bin for x axis
%     [nTbwBur,cTbwBur] = hist(AllRecords(:,4)*1E3,edges{1});
     [nTbwBur,cTbwBur] = hist(ReadRecords{4}*1E3,25);
       bar(cTbwBur,nTbwBur,'BarWidth',0.75,'FaceColor', 'r');
        xlabel('Time Between Bursts (milliseconds)')
        ylabel('Frequency')

% if subens_fluorplot
%     
%     if ishandle(hSubFluo)
%         plot(hSubFluo,0:4095,Itotal(subEns1_Dpar,subEns1_Dperp,'D'),0:4095,Itotal(subEns2_Dpar,subEns2_Dperp,'D')) 
%     else
%         figure;
%         hSubFluo= plot(0:4095,Itotal(subEns1_Dpar,subEns1_Dperp,'D'),0:4095,Itotal(subEns2_Dpar,subEns2_Dperp,'D'));
%         xlabel('TCSPC Channels')
%         ylabel('Fluorescence')
%         legend('SubEnsemble1','SubEnsemble2')
%     end
% end
% 
% if subens_anisoplot
%     
%     if ishandle(hSubAniso)
%         plot(hSubAniso,0:4095,Aniso(subEns1_Dpar,subEns1_Dperp,'D',[]),0:4095,Aniso(subEns2_Dpar,subEns2_Dperp,'D',[])) 
%     else
%         figure;
%         hSubAniso= plot(0:4095,Aniso(subEns1_Dpar,subEns1_Dperp,'D',[]),0:4095,Aniso(subEns2_Dpar,subEns2_Dperp,'D',[]));
%         xlabel('TCSPC Channels')
%         ylabel('Anisotropy (No bkg Corr)')
%         legend('SubEnsemble1','SubEnsemble2')
%     end

    


drawnow
end

