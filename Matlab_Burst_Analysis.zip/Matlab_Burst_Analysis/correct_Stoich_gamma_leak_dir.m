function [S] = correct_Stoich_gamma_leak_dir(nD,nA,nAA,gamma,lk,di,dirTYPE)
%UNTITLED3 nD,nA are donor and acceptor counts after donor excitation with
%only bkg correction. nAA also only bkg correction - the acceptor counts
%after acceptor excitation.
%   dirTYPE: a string which expressed how the coeffecient dir has been 
%calculated since nDir can be expressed in several equivalent ways:
%see http://nbviewer.ipython.org/github/tritemio/notebooks/blob/master/Derivation%20of%20FRET%20and%20S%20correction%20formulas.ipynb
% or Kapanidis/Lee/Michalet's ALEX papers, Eg. Biophys J 2005.

%If using ALEX with manual input corection factors use:
    %[E] = correct_Stoich_gamma_leak_dir(nD,nA,nAA,gamma,lk,dir,'ALEX')
%If using ALEX with global corection factors use:
    %[E] = correct_Stoich_gamma_leak_dir(nD,nA,nAA,[],[],[],'ALEX')    
%If not using ALEX, but using manual input corection factors use:
    %[E] = correct_Stoich_gamma_leak_dir(nD,nA,[],gamma,lk,dir,'ABS')
%If not using ALEX, but using global corection factors use:
    %[E] = correct_Stoich_gamma_leak_dir(nD,nA,[],[],[],[],'ALEX')
%In all cases if you only want to use one or two correction factors, leave
%the ones you don't know as empty matrices. Example:
     %[E] = correct_Stoich_gamma_leak_dir(nD,nA,[],1.1,[],[],'ALEX')
     %Is for not using ALEX, using global correction factors for lk and dir
     %but using gamma=1.1. 
%If the global correction factor(s) is(are) empty ([]) then the function
%will use defaults which are like no correction factor, ie, gamma=1,
%lk=0,dir=0.

global global_gamma global_lk global_dir global_dirType

if isempty(gamma)
    if isempty(global_gamma)
        gamma=1;
    else
        gamma=global_gamma;
    end
end

if isempty(lk)
    if isempty(global_lk)
        lk=0;
    else
        lk=global_lk;
    end
end

if isempty(di)
    if isempty(global_dir)
        di=0;
    else
        di=global_dir;
    end
end

if isempty(dirTYPE)
    if ~isempty(global_dirType)
        dirTYPE=global_dirType;
    end
end

switch dirTYPE
    case 'ALEX'
        %dir was calculated from acceptor only population and nDir is
        %expressed as
        nDir=di*nAA;
    case 'ABS'
        %dir was calculated from absorption cross section as
        %dir=sigma_A532/sigma_D532 ie, if green donor excitation was used.
        nDir=di*(nA+gamma*nD); %ie as a function of total signal
    otherwise
        nDir=0;
        sprintf('Error: correct_E_gamma_leak_dir: Direct excitation correction method not recognized')
end

corr_nA=nA-lk*nD-nDir;

S=(gamma*nD + corr_nA)./(gamma*nD + corr_nA + nAA);



end

