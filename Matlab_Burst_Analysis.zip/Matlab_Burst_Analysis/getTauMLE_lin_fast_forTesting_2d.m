function [tau_out,gamma_out, err_out]=getTauMLE_lin_fast_forTesting_2d(irf,N,dt,p,c,Tmax)

% close all
drawmode=1; %don't draw fitting procedure
maxiter=1000;
%N is the decay to fit.
%c is a color offset in TCSPC channels, which can be varied if known, set to 0 if not known.
%p is the periodicity of the excitation pulse, ie p=Tpp=12.5, 25, 37.5, 50
%etc ns. dt and p must be in the same units. irf and N must be of same
%length.
%An additional assumption is that the bkg contribution is 0%, which is
%close to the actual value when count rates within burst are high.
%Tmax, delete all values after Tmax

fw='Normal';
fn='Helvetica';
axw='Normal';
cc=[255, 153, 0]/255;
cc2=[48, 94 168]/255;
fontsizeax=16;
fontsizel=12;
lwax=1;
ticksize=20;
linewidthbestfit=0.4;
linewidthErrBar=1;
markersize=10;
lw=2;
lwe=2;
ms=markersize;

%% Make inputs insesnitive to row or column

irf=irf(:);
N=N(:);

N(floor(Tmax/dt):end)=[];
irf(floor(Tmax/dt):end)=[];

% figure;
% plot(0:dt:dt*(finalsize-1),N)

%% Some prep work

p = p/dt; %in channels
n = length(irf);
t = 1:n;
tp = (1:p)';
% c = 0; %color offset, can vary if known
irs = (1-c+floor(c))*irf(rem(rem(t-floor(c)-1, n)+n,n)+1) + (c-floor(c))*irf(rem(rem(t-ceil(c)-1, n)+n,n)+1); %a shifted irf by c channels
IRS=irs/sum(irs); %normalized scatter
Ntot=sum(N);

dtaumin=0.020;

%% Iteratively searching grid

taustart=0.010/dt;
taustop=9/dt;
gammastart=0;
gammastop=0.5;
gammarange=gammastop-gammastart;
range=taustop-taustart;
numiter=1;
while (range>dtaumin/dt || gammarange>0.01) && numiter<maxiter %we desire an accuracy of 10ps
    
    
    tauv=linspace(taustart,taustop,10); %a grid with  approx 1ns spacing on the first iteration, in TCSPC channel units
    gammav=linspace(gammastart,gammastop,10);
    err=zeros(length(tauv),length(gammav));

    for j=1:length(gammav)
        for i=1:length(tauv)
            err(i,j)=mlelin(tauv(i),gammav(j));
        end
    end
    
    [GAMMAV,TAUV]=meshgrid(gammav,tauv);
    
    
    [~,I]=min(err(:));
    [itau,igamma]=ind2sub(size(err),I);
    mintau=TAUV(itau,igamma);
    mingamma=GAMMAV(itau,igamma);
    
    itau=find(tauv==mintau);
    igamma=find(gammav==mingamma);

   
    
    
    if itau~=1 
    taustart=tauv(itau-1);
    end
    if itau~=length(tauv)
    taustop=tauv(itau+1);
    end
    
    if igamma~=1 
    gammastart=gammav(igamma-1) ;
    end
    if igamma~=length(gammav)
    gammastop=gammav(igamma+1);
    end
    
    range=taustop-taustart;
    gammarange=gammastop-gammastart;
    tau_out=tauv(itau)*dt; %the tau output is in same units as dt now
    gamma_out=gammav(igamma); %the tau output is in same units as dt now
    err_out=mlelin(tauv(itau),gammav(igamma)); 
    
    
     if drawmode && numiter<10
        figure;
    hold all

    surf(TAUV*dt,GAMMAV,log(err))
   
    ZMax=max(max(log(err(~isinf(err)))));
    plot3(mintau*dt,mingamma,ZMax,'d','MarkerFaceColor','m','MarkerSize',ms)
     axis tight
     
         set(gca,'FontSize', ticksize);
        set(gca,'FontWeight',axw);
        set(gca,'TickDir','in', ...
            'TickLength'  , [.02 .02] , ...
            'XMinorTick'  , 'off'      , ...
            'YMinorTick'  , 'off'      , ...
            'YGrid'       , 'off'      , ...
            'XColor'      , [.1 .1 .1], ...
            'YColor'      , [.1 .1 .1], ...
            'LineWidth', lwax) ;
        set(gca, 'Box' , 'on' )
          set(gcf, 'PaperPositionMode','auto');
        set(gcf, 'color', 'w');
        
         left1=0.18;
        left2=left1;
        width1=0.8;
        width2=width1;
        
        height1=0.75;
        height2=0.15;
        
        bottom1=0.18;
        bottom2=bottom1+height2+0.03;
        
%         set(hAxTOP,'Position',[left1 bottom2 width1 height1]); %1
        set(gca,'Position',[left2 bottom1 width2 height1]); %2
        
        titled=sprintf('MLE2d%d',numiter);
        print('-dpng','-r600',titled)
        
        sprintf('Iteration %d \r\n',numiter)
                sprintf('taustep %f \r\n',range*dt/10)
                        sprintf('gammastep %f \r\n',gammarange/10)
    end
    
    
    
    
    
    numiter=numiter+1;
end

%% Functions used.

    function err = mlelin(tau,gamma)
        
        x = exp(-(tp-1)*(1./tau)).*(1./(1-exp(-p./tau))); %repetive excitation period
        X=x./sum(x);
        z = Convol(IRS, X);
        zz=z/sum(z);
        M=Ntot*((1-gamma)*zz + gamma*IRS); %model function

        ind = N>0;

        err = (2./(length(N(ind))-1-2))*sum(N(ind).*log(N(ind)./M(ind))); %only 2 fit parameter
        err(~isreal(err))=Inf;
        
    end
end



