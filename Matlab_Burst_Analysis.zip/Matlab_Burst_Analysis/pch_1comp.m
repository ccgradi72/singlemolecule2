function err = pch_1comp(p_pch)
    %Adapted From Yuchong Li

    global Q PCHData PCHFit PCHEndBin
    
    k_max=PCHEndBin;
    correctionF=p_pch(end);
    
    switch length(p_pch)
        case 3
            
            v=pch_1compfcn(p_pch(1),p_pch(2));
            
        case 5
            v1=pch_1compfcn(p_pch(1),p_pch(2));
            v2=pch_1compfcn(p_pch(3),p_pch(4));
             v = convfft(v1,v2);
            v = v(1:length(v1));
    end
    
    
    

w=1./(sqrt(PCHData.*(1-PCHData)) ); %Binomial weighting
    
%% Obtaining weighted residual  
 err=(PCHData-v).*w; 
 err(isnan(err))=0;
 err(isinf(err))=0;
 
 
    function [v]=pch_1compfcn(ep,N)
       
        
%% Insert the p_1 particle function
    w0=100; %PSF profile parameters, is also #of integration steps
	w0_2=w0^2;
	z_max=w0*Q^(1/3);    
    % PSF=@(r,z,w0_2)(exp(-4*(z^2+r^2)/w0_2)); %define PSF form
    y = zeros(1,k_max+1); % k_max+1
    for z=0:z_max;
        r_max=z_max*sqrt(1-(z/z_max)^2);
        for r=0:r_max;
            y = y+((2*pi*r.*poisspdf(0:k_max,ep).*(exp(-4*(z^2+r^2)/w0_2))));
        end
    end
    
    y=y/sum(y);
    y(2)=y(2)+ ep*correctionF/(2.828*Q);
    y(2:end)=y(2:end)./(1+correctionF)^2;
    y(1)=1-sum(y(2:end));
    p1 = y;

    %% The P1 convolution function
    poisson_N = poisspdf(0:k_max ,N);    
    v = zeros(1,k_max+1); % k_max+1
    v(1) = poisson_N(1);
    v = v + p1.*poisson_N(2);
    for i = (2:k_max);
        pN=p1;
        for j = (1:i-1);
            pN = convfft(p1, pN);
        end
    	v = (v+pN(1:k_max+1).*poisson_N(i+1));
    end
        
    end

end
