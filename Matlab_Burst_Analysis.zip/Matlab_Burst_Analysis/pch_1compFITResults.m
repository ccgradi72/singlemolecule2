function [fit, err] = pch_1compFITResults(p_pch)
    %Adapted From Yuchong Li

    global Q PCHData PCHFit PCHEndBin
    
    k_max=PCHEndBin;
    correctionF=p_pch(3);
    
%% Insert the p_1 particle function
    w0=100; %PSF profile parameters, is also #of integration steps
	w0_2=w0^2;
	z_max=w0*Q^(1/3);    
    % PSF=@(r,z,w0_2)(exp(-4*(z^2+r^2)/w0_2)); %define PSF form
    y = zeros(1,k_max+1); % k_max+1
    for z=0:z_max;
        r_max=z_max*sqrt(1-(z/z_max)^2);
        for r=0:r_max;
            y = y+((2*pi*r.*poisspdf(0:k_max,p_pch(2)).*(exp(-4*(z^2+r^2)/w0_2))));
        end
    end
    
    y=y/sum(y);
    y(2)=y(2)+ p_pch(2)*correctionF/(2.828*Q);
    y(2:end)=y(2:end)./(1+correctionF)^2;
    y(1)=1-sum(y(2:end));
    p1 = y;

    %% The P1 convolution function
    poisson_N = poisspdf(0:k_max ,p_pch(1));    
    v = zeros(1,k_max+1); % k_max+1
    v(1) = poisson_N(1);
    v = v + p1.*poisson_N(2);
    for i = (2:k_max);
        pN=p1;
        for j = (1:i-1);
            pN = convfft(p1, pN);
        end
    	v = (v+pN(1:k_max+1).*poisson_N(i+1));
    end

w=1./(sqrt(PCHData.*(1-PCHData)) ); %Binomial weighting
    
%% Obtaining weighted residual  
 err=(PCHData-v).*w; 
fit=v;
end
